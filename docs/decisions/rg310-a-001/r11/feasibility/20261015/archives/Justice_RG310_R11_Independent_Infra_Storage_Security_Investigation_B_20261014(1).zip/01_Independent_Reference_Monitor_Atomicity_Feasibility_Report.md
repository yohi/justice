# Justice RG-310-A-001 / R11 — 調査B 独立 Reference Monitor・Atomicity・Security 静的調査報告

**作成日:** 2026-10-14 JST  
**役割:** 新規・独立した技術調査B（正式 Owner／Gate reviewer／人間の独立性認証ではない）  
**区分:** READ-ONLY STATIC RESEARCH / CANDIDATE ONLY / NO HOST RUN / UNSIGNED  
**最終判定:** `RG310-FEAS-002=OPEN/NOT_VERIFIED`, `RG310-FEAS-003=OPEN/NOT_VERIFIED`, `RG310-FEAS-006=OPEN/NOT_VERIFIED`; `TRUSTED_OP_BOUNDARY_PROVEN=UNKNOWN`; `OP_PREPARE_ALLOWED=UNKNOWN/BLOCKED + STOP`。

## 1. 独立確認した原本と方法

- 受領した外側ハンドオフZIP `Justice_RG310_FEAS002_003_Monitor_Atomicity_Independent_Handoff_20261014(1).zip` のSHA-256は **`af1a364228650c2ca778e517962751049507bfe7819a3f63730351662aaa9499`** で指定値に一致。ZIP CRC全件PASS、内部SHA256SUMS **22/22 MATCH**、MANIFEST記載22ファイルのSHA-256/byte長は再計算一致。原本を `ORIGINAL/` 内に byte-for-byte 収容した。
- `INPUT/` の四つのZIPは個別のSHA256・CRC・内部SHA256SUMSを再計算し、順に **8/8・12/12・3/3・15/15 MATCH**。R11 ZIP `1df24d4250132a3df1bc2c4d39b53baebbe1b1d8ad8060862c0531743601d185`、旧Feasibility result `b879c369cacdda126caf22b0633af137187d5fa4920a615dd232a9d58527ef99`、R11 technical review `bd1abee742d1a495f7e8a7bed9e2fb7a99f8358efbf5f835451e20cff67fc14b`、original feasibility handoff `bbc40f2712fc0e016807648825c68481ad214fcb6b3cf6961aa33ba05cac095b`。 `SOURCE/` 12ファイルは result ZIP の12原本に **12/12 byte一致**。旧handoffに内包された再帰的ZIP（diff/historicalを含む）もCRC・各内部SHA256SUMS一致、diff SHA `797bb62ff36a0df9ff76e532738ff015bae525c7c87edde76a6752bfc93b9db6`、historical ZIP SHA `6d4009a0272539b22707607f4e32e931829eda83e3e6ec52aa748c51dd2fc591`。
- 受領 `00_READ_FIRST.md`・`01_SHARED_STATIC_WORK_CONTRACT.md`・`02_B_MONITOR_ATOMICITY_FULL_WORK_CONTRACT.md` を全文確認。R11原本 `01-architecture-decision-proposal-R11.md` D.3.2/E.3.2/E.9.0 と `04-authorization-fingerprint-transition-matrix-R11.md` §§1–7、Feasibility result `01`・`03`・`04`・`05`・`06`・`07`、固定Task1最終記録を照合した。原本中の説明を安全性の証明としては採用しない。
- GitHub読み取り専用APIで正確な immutable SHA を指定し取得（代表 anchor を下に記載）。直接得た Git blob: fixed Senpi `types.ts=278432ae2bb98098ef69ecdea7d508bb7aa59bc2`、`agent-session.ts=2ba84efe75090fb9b34562fba41048233367a260`、`tools/bash.ts=af91ac54f3a53887ae4db7d0a4ebdb184a429060`、`exec.ts=5afe9ec367257ae4b7bd62fd1502e9b1fa275684`、`extensions/runner.ts=90f5cbddca03d4bca71151e6a9cbf40a5fc71db5`。fixed Justice `R= d335c34b747cafd6ac3b2e81d710fdcc61fb777e`, `D=64acdf177d2fd207861eb477af7c8a265eed71e8`, `P=10dfba4c199feff19ee387b244daf6c0fd30d5e3`, `Task1 evidence=7df0887402d1d4eaf34a09e44213cf75b630b813`, `package.json=8e154e09d0c6253d104b60e72208c5ff2a3478b4`。これらは取得した範囲の一次ソース確認であり、全依存呼出しグラフの網羅証明ではない。
- 元R11文書は**未承認の提案候補**。PR #295固定Evidence HEAD `c428041dfb5779b6b6dc8db7bf14928225a00373`、既承認R/D/P `8a2e4f1536e9cad499ee7e9d996ff163df132fd4`、PR #325 archival HEAD `74cac6f61946a30583e61e4004ae6f66a0abdd76`。固定SHA以外の現在のブランチ先頭／公開状態は当調査の新規ライブ検証対象外。

## 2. 否定例を先に示す一次ソース・信頼境界（事実／推論）

| 区分 | 一次ソース anchor | 独立確認できた事実 | Bの安全性への含意（設計上の推論、未実装） |
|---|---|---|---|
| 確認済 | `code-yeongyu/senpi@d56e6a260d9468418a39bc9120945cf98e06b840:packages/coding-agent/src/core/extensions/types.ts#L2327-L2334` | `registerFilesystemPolicy` の説明は組込み `read/write/edit/ls/find/grep` のdeny-winsに限定されている | shell/`exec`、native add-on、CI/admin、network、mountへのcomplete mediation証明には使えない |
| 確認済 | 同 `types.ts#L2435-L2452` | `exec(command,args,...)` と `executeTool` が別のextension actionとして宣言 | FS policyを全effect monitorと同一視できない |
| 確認済 | 同 `tools/bash.ts#L103-L129`, `#L173-L205` | `createLocalShellOperations` は子プロセスを`spawn`し、descendant/background lifecycleも考慮 | 子孫プロセスと事前に存在するwriterへ OS強制が必要。`kill`/ログで後追いしても足りない |
| 確認済 | 同 `exec.ts#L30-L45` | `execCommand` が独立の `spawn` API を使用 | shellを遮断しても extension `exec` 等が残れば actor 許可境界とは異なる |
| 確認済 | 同 `agent-session.ts#L1665-L1718`, `#L3080-L3135` | `tool_call`/`tool_result` hook は存在し、`message_end` に対するcallback後に session append処理がある | hook callback・append記録は host外の全writer/reader・外部副作用を封じない |
| 確認済 | `yohi/justice@c428041dfb5779b6b6dc8db7bf14928225a00373:docs/reports/omo-native-v5.1.17-senpi-2026.10.8-contract-evidence.md#L420-L535` | Task1 31/32、Case A未観測5項目、unknown-tool messageId null、Task1 BLOCKED | 監視器とstorage調査で Task1やH0は改善したとは扱わない |
| 提案入力（未承認） | R11原本`04-authorization-fingerprint-transition-matrix-R11.md` §§1–6、`01-architecture-decision-proposal-R11.md` D.3.2/E.3.2 | 全事前仲介と一元的 ACCEPT+PUBLISH をMUSTと規定 | MUSTの文章は配置済み監視器、ACL、鍵、commit/readerの証拠ではない |

**反例A（pre-effect bypass）:** actorが利用できる `bash/exec` のchild processが外側authority pathにwrite可能なら、extension hookで事後観測する前に直接変更できる。ファイルの `open/write/rename/link/symlink/mount`、`/proc/<pid>/fd` 等の代替参照、bind mount、hardlink、native subprocess、CI・管理者・別writer・外部ネットワークも同じ。各経路にOS/credential ACLによる非到達証拠がなければ `COMPLETE_MEDIATION=NOT_VERIFIED`（実際の侵害を観測したとは主張しない）。

**反例B（publish split）:** 正常FS renameで新しいsourceを公開してから別ledgerをappendすると、crashで **bytes-only**。逆順なら **accepted-only**。その間に直接pathを読む readerがいるなら gateway経由の監査結果と実可視性が分離する。これは原子的linearizationと両立しない構成的反例であり、現行環境がこの設計で動いていると確認したわけではない。

**反例C（権限自己発行）:** actorが `time`, `revocation`, ledger hash chain, policy config, HSA verification keys, monitor binary, broker root を任意変更できる境界では、actor署名・Git履歴・hash chainが整っていても外部真正性なし。署名者/失効authorityとBroker/DB管理者が同一privilege rootに吸収されるなら「独立」を立証できない。

## 3. 分離した3技術判定

### `RG310-FEAS-002` — actor-external complete mediation: `NOT_VERIFIED / OPEN CRITICAL`

**構想可能**な最小構成は、actor process/treeを非特権・閉じたnamespace/cgroup/networkで強制隔離し、 authoritative mount/credentials/CI/admin/service keyの一切を渡さず、 private stageだけをwrite可にし、完全に独立したBrokerが事前grant・effect許可・書込・公開を一元管理するもの。built-in/custom/deferred/nested tools、extension `exec`、subprocess、fs syscalls、symlink/mount、artifact caches/logs/secrets/network、外部SaaS、CI runner、管理者、他worktreeやbackground writerまで writer inventory に含める。ポリシーUIが存在するだけでなく、OS/credential policy自体をactorが変更・経由できないことが必要。

**不足:** 実際のactor UID/capability/seccomp/mount namespace/LSM, socket/IPC/FD継承、CI/administrative principals, storage ACL, network egress, privileged escape, OS/host extension binaries、write/side effect一覧とそれらの否定証拠が存在しない。**static source alone cannot prove deployment mediation**。直接pathへアクセスするreader/管理者がいるなら Option1の「gatewayのみ」を破るため **FAIL**（当該読者の存在自体は未検証）。actorに上位root権限を与える運用を許す設計はその時点で不適合。

### `RG310-FEAS-003` — durable acceptedとvisible bytesの単一atomic point: `NOT_VERIFIED / OPEN CRITICAL`

**最も厳密な候補:** 独立サービスの単一transactional authority (単一ACID database) に accepted operation record、source bytes/content manifest、visible head pointer、seq state、grant revocation epochを保持し、serializable commitで一括更新する。全readerはこのDBスナップショットを読む唯一のgatewayだけを利用し、filesystems・Git worktrees・CDN・log tailを authoritative root にしない。**commit成功が唯一のlinearization point** であり、別領域のACL・普通のrenameを入れない。private stageは外から不可視、durable `PREPARED` は受入ではない。復旧時は一貫したDB transaction snapshotでroot/ledger/sequenceを同時に読む。DB content immutable参照方式は別blobストアのdurability・削除耐性まで一体として証明する必要があり、汎用的に自明ではない。

**不足:** storage engineのAPIと具体的transaction isolation/durability/commit acknowledge/replication/failover, gateway reader confinement、writer CAS/lease epoch、refcount GC, backups/restore point in time、独立recovery actorの証明がない。とりわけ ordinary pathを直接読むreaderを残したまま transactional manifest だけ追加する案は**不適合**。`ACCEPTED`はDB中のacceptedRecordのみを指すのでなく、同一snapshotでbytesが可視であることを意味する。

### `RG310-FEAS-006` — signatures / clock / revocation / ledger independence: `NOT_VERIFIED / OPEN HIGH`

Human grant signer/HSA authority、OS policy operator、Broker identity、database writer、read gateway、revocation publisher、trusted time/seq authority、independent auditorは**異なる権限とaudit trails**を持つべき。人間署名はcanonical grantとexact scoped digestに結合、鍵はactor非保有、署名検証は専用trusted roots、失効はBrokerではなく独立publisherが更新。可能ならrevocation decision/versionは commit databaseと同一serializable transaction domainに格納し、**反映済 revocation とcommitを直列化**する。外部発行からDB反映までの遅延をどの時点で失効と扱うか定義/証明できなければ STOP。clockは独立署名された時刻/最大不確実性とcommit-time checkを組み合わせる必要がある。DBサーバの自己申告timestampだけでは外部独立時計証明でない。

**不足:** 実鍵 custody/rotation, cert expiration, principal IAM/ACL, dual control, trustworthy timestamp, commit-vs-revoke ordering, quorum/failover clock monotonicity, ledger export WORM verification。**過去の正式権限発行・鍵管理・署名が存在したとは主張しない**。

## 4. 受理の最小不変条件と38×7保全

- **PREPARE:** signed HSA/IAB exact chain + actor/phase/attempt/command/scope、fresh external time/revocation、live current `beforeFullRoot`、exclusive writer fence、durable unique `opId`/reserved seq、independently durable `OP_PREPARED`、private stage boundary。**unknown future afterRootをPREPAREへ入れない**。
- **COMMIT:** independently remeasure staged bytes/paths/hunks/modes/symlinks/pins/effects; HSA expiry/revocation and root/CAS/epoch recheck **at linearization**; one DB transaction atomically write accepted record+new authoritative bytes/manifest+visible root+seq. No replay/duplicate delivery changes historical result。
- **ABORT:** independent proof of no public/irreversible effect + durable abort tombstone and stage disposal; if undecidable return `IN_DOUBT/QUARANTINE/STOP` rather than silent rollback or invented `ABORTED`。Recovery must not promote stage automatically。
- **Phase close:** gap-free accepted/aborted reservations, no pending/IN_DOUBT, exact sealed full root, independently authenticated close/freeze/reattest. Source-only `S`、compiled `P`、host `R`、production `I` are not interchangeable。
- Original 38 stable IDs and seven independent columns (**operation, grant, evidence, next action, human decision, fail-closed result, independent proof obligation**) remain unchanged in `09_R11_38x7_B_Impact_Audit.csv` and immutable original R11 ZIP。Today **none** of the hypothetical run/write rows have executed; each remains `B_INFRA_PROOF=NOT_VERIFIED`。Row 34 still `H0 UNKNOWN/BLOCKED`; row 35 is a future conditional trace, not evidence.

## 5. Scope/STOP/dependencies

Existing **Task1 canonical 31/32 PROVEN + 1 unknown-tool BLOCKED; Case A BLOCKED (5 controls missing); Case B PROVEN; B-001 BLOCKED / B-002 NOT_PROVEN (outside canonical 32), required runtime and mandatory safety aggregates true; Task1 BLOCKED** all unchanged. H0/G1/G2 fixed Senpi source/API is **調査Aの未解決外部依存**。調査Bの ledger/monitor 構想から H0・R・I や真正producer identity を推定しない。

未採択R11順序をそのまま保持：`R'→D'→P' fresh review→human ADR→B0 HSA→B0 isolated staging/acceptance→B1 independent P(EAF0)→separate DEP HSA→DEP_START latch at EAF0 before first DEP stage→B2-DEP each op→DEP close→separate HOST-PREP HSA→HOST-PREP no run→EAF_final freeze→independent B1 reattestation RA→separate human ACTIVATE→H0 before START→H1 per ingress→H2 actual result only after arrival→H3 independent actual evidence→B3 separate Task1 gate`。任一未証明またはgrant失効= `UNKNOWN/BLOCKED/STOP`; 実侵害・偽造が別途独立立証された場合に限り `REVOKED`（別途明示的なB1 formal FAIL規則は除く）。

**本調査の実行結果:** コード、fixture、tests、evaluator、R/D/P、CI、cloud/OS、GitHub、branch、Git設定を変更していない。build/test/process runtime/host experiments、署名・HSA・RA発行、任意の実運用操作を行っていない。提出物は設計候補を比較する読み取り専用成果物であり、`STATICALLY_CONSTRUCTIBLE_WITH_VERIFIABLE_PRE_EFFECT_COVERAGE`、`PROVEN`、正式採択、正式Fresh Gateを**いずれも主張しない**。

## 6. 新規findingと次の独立確認

`RG310-B-FI-001..006`（`07_B_Independent_Finding_Register.csv`）参照。未取得のOS/ACL、credential/writer/read inventory、transaction commit／failover consistency、clock/revocation serialization、audit custody、fixed host producer ingress/APIは `08_B_Unresolved_Evidence_Inventory.csv`。独立調査Bだけで本番検証・実装へ進めない。次に必要なのは人間Architecture/Requirements/Design/Plan Ownerによる**署名なしの選択肢判断**と、後日別途認可された境界検査＋新規独立Gateである。
