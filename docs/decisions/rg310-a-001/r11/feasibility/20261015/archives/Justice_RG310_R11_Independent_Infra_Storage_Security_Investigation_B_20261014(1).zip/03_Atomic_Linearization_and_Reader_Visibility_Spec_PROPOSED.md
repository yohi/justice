# 調査B — Atomic ACCEPT+PUBLISH / Reader Visibility 仕様案

**提案のみ／実装・安全性・採択未確認／NO HOST RUN。** R11の `OP_PREPARED`（prospective）と `OP_COMMIT_ACCEPTED`（retrospective）を同一視しない。`H0` source APIは調査A依存、未証明。

## 1. セキュリティ境界と唯一のauthority

**主候補の形式化（Option 2）:** actorの `privateStage(opId)` はOS隔離内でしか見えない。authoritative state は独立運用される単一**strict-serializable・durable transaction store**の `Head`, `AcceptedOperation`, `Content`, `Sequence`, `Revocation`, `Phase` のみ。すべての正式readerは独立 `PublicationGateway` を通って一つの読み取りsnapshotで `Head→AcceptedOperation→Content` の全関係を検証する。actor、CI、admin、別writerはauthoritative read/write credentialを持たず、gatewayやtransaction coordinatorのconfig/keyも変更不能とする。FS checkout、Git mirror、cache、ステージ、ログ、外部object、CI artifactは非authoritativeな**派生materialization**であり、正式観測に用いてはならない。

未検証前提：OS ACL/namespace/cgroup/LSM/FD inheritance denial + separate DB credentials、reader/writer registry、DB strict serializability+fsync/quorum、no direct DB/read-only path、trust root/clock、recovery。一般的な「DBがACID」「object storeがstrong consistency」といった機能説明だけでこの全体を満たさない。

```text
                         ┌─ offline Human IAB/HSA Signer [separate key]
                         ├─ Revocation Authority [independent write right]
                         ├─ Trusted Time/Sequence/Policy Authority
                         └─ OS Isolation / CI Privilege Operator
                               (cannot be actor)
  ACTOR + children + tools + model + env
  [nonprivileged, restricted network, no authority mount/cred]
          │ write only
          ▼
  privateStage(opId, no external effects) ── measured immutable candidate ──┐
                                                                           ▼
                                                                TRUSTED BROKER
                                                               PREPARE/COMMIT
                                                                          │
                                DB strict-serializable durable transaction │
                                  [HEAD, ACCEPTED, BYTES, SEQ, REVOCATION]◄┘
                                             │ same snapshot (read-only)
                                             ▼
                                         GATEWAY ONLY
                                             │
                                   ALL OFFICIAL READERS
                                   (humans/CI/admin/agents)
```

## 2. 提案データモデル／不変条件

`Scope`: `{authorizationId, grantVersion, exact R'/D'/P' digests, actorPrincipal, phase, attemptIndex, branch, baseRoot, allowlist path+hunk+command, denylist effects, issuedAt, notBefore, expiresAt, signerKeyVersion, isolationPolicyHash, monitorPolicyHash}`。署名付きcanonical encoding/algorithm/key rotationは将来別途固定。

`Sequence`: `(authorizationId,phase,attemptIndex, seq, opId)` について重複不可。全予約は `PREPARED`、`ACCEPTED`、`ABORTED`、`IN_DOUBT` のうち1つをもつ。`IN_DOUBT` はterminalではない。`PREPARED`を決して acceptedOperation とみなさない。

`Content`: `(contentDigest, length, canonical bytes, modes/symlinks, complete metadata)`。source revisionはすべてのpath/mode/symlink/contentsと保護対象を含む fullRoot。hardlinkデバイスファイル、special path、case-folding、Unicode canonicalization、relative path、import closureはscopeで列挙し不明なら拒否。

`AcceptedOperation`: `{opId, authorizationId, phase, attemptIndex, seq, preRoot, afterRoot, diffDigest, verifiedScopeDigest, trustedCommitOrder, txId, acceptedProofDigest, signer/verifier identity}`。`Head`: `(phase, revision, root, lastAcceptedOpId, transactionVersion, fencedWriterEpoch)`。`Revocation`: `(grantId, version, revoked, commitOrder)` を同一DB transaction domainで更新するよう設計し、外部署名者のみrevocation変更可能なACL分離を要求。`Phase`: freeze/close state, outstanding reservation set。

**INV-AP-1** Gateway-visible `Head.root=r` iff同一線形化snapshot内で `AcceptedOperation(afterRoot=r, accepted=1)` とbyte-complete `Content(r)`を結合できる（genesis rootは別の独立初期sealとして固定）。

**INV-AP-2** すべての成功した `OP_COMMIT_ACCEPTED` について `Head`/`AcceptedOperation`/`Content`/`Sequence` のすべてが **同じ durable transactionのcommit** で反映され、どの公式readerにも `accepted-only` や `bytes-only` のsnapshotがない。

**INV-AP-3** 重複opIdは**同じcanonical intent+exact actual delta**の場合のみ過去結果を読み返す。異なるpayload、stale root、古いfence、古い署名の再送は拒否。ACKの有無で2回publishしない。

**INV-AP-4** Revocation/expiry/phaseClosed/currentRoot/writerFence はcommit linearizationの実時点で整合する。revocationを別システムで受け、当該事実をDBへ遅延反映する構成は**未解決の競合**。独立Revocation Authorityによる署名更新とbroker commitを同じDB serialization orderへ接続できない限りSTOP。

**INV-AP-5** Official readers have no alternate authoritative view. `file://`/Git checkout/CI cache/direct object/CDN/direct DB replicaを正式公開とするなら**Reader Visibility FAIL**。cacheは `revision+acceptedProof` に結合しても元のGatewayだけが正式判定元。

**INV-AP-6** Source stageにexternal side effectsが一切ない。許可外ネットワーク、SaaS、host effectはtransactionでrollbackできず、一つでも到達するなら `TRUSTED_OP_BOUNDARY_PROVEN=false`。外部効果のoutboxは別の将来案件／一元的publicationと同等ではない。

## 3. 2段階state machineとlinearization

`NONE → OP_PREPARED(opId,seq,stageId) → CANDIDATE_MEASURED → OP_COMMIT_ACCEPTED(txId)` または `OP_ABORTED(tombstone)`。不明/部分crashは `IN_DOUBT` (QUARANTINE/STOP)。PREPAREDとABORTEDの記録にもdurable operation logを使うが、公式source rootを変えない。

**PREPARE prospective:** 1) Brokerがactor identityを**独立通路**で認証し、canonical署名/HSA/IAB exact scope、approved chain、phase、branch、negative effects、clock±uncertainty/expiry、revocation freshness、現存root、writer fenceを検証。2) stageが権威pathから物理/credential面で隔離され、子孫・CI・host全経路に制約が継承される証明を求める。3) 独立DBでseq/opIdを予約し、durable `OP_PREPARED` を確定した**後だけ**stageを書込可能にする。後続afterRoot, future commit timestamp, post-write receiptをここで要求しない。すべての証明が現状不明のため **現時点ではPREPARE禁止**。

**STAGE:** actorは私有一時rootにだけwrite; stage終了時Brokerがsnapshotをfenceし、canonical paths/metadata/full resolved root/diff/hunks/unknown symlinksを独立に読み直す。必要なセキュリティ判定中にactorがstageを書換えられるなら immutable snapshot copyを新たに作り、ハッシュを検証。actorの自己申告、ソフトウェアhookのログ、CIのPASSは検査の代用不可。

**COMMIT check + same transaction:** Brokerが完全ステージbytes（1案ではDBのunpublished immutable rows、2案では同一transaction内新bytes）をdurableで扱えることを確認し、DBの `SERIALIZABLE` + reader向け strict real-time ordering を持つ書込transactionを開始。`opId/seq` unique・PREPARED reservation・grant/version/revoked・trusted commit time/lease・phase Open・currentRoot==prepared beforeRoot・fencing epoch・all changed hunks・negative effects を再確認。条件とbytes検査の両方が成立した場合に限り `Content + AcceptedOperation + Head + Sequence(ACCEPTED)` を**同一transaction**で書き、durable commit。**このcommitのみ**が `L` (linearization point)。将来のpost-commit外部署名/async WORM ACKやfilesystem renameをLの構成要素にしてはならない。必要な署名はtxn内に置く検証可能な証明digestを独立authorityで成立させ、署名タイミング/保管まで具体化することが未解決。

**ACK/reader:** ACKは `L` の成功を確認した結果だけを返す。「DB commit応答不明」なら opIdで照会して同一transaction snapshotから accepted+bytes+headを独立再構成する。成功が判定できなければ `IN_DOUBT/STOP`、再commitや誤ABORTをしない。Reader gatewayは同じsnapshotで accepted recordとbytesを検証し、schema/signer/fence破損なら公開を拒否（既存正常rootに暗黙切戻ししない）。

**ABORT:** 事前に外部影響がゼロと独立証明できたstageについてのみ、予約seqに同一authorityでdurable tombstoneを書き、stageを不可視に破棄して `OP_ABORTED` とする。crash、外部effect、gateway経路の不確定、証拠欠損は `IN_DOUBT` であり実際の侵害が確認されない限り `REVOKED` ではない。

## 4. トランザクション/可視性の条件と採用不可例

**Option2最小原子単位:** 同一DBトランザクションにfull content bytes（またはDBで同一transaction内整合する全immutable chunk）のdurable insert、accepted row、head pointer、monotonic seqを含める。全readerがstrictly serializableまたはlinearizable current snapshot APIだけを通ること、checkpoint/backup/failoverが同一commit prefixであること、後からDB adminが関係を勝手に書換えられないことは未証明で、**DB採用名だけでは満たせない**。

**Option1変種:** content-addressed blob stageを先にdurableに置いても**正式公開はゼロ**。可視化は single transactional manifest pointer + accepted row のcommitのみ。blob deletion/availability/tenant ACL/key retention/remote replicasまで独立に証明できなければ、acceptedだけ先行する故障が再出現する。immutable object URLを読者に直渡しする設計は、gatewayを迂回するため不適合。

**Option3不適合:** 普通のpathへrenameしてからappend ledger（または逆順）は異なるatomic/durability domain。CRASH後の補償/rollbackは一瞬の未承認可視性を消さず、`accepted-only/bytes-only`反例で `FAIL`。filesystem snapshotsと別DBの2-phase commitを言及するだけでは、すべてのreader/writer participantが真のprepare/commitを持つ証明なしに同等でない。

## 5. trust independence と運用障害

| 主体 | 唯一の権限と分離条件 | 不許可 |
|---|---|---|
| Human signer | canonical HSA/IABに限定署名。私有鍵はoffline/KMS等のactor外、issuer/reviewer互いに監査 | actor/CIの自動署名、Brokerによる権限拡大 |
| Broker identity | fenced stage検査とcommit入力だけ、signed scope読取 | human grant/signing keyの変更、自己失効解除 |
| OS sandbox policy owner | OS user/namespace/mount/LSM/cgroup/net policyを署名運用 | actorがroot/CAP_SYS_ADMIN、policy file、host socketを保有 |
| Revocation publisher | DB内 grant statusを独立identityで更新・署名 | Brokerによる任意 un-revoke、stale cached allow |
| Clock/seq | 信頼時刻、不確実性、単調予約、ordering証明 | actor timestampでexpiry判定、split-brain seq発行 |
| DB/storage admin | durability/ACL/replica/PITR保守、breakglass独立監査 | 無監査によるhead/accepted/content個別修正 |
| Gateway/reader | 単一snapshotで`Head`+`Accepted`+`Content`確認 | FS/Git/CDN/lagged replicaを別authoritative source扱い |
| Recovery/auditor | gap-free全予約とtransaction prefix検証、WORM写し | actor所有ログで「復旧済」「証明済」を捏造 |

原子性は単一commitだけでなく**単一読取観測点**に依存する。readersが公開ゲートウェイを迂回可能なときは直ちに `FAIL`（未調査者を存在済みと断定はしない）。read-only replicaやcacheで単調可視性を壊す運用、DNS切替・failover中の旧primary、バックアップ復元時のledger/root分裂も受入不可。

## 6. 未来の独立証明リスト（未実施）

1. exact policy digestに対するactor+child全syscall/FD/mount/network/CI/admin/daemon writerの**実アクセス拒否**と継承証明。privileged actor/rootはTCB外へ置けない（TCB内に入れるなら独立管理保証が必要）。
2. **同一DB transaction** のAPI/commit WAL/fsync/strong replica failoverと同一snapshot `Head/Accepted/Content` read semanticsのvendor/version/config/事故シナリオ別書面・別レビュー。
3. 読者一覧と正式URL/mount、予備の普通path、Git clone、CI artifact、CDN/browser cache、reader cred inventoryの完全除去／ゲート外の正式readが一件でも可能ならFAIL。
4. 署名者、DB admin、Broker、OS operator、revocation、time、auditの実credential ownership、key custody、dual control、break-glass監査、証明鍵の管理不能性。
5. revocation/expiry同時競合、ACK消失、journal gap、after commit replay、2writer、failover、restore、GC、キャッシュ、ロールバック不能effectの独立最小障害評価。**調査Bでは実施しない**。
6. `H0`/G1-G2真のproducer-bindingは別調査A。R11承認/正式新規審査/各human HSA/RA/ACTIVATEが得られてもH0未証明なら `NO HOST RUN`。
