# Justice RG310 調査B — 3構成案の独立静的比較

**未署名・実装未認可・source/runtime安全性未証明。** 以下の構成案1/2/3は、R11の全体 A/B/C（Maintain STOP / Staged Authorization / Upstream API）とは**別レイヤー**のinfra/storage案。混同禁止。

| 評価軸 | 1: RO authoritative path + isolated stage + CAS blob/transactional manifest + gateway | 2: 単一独立authoritative service / DB・全writer/reader Broker化 | 3: 通常FS rename + 別ledger（対照） |
|---|---|---|---|
| 静的評価 | `CONCEPTUALLY_PLAUSIBLE / NOT_VERIFIED` | `CONCEPTUALLY_PLAUSIBLE / NOT_VERIFIED`（検証境界が最も明瞭） | `STRUCTURALLY_INCOMPATIBLE`（split commit） |
| Actor/OS | actorはauthoritative path RO/未mount。private stageのみRW、child・network・FD制限 | 同左＋actorへDB read/write credential不可 | actorが既存FSを書ける場合は必ずバイパス |
| sole promotion writer | 独立BrokerがCAS blobをpre-stageし、independent manifest txだけで公開 | 独立Broker/DB transaction accountがcontent/accepted/headを一体commit | FS writerとledger writerが異なるboundary。sole commit不存在 |
| authoritative bytesの場所 | immutable CAS blob/verified retention。actor/stageと完全別ACL | 同一strict-serializable durable DBのcontent rows（または同等証明済transactional chunks） | 普通のpath rename後のOS FS |
| atomic visibility | `acceptedRow + headPointer` 同一DB commit。CAS blob事前耐久性が必要 | `acceptedRow + Head + authoritative content + seq` 同一DB commit | ledgerとrenameどちらが先でも一方のみ先に見える |
| reader | **gatewayのみ**。blob direct URL、mount、Git checkoutは正式rootではない | **gatewayのみ**。同一snapshotでhead/accepted/contentを確認 | filesystemを直接読むreaderが見えた時点で不合格 |
| signed grant/revocation | independent signer; revocation/commit total orderをmanifest DBで保つ必要 | independent signer; Revocation rowとcommitを同一serializationに参加させ得る（authority separation別途必要） | 別ledgerが失効を知っても既にrenameされたbytesを止められない |
| failure/recovery | CAS blob lost/GC/durability・pointer stale・replica lagが特殊リスク。commit uncertainty=IN_DOUBT | DB WAL/quorum/strict realtime ordering/backup restore・large content transaction・DBA privilegeがリスク | accepted-only/bytes-onlyを常に排除できずrollbackは不十分 |
| CI/admin/other writer | CAS・manifestとgateway ACLを各人に対してfence。CIミラーをauthoritativeにしない | DB writer privilegeをBrokerに限定、DBAは別TCBと独立監査 | shell/CI/adminがroot pathを書けたら完全仲介なし |
| independent audit | WAL/accepted proofとCAS retention+WORM copyのjoin必須 | single transaction record+WORM外部監査のjoin。async WORM exportをcommit pointにしない | ledger監査できても公表bytesと同時成立の証明なし |
| strong proof needed | content addressing・blob immutability・retention・existence-before-pointer・reader-only gateway＋manifest DB strict linearizability | DB transaction durability、commit ACK、reader snapshots、ACL/credentials、lock/epoch、revocation race、replica/failover | 二つの別commitを同時に可視化する実証が必要だが普通rename+appendには原理的にない |
| 現在証明されたか | NO | NO | **仕様不適合の構造的反例**。現在の実運用で採用されているとは未確認 |

## 案1 — immutable CAS／manifest gateway

Actorにはsource authoritative mount不可。stageをtrusted stagerへ渡し、Brokerがcanonical digest/symlink/mode/actual hunksを検査後、actorに読書不能なimmutable CASに耐久保存。その後、同一transactionで `AcceptedOperation(seq/opId/fullRoot)` と `ManifestHead(root)` をcommit。GatewayはCASの直接URLを公開せず、DB snapshotでaccepted recordが確かめられたrootに限りbytesを配信。**条件が一つでも欠ければ不能**。CAS blobがDB transactionの外で削除可能なら、accepted-only不変条件の耐久保証を失う。CASのアップロード完了、独立強制retention、replica quorum、GC禁止、BLOB hash再検証と原子head更新を全て証明する必要がある。クラウド製品に一般的な機能があるだけでは足りない。

## 案2 — 強い単一transaction DB（B調査の次回評価候補）

単一のauthorityの `Content + AcceptedOperation + Head + ReservedSequence + RevocationVersion` を厳密なtransactionに固定し、唯一のcommitをLとする。readerは同じsnapshot、正式出力物以外はderived copiesと宣言。外部clock、human signer、OS policyは別責任主体で、DBに参加できない外部 revoke raceは解けたと主張しない。ストレージのサイズ・BLOB transaction上限・checkpoint/backup・WAL failover・DBAによるwriter bypassは運用課題。**一元DB自体がseparation of dutiesを証明するわけではない。**

案2を先行して仕様上検証する合理性は、accepted recordとbytesの同時可視性の論証に必要な技術境界を一つに減らせるため。これは**人間による採択の勧告ではなく、独立検査時の比較優先順位**である。案1が等価と認められる可能性は、CASの耐久性とreader fenceを独立に立証できた場合だけ。

## 案3 — ordinary filesystem rename＋別記録器（不適合）

- T1：rename成功→readerが新しいファイルを開く→プロセスcrash→ledger未commit。`bytes-only`。
- T2：ledger record先commit→プロセスcrash→rename未実施。`accepted-only`。
- T3：二つのwriterがrename上書き→ledgerが一方だけをcommit、またはACK lost/replayによる別順序。`root/seq`非整合。
- T4：DB/manifestの別トランザクションが整っても、元ファイルを直接読む人間/CI/プロセスが残ればgatewayの原子表示と一致しない。

renameを「ファイルシステム内でatomic」と言っても**異なるledger/readerの同時原子性**は意味しない。best-effort rollback/compensating actionは事前に見られたbytesを取り消せない。R11候補の要求に不適合、`FAIL/STOP`。

## 選定前に必要なOwner入力

- 誰が唯一の authoritative reader/writer となるのか、現在のGit/worktree/CI/user accessを含む全principal inventory。
- DB/CAS候補の**固定製品、version、transaction・fsync・failover・read coherence仕様**、バックアップ/復旧の条件。
- Actor/Senpi/OmO extensionとCI/adminがDB/key/clock/policy/ネットワーク経路を経由しても権限上昇不能であること。
- Human署名/失効とDB commitの強い順序、lease/clock drift上限、独立台帳とaudit sealの所在。
- 正式R'/D'/P' の承認とfresh Gate（未成立）、各B0/B2段階の署名済HSA、独立B1/RA・final ACTIVATE、調査AのH0。

**当面:** A（STOP）を維持。いかなる構成案も本成果物によって実装済、可行性証明済、正式採用済にならない。
