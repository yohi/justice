# Justice RG310 / R11 調査B — Human Trust Decision Packet（未署名）

**NOT A DECISION.** 2026-10-14 JST。R11 `UNAPPROVED`、PR #295 Task1 `BLOCKED`、Formal Fresh Gate `NOT_ESTABLISHED`、R'/D'/P' `NOT_ADOPTED`、`NO HOST RUN`、Tasks2–14 `NOT_AUTHORIZED`。この文書による委任・採択・認可・署名なし。

## 審査に渡す事実／未証明事項

1. `RG310-FEAS-002` **CRITICAL/OPEN**：固定Senpiは組込み6種filesystem policyに加えて独立 `exec` と shell process spawnの経路を持つ。調査Bが確認したのはソースAPIの存在／上限であり、構成済みOS sandbox/全principalの完全仲介は**未検証**。`02_Actor_Principal_Effect_Trust_Graph.csv`の30 nodes。
2. `RG310-FEAS-003` **CRITICAL/OPEN**：単一transactionでaccepted record、authoritative content、head、seq、grant versionをcommitしgateway-onlyで読む構成は**概念上の候補**。固定環境のstorage engine/reader/writer ACL、durability、failoverは未証明。normal FS rename + 別ledgerは原子的R11要求に**構造的不適合**。
3. `RG310-FEAS-006` **HIGH/OPEN**：独立署名・clock・revocation・audit storageの実credential/鍵/権限分離、特に失効とcommitの同じ順序がない。鍵/時刻/ledgerをactorが作れるなら不適合。
4. H0/G1-G2の固定Senpi producer-bindingは**調査A担当／未証明の外部依存**。調査Bは解決したと主張しない。H1は実ingress認証、H2はevent到達後の真偽、H3は独立記録で、H2/H3をH0へ逆流させない。
5. 38 stable states×7 axesの候補を原形保存。`IN_DOUBT/QUARANTINE/STOP`、ABORTの外部無影響立証、per-operation B0/B2-DEP/host prepの順序を保持。preflightの後だけprivate stage、commit後だけaccept。

## 人間が別途正式に判断すべき点（署名欄は全て空欄）

| Decision ID | 選択候補 | 主体（将来） | 現段階のDisposition |
|---|---|---|---|
| `B-DEC-01` | 監視対象外のauthoritative pathを全actor/child/CI/admin/別writerから隔離し、Trusted Brokerを唯一のpublish writerとするTCBを採るか | Human Architecture Decision Owner / OS+Security Owner | 未決裁。Proof missingのため作業不可 |
| `B-DEC-02` | 案1 CAS+manifest gateway 対 案2 transactional DB gateway を具体的storage/APIで評価するか（案3は除外） | Storage/Infrastructure Owner | 未決裁。案2は原子的境界が単純な調査候補に過ぎない |
| `B-DEC-03` | 署名者/監視器/OS policy/ledger/DBadmin/clock/revocationをどう法的・技術的に分離しauditするか | Security/Identity/Compliance Owners | 未決裁。署名鍵・権限構成・時計証明なし |
| `B-DEC-04` | R11のR'/D'/P'改訂候補を正式起案・fresh independent Gateへ付すか | Requirements/Design/Plan Owners | `UNAPPROVED` のまま。提案ZIPは法的/規範的権限なし |
| `B-DEC-05` | H0解明を調査A/Host API担当へ照会するか、必要なら上流Option Cを検討するか | Architecture/Host Owner | 調査Bでは解決不可。NO HOST RUNを保持 |
| `B-DEC-06` | 構成案の実アクセス拒否、DB crash/failover、revocation race、reader escapeの最小将来実験を別認可案件で計画するか | Human Plan Authorization Owner + Independent reviewer | 現権限では**禁止**。別スコープ/別HSAに限る |

**比較オプション:** Infrastructure 1 `CONCEPTUALLY_PLAUSIBLE/NOT_VERIFIED`、2 `CONCEPTUALLY_PLAUSIBLE/NOT_VERIFIED`、3 `STRUCTURALLY_INCOMPATIBLE`。R11全体のOption A（現行STOP）・B（段階的候補）・C（上流API変更）はこれと別に審査し、今はAのSTOPを維持。技術調査がBを自動採択することはない。

## 前提がすべて取得される場合でも強制される順序

`R'/D'/P' approved + formal review → independent human ADR → B0 scoped HSA → per-op OP_PREPARED/private stage/ATOMIC_ACCEPT → independent B1 P(EAF0) → separate B2-DEP HSA → DEP_START initial EAF0 latch → each B2-DEP fresh preflight/commit → DEP close → separate HOST-PREP HSA → no-runtime prep → freeze EAF_final → independent B1 final RA → separate human exact ACTIVATE → independent H0 pre-run → HOST START → H1 per-event → H2 actual result post-arrival → H3 evidence → B3-T1 review`。B1 PはR/Iを代替せず、Task1は既存32+Case A/B+既存aggregatesによるGateのみ。失効後に歴史的accepted sealを消さない一方、別新書込みを許可しない。

**STOP条件:** pre-effect path網羅未証明、独立signer/clock/revoke/ledger未証明、accepted-only/bytes-only、直接path reader、DB/reader replication曖昧、unresolved op seq、revocation/commit race、H0不明はすべて `UNKNOWN/BLOCKED/IN_DOUBT→STOP`。実証済みの不正write/forged key/bypassのみ別途 `REVOKED+STOP`、欠損だけでREVOKEDを捏造しない。

## 未署名の審査欄

- Human Architecture Decision Owner: **未署名**　判断：**未決**
- Requirements Owner: **未署名**　規範採用：**なし**
- Design/Plan Owners: **未署名**　実装・phase認可：**なし**
- Security/Storage/Time/Revocation Authorities: **未署名**　独立委任：**未確認**
- Fresh Independent Formal Gate Reviewer: **未署名**　Gate判定：**NOT_ESTABLISHED**
- 調査B作成者: 技術資料提出のみ。正式gate資格・人間承認の署名はしない。
