# 調査A パッケージ索引

**これはFEAS-001の技術調査契約であり、設計承認ではありません。** 最初に `00_READ_FIRST.md` と二つの作業契約の全文を読んでください。

主要入力：`SOURCE/02` (11-hop source reachability)、`SOURCE/03` (20 obligations)、`SOURCE/07` (8 findings)、`SOURCE/01` (full report) 、`INPUT/`の完全原本。調査AはFEAS-001/004/005を中心に、新証拠を分離して作成。調査Bのmonitor/atomicは未証明依存として扱い、調査対象外の安全認可を行わない。
