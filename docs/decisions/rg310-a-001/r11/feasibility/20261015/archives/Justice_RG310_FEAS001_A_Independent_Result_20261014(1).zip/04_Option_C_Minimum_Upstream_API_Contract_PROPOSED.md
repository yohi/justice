# Option C — Minimum Upstream Host-Origin / Message-Identity API（未採択・仕様案のみ）

**Record:** RG310-FEAS001-C-PROPOSED / 2026-10-14 JST / **対象固定pin:** Senpi `d56e6a260d9468418a39bc9120945cf98e06b840`; OmO `091728d274f20d62504b0b5e1edbc3970671dd8b`

**Status:** `SPECIFICATION_ONLY`, `NOT_IMPLEMENTED`, `NOT_PUBLISHED`, `NOT_ADOPTED`, `NO HOST RUN`。既存 `@code-yeongyu/senpi@2026.10.8` のAPIでは**ない**。新public API追加・published package検証は新pinと新Gateを要する。

## 1. 安全性を左右する最小境界

`Host producer`（モデル・Justice extension・任意のRPC clientとは異なる権限）で read attempt を開始時に発行し、そのhost固有のsource generationとincrement sequenceをimmutableに保持する。ホスト外のreference monitorだけがauthority/receipt/effectを許す。host eventだけで勝手に権限を発行する実装ではない。

### Originおよびread terminalの prospective discriminated union (TypeScript sketch)

```ts
// PROPOSED ONLY — no imports shall resolve on the current pin.
type OpaqueHostId = string & { readonly __hostMinted: unique symbol };
type ReadOriginV1 = Readonly<{
  protocol: "senpi.origin.v1";
  hostInstanceId: OpaqueHostId;
  processGeneration: OpaqueHostId;
  sessionId: string;               // durable canonical session ID, not merely RPC routing handle
  sessionIncarnation: OpaqueHostId; // new value across reopen/restart/fork
  attemptId: OpaqueHostId;         // fresh on every execution attempt, including retries
  readStartSeq: bigint;            // monotone in producer-authoritative timeline
  toolCallId: string;              // may repeat; NEVER primary proof key
  method: "read";
  canonicalTargetDigest: string;    // host resolved canonical target, not mutable plugin path
  dispatchDigest: string;           // exact resolved method and arguments
}>;
type HostReadEventV1 =
  | Readonly<{ type: "read_started"; origin: ReadOriginV1; timelineSeq: bigint }>
  | Readonly<{ type: "read_succeeded"; origin: ReadOriginV1; timelineSeq: bigint; resultDigest: string; deliveryId: OpaqueHostId }>
  | Readonly<{ type: "read_failed"; origin: ReadOriginV1; timelineSeq: bigint; errorCode: string; deliveryId: OpaqueHostId }>
  | Readonly<{ type: "read_cancelled"; origin: ReadOriginV1; timelineSeq: bigint; reason: string; deliveryId: OpaqueHostId }>
  | Readonly<{ type: "origin_invalidated"; hostInstanceId: OpaqueHostId; processGeneration: OpaqueHostId; sessionIncarnation: OpaqueHostId; timelineSeq: bigint; reason: string }>;
```

`OpaqueHostId`はTypeScriptブランド**だけでは不偽造性を持たない**。真正性はhost秘密鍵署名付きenvelope、または**peer credentials確認・OS隔離されたtrusted IPCで外部monitorが直接受信**する方式のいずれか（両案とも脅威モデル・鍵/transport所有・log改ざん耐性の独立レビュー必要）。イベント発行をExtensionAPIの任意文字列APIに任せる設計は不可。`origin`はproducer-owned readonly snapshot/manifest-bound bytesで、pluginが同じ鍵を知ってはいけない。

### 受付前・保存前 correlation (syntheticを含む)

```ts
// PROPOSED ONLY — stable intent is host-minted BEFORE any message_end callbacks.
type MessageIntentV1 = Readonly<{
  protocol: "senpi.message.v1";
  producerGeneration: OpaqueHostId;
  sessionIncarnation: OpaqueHostId;
  messageIntentId: OpaqueHostId;    // non-null for every role: assistant/toolResult/custom
  parentReadAttemptId?: OpaqueHostId; // present for a read-derived message
  toolCallId?: string;
  sourceKind: "model" | "tool" | "provider" | "synthetic" | "nested" | "custom";
  sourceEventId: OpaqueHostId;
}>;
type PreAppendMessageV1 = Readonly<{
  type: "message_end_preappend";
  intent: MessageIntentV1;
  canonicalCandidateDigest: string;
  replaceOrReject: "REQUIRED_BEFORE_APPEND";
}>;
type AppendCommittedV1 = Readonly<{
  type: "entry_appended";
  intent: MessageIntentV1;
  entryId: OpaqueHostId;           // non-null canonical SessionManager id
  canonicalJsonlRecordDigest: string;
  persistedFileIdentity: string;
  appendOrder: bigint;
}>;
```

`messageIntentId`≠ `message.id`≠ `entry.id`。APIは**一つの真正host mappingを同一intentに対して渡す**。host-generated unknown/incomplete/invalid-schema result も preappend IDを必須とし、`null`は禁止。append不可なら認証済 `append_refused` を後続terminalにし、raw messageの復活を禁止。`message_end_preappend` のapproved replacementまたはsame-role minimal fallbackを authoritative append対象とし、preappend veto失敗はfail-closed (no publish)。`entry_appended`は後段照合であり、pre-effect acceptanceの代用にしない。

## 2. 全経路 pre-effect ingress: 非交渉条件

Host implementerはproducer graphの各edgeで下記全経路を **actor-external reference monitorの認証済境界**へ公開し、いかなるauthority、receipt、evidence、trusted execution、canonical publishより先に検証する。readがhostで実行された事実と、read結果をJustice authorityへ採用する事実を分離する。

- Built-in read / tool_call and tool_result; before-hook input mutation後のcanonical resolved read targetもsigned digestに含める。
- `providerToolResults` (cursor exec/onToolResult) の独立source・hard terminal前のmessage_end。
- unknown/incomplete/invalid-schema/truncated synthetic、custom ToolDefinition、nested `executeTool`/`runToolCall`、direct SDKとprivate helper（eventsをemitしないケース含む）。
- assistant/toolResult/customの全 `message_start`, `message_end`, preappend replacement, RPC `entry_appended`、`SessionManager` writerとJSONL durable readback。
- RPC classic/multi-host, session worker, process-generation handoff/reattach/replay、in-process child、OmO task-engine producer。`sessionId`はroutingとdurableを区別。
- File/network/shell/admin/private-writer等の**全外部効果**は別のOS/runtime enforcement境界の技術設計を必要とする。本APIのみで `RG310-FEAS-002` の完全なreference monitorが存在するとは主張しない。

いずれかの枝が監査不能・host-signed delivery不能なら、その枝は**unsupported fail-closed**。対象branchの利用自体が許容されるかは別Owner決裁。monitorは actor extensionの同一process内に単なるlistenerとして置く設計では独立と認めない。

## 3. event ordering と失敗意味論

1. **START:** host validates method/resolved target before executing; mints `attemptId`、strict fresh `readStartSeq`、`read_started`を trusted ingressへ**accept**させる前にread authorityを付与しない。admission拒否時は dispatchしても「trusted originを得た」扱いにしない。必要ならread execution自体を止める。
2. **COMPLETION:** `read_succeeded`/`read_failed`/`read_cancelled`のうち **同一attemptにちょうど1件**のterminalがproducer-owned timelineで確定。after callbackのcontent差し替えは結果digestを遡及変更しない。resultとoriginを切り離して運ぶのは禁止。
3. **ABORT/RETRY:** cancel/abort/invalidationを単調sequenceでauthenticに記録。completion arrived later than invalidationなら、G1のold originで確実にDENY。tool_callId再利用やactor epoch再作成で判定を変えない。retryは常にnew attemptId。
4. **NO-DELIVERY ALTERNATIVE:** sourceが安全に旧successを届けないと主張する場合、当該branchの `read_cancelled`/`read_failed` terminal確定後の結果**非配送保証**と、その後の callback/queue/worker/restart経路が閉じている証明を要する。ただし Task1 Case AのH2 actual old-success rejection要件を満たしたことにはならない。
5. **DUPLICATE / GAP / REORDER:** 重複completion、意図不明、欠落start、out-of-order sequence、cross-epoch replay、unknown sourceKind、messageIntentId collisionはDENY。欠落／検証待ちはno-authority。streamの切断を安全なcleanup済みの証拠にしない。
6. **CRASH/RESTART:** actor-local memory map復元禁止、new processGeneration/sessionIncarnation mint必須。old `attemptId`と terminalの再playが新scopeに受理されないproofが必要。hostとexternal monitorの持続状態/外部永続化の一貫性は別設計。結果ACKと権限publishを別トランザクションにしない（`RG310-FEAS-003`未証明）。
7. **PRE/POST APPEND:** host生成 `messageIntentId` はvalidation/redaction前に固定し、mutationはintent対象を変えない。sanitation exceptionでraw原文appendを許すことは禁止。canonical persisted readbackは exact bytes and digestで照合。既存 `entry_appended` RPC通知はappend後なので単独でpreappend authorization不可。
8. **Trust-transfer:** H0能力はtrusted producer implementation+config/OS boundary+subscriber coverage+published APIの固定SHA事前照合で発行主体を限定。H1各eventでproof検証。H2旧G1成功到着後拒否は将来の**real pinned runtime**で別判定。H3は独立証拠記録サービス。

## 4. Public package API / import/export prospective sketch

- Senpi `packages/coding-agent/src/core/extensions/types.ts` に `HostReadEventV1`, `MessageIntentV1` をpublic immutable typesとして追加 **候補**。読み取り専用 `subscribeAuthenticatedReadEvent` / `subscribePreAppendIntent` のコールバックはactorがイベントmintできない**一方向ホストsource**とする。一般 extension APIの`on()`に入れる場合でもhost producerとsubscriber identityが同一processで改ざんできない外部verification protocolが必要。
- `packages/coding-agent/src/index.ts` でsymbolを **explicit** root type export。`packages/coding-agent/package.json` `exports['.']` / `./client` の新revisionを公開。`./rpc-entry` と RPC codec/typed envelopes はgeneration/intentを壊さず配送。`dist/index.js`, `.d.ts`, `dist/client/index.d.ts` のpublished artifact matchが必要。**現pinの変更禁止**。
- OmO `packages/omo-senpi` extensionと `packages/senpi-task` in-process/RpcHost/RpcProcess runnerは同じhost-authenticated provenanceを保持。task-host `instanceId`/`generation`をreadAttempt IDに置換しない。OmO compile/public package/CLI lock compat再検証。
- Justiceは upstream内部APIへの相対path deep import禁止。新 `@code-yeongyu/senpi` の正規公開exportのみで組み込み、package/lockのexact source tarball SHA, registry integrity, engine ordinal, compiler-emitted JSを確認。**build/testは今回実行していない**。

## 5. 現pin vs 仕様候補の証明可能性

| 調査軸 | fixed pinned observed | Option C proposal | 実証前提 |
|---|---|---|---|
| tool read origin | public callId/toolName/input/results | immutable host generation/incarnation/attempt/startSeq | source + compiled + runtime + external monitor |
| reused callId | 同一attemptの真正性証明なし | attemptId+startSeqで G1/G2分離 | cross-epoch replay red team |
| provider / nested | 特別経路・hook非発火経路あり | producer complete ingress enum/closed-world mediation | all branch writer reachability |
| unknown-tool message | callback/id=null、append messageId=null | stable `messageIntentId` before message_end、entry+JSONL join | token-positive actual callback/append/readback |
| authority/effects | arbitrary actor pluginsやRPCに independent reference monitor未証明 | independently authenticated host origin + external monitor | `RG310-FEAS-002` 別調査 |
| atomic publication | Senpi transcript appendはJustice transactionではない | separate trusted one-transaction accept+publish design | `RG310-FEAS-003` 別調査 |
| packages | root/index types and OmO workspace dependency pin observed | published exact API and new pin/lock/ABI | staged owner approval + independent builds **later only** |

## 6. 最小上流変更候補（実装指示ではない）

1. `packages/agent` executor/stream provider → producer attempt registry + read start/terminal/no-delivery trace semantics。
2. `packages/coding-agent` `AgentSession` → immutable origin translation、extension event schema、`_processAgentEvent` の message preappend intent、`SessionManager` binding。
3. `packages/coding-agent` RPC schemas/writer/client → signed/authenticated `origin` / `messageIntentId` field propagation、fail-closed old readers feature negotiation。旧protocol黙示fallback禁止。
4. OmO `omo-senpi` / `senpi-task` host/in-process/task producer → original producer envelope propagation or deny-on-unsupported、package pinned dependency更新は別Owner承認後。
5. Ref Monitor/storage（**Senpi upstreamだけでは済まない**）→ external identity validation, all writers enforcement, transactionally linked accepted-record+visible bytes。

**Integration change gate:** upstream source SHA + owner provenance + release binary/tarball SHA + pinned new version/lock + TypeScript public export + compiled generated JS + RPC protocol-version capabilities + exact equality/revocation tests + no actor forgery + negative provider/nested/unknown replay tests + formal owner R'/D'/P' approval + fresh independent Gate + separate human phase HSA。さらにPR295の canonical32/CaseA/CaseB/B001/B002 を**新pinで再実証**しなければならない。以前の31/32を再利用してTask1 PASSにしない。

## 7. 承認不要な結論と承認を要する行為

この文書が確定するのは **仕様案の提示**だけ。正式Requirements採択、Design/Plan fix、変更コミット、upstream PR、署名、B0/B1/B2/RA/ACTIVATE、HOST RUN、Task1 PASSはいずれも**行わない**。正式Owner・新規独立reviewer・human Architecture Decision Authority に引き渡す材料である。
