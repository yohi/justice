# RG-310-A-001 / FEAS-001 — 調査A 新規独立 Source/API 到達可能性報告

**実施日:** 2026-10-14 JST / **方式:** pinned immutable GitHub source の読み取り専用静的調査 / **本書の地位:** technical investigation, **NOT authority** / **署名:** なし

## 1. 結論（互いに独立した判定軸）

| 判定軸 | 判定 | 意味 |
|---|---|---|
| `CURRENT_FIXED_PIN_H0_VERDICT` | `NOT_PROVEN` | 調査した current fixed Senpi/OmO の公開 extension・RPC event・host task path から、actor-external な真正 read producer identity と完全な pre-effect ingress の組を証明できない |
| `PUBLIC_API_SUBVERDICT` | `EXAMINED_PUBLIC_API_LACKS_PROOF` | 対象 public `tool_call`, `tool_result`, `tool_execution_*`, `message_end` と root exports に host-minted read attempt/readStartSeq を含む binding がない |
| `EXHAUSTIVENESS` | `PARTIAL_WITH_EXPLICIT_UNEXAMINED_BRANCHES` | private AgentSession/SessionManager と RPC/OmO 代表経路を独立に確認。ただし全拡張・全 provider・全 RPC command・全 package compiled artifact・全非公開 caller を閉包検査していない |
| `ALL_FIXED_PIN_ROUTES_STRUCTURALLY_IMPOSSIBLE` | `NOT_ESTABLISHED` | 「調査した経路に証明がない」と「すべての経路が不可能」を混同しない |
| `POSSIBLE_ON_PIN` | `NOT_PROVEN` | 新たな信頼可能な既存の host-private producer→exported complete ingress が立証されるまで肯定不可 |
| `OPTION_C` | `PROPOSED_ONLY` | fixed pin に新APIが存在するという主張ではない |

**実務判断: A/STOP 継続。** B のH0事前保証なしにhost開始・権限・エビデンス合格を与えない。C上流APIの最小仕様を別文書に提示。Option Cを選んでも independent monitor / one-transaction publication は本調査では証明していない。

## 2. 原本・SHA256・自力照合

- 外側 handoff `Justice_RG310_FEAS001_Source_API_Independent_Handoff_20261014(1).zip`: requested / recomputed SHA256 **`a68e1a910a145f3660192b065400867285b0be9a0543810af601c6a816eae8a1`**, 23 members; ZIP CRC 全件OK、内部SHA256SUMS **22/22**、MANIFEST のfile hash/bytes **21/21**、result 原本と `SOURCE/` のbyte比較 **12/12**。
- R11 architecture original: `1df24d4250132a3df1bc2c4d39b53baebbe1b1d8ad8060862c0531743601d185` (CRC OK, 8/8 inner SHA256SUMS)。
- R11 feasibility-result original: `b879c369cacdda126caf22b0633af137187d5fa4920a615dd232a9d58527ef99` (CRC OK, 12/12 inner SHA256SUMS)。
- R11 technical-review original: `bd1abee742d1a495f7e8a7bed9e2fb7a99f8358efbf5f835451e20cff67fc14b` (CRC OK, 3/3 inner SHA256SUMS)。
- original feasibility-handoff: `bbc40f2712fc0e016807648825c68481ad214fcb6b3cf6961aa33ba05cac095b` (CRC OK, 15/15 inner SHA256SUMS)。
- `00_READ_FIRST.md`, `01_SHARED_STATIC_WORK_CONTRACT.md`, `02_A_SOURCE_API_FULL_WORK_CONTRACT.md` を全文読了。上流にアクセスしたのはGitHub read-only connector の `fetch_file` を**常に指定完全commit SHA**とセットにした静的source取得のみ。先行Feasibility成果を結論の代用品にしていない。証跡詳細 `07_Input_Integrity_Independent.json`。
- 固定 justice: PR295 `c428041dfb5779b6b6dc8db7bf14928225a00373`; PR325 R11 archive `74cac6f61946a30583e61e4004ae6f66a0abdd76`; approved R/D/P `8a2e4f1536e9cad499ee7e9d996ff163df132fd4`。本調査は３者の承認状態を変更しない。
- 固定 Senpi: `code-yeongyu/senpi@d56e6a260d9468418a39bc9120945cf98e06b840`（以降S）；OmO: `code-yeongyu/oh-my-openagent@091728d274f20d62504b0b5e1edbc3970671dd8b`（以降O）；Superpowers: `obra/superpowers@8ca22dba9a94f28898bbce59f2537ff4d87c747d` は手法owner referenceであり今回のsource全枝未取得。

## 3. 主要な一次ソースの到達グラフ（観測事実）

以下のpathの前に付く `S:` / `O:` は上記固定commitであり、全anchorは `repo@SHA:path#Lx-Ly` を指す。機械的な1-hop単位の評価は `02_Source_Producer_Ingress_Reachability_Matrix.csv` に記載。

**通常tool始動:** `S:packages/agent/src/agent-loop.ts#L1008-L1058` で `resolveCallTool` → `tool_execution_start` → `prepareToolCall` → `executePreparedToolCall` → `finalizeExecutedToolCall` → `createToolResultMessage` → `message_start/message_end`。`S:packages/coding-agent/src/core/agent-session.ts#L1640-L1723` は `preflightToolCall` を `tool_call`、事後hookを `tool_result` に写像し `toolCall.id`、args/content等を渡す。一方 `S:packages/coding-agent/src/core/extensions/types.ts#L1711-L1820` に公開された `toolCallId`, `parentToolCallId`, input/content/details/usage/isError は immutable host-run incarnation/attempt/readStartSeq ではない。before-toolのinputは可変 (`types.ts#L1750-L1770`)。`tool_execution_*` 型にも同identifiersはない (`types.ts#L1571-L1600`)。

**async/abort:** `S:packages/agent/src/agent-loop.ts#L1344-L1435` は abort時 `Promise.race` で `ABORTED` に決着させ、放置された tool promise は catchされる。通常経路で旧成功が確実に後日emitされると主張することは**誤り**。ただしこれは**H0となる外部producer identity証明ではない**。`S:packages/coding-agent/src/core/agent-session.ts#L2664-L2733` は各 event にsource `signal` を保持して非同期キューへ渡すが、公開resultには `signal`由来の真正attempt IDは流れていない。private run の signal identity と public result attestation は別物。

**provider result:** `S:packages/agent/src/agent-loop.ts#L598-L655` で provider `onToolResult` は `providerToolResults.push(result)` する。`#L293-L335` ではその結果を **通常 tool_result hook が保証されない経路**で `message_start/message_end` し、hard-terminalチェック前に context に加える。故にtool_result hookのみの署名・sanitizationでは全結果前段を代表しない。providerの別実装と`onToolResult`登録全件まで網羅していない。

**unknown/incomplete/invalid-schema:** `S:packages/agent/src/agent-loop.ts#L1200-L1345` では missing tool/incomplete/validation error が immediate synthetic error result となり得る。`#L1509-L1525` は `{role:'toolResult',toolCallId,content,isError,timestamp}` を構成して `message_end` に流す。そこにhost-minted `messageIntentId`/attemptはない。`S:packages/coding-agent/src/core/agent-session.ts#L3620-L3688` は `message_end` のreplacementを同一objectへコピー可能だが、type eventは `{type,message}` のみ (`types.ts#L1564-L1570`)。

**append / persistence:** `S:packages/coding-agent/src/core/agent-session.ts#L3077-L3141` は extension callback → listener → `SessionManager.appendMessage(event.message)` の順。`S:packages/coding-agent/src/core/session-manager.ts#L1616-L1633` は **append時に**新しいentry.idを生成し persist/commitする。`S:packages/coding-agent/src/core/agent-session.ts#L2198-L2209` の `_emitEntryAppended` は `rpc` のみ・append後にentryを公開。したがって *後置entryIdをpreappend synthetic messageIdに同一視できない*。`session-manager.ts#L1523-L1547` の `_persist`→`_commitEntry` もJustice固有の受理・公開同一transactionを提供するとの証明ではない。

**RPC:** `S:packages/coding-agent/src/modes/rpc/rpc-mode.ts#L30-L70` は routing handle `sessionId`、durable `state.sessionId`、host `instanceId/generation` を**異なる意味**として文書化。 `S:packages/coding-agent/src/modes/rpc/rpc-types.ts#L1-L110` の command unionと `#L640-L655` のhost世代はあり、`S:packages/coding-agent/src/modes/rpc/session-event-fanout.ts#L1-L113` はfanout/replayを持つ。しかし sampled RPC payload では read attempt と G1/G2 completion のproducer bindingがない。full command→event→client mappingとraw wire securityは未閉包。

**OmO:** `O:packages/omo-senpi/src/components/task/host-prewarm.ts#L1-L130` は session開始/最初の入力にhost warmingを接続。`O:packages/omo-senpi/src/components/task/engine-runners.ts#L1-L118` は `InProcessRunner`, `RpcHostRunner`, `RpcProcessRunner` を選択できる。`O:packages/senpi-task/src/runners/in-process.ts#L1-L90` はchild sessionを管理。`O:packages/senpi-task/src/runners/rpc-host/session-client.ts#L1-L122` は1 client/child, routing handleはephemeral、instanceIdはliveness情報。`O:packages/senpi-task/src/runners/rpc-host/session-wire.ts#L80-L100` の受信判別は`sessionId`によるrouting filterと`type: string`の型ガードであり、暗号認証/独立read producer証明ではない。`O:packages/omo-senpi/src/components/task/event-bridge.ts#L1-L115` はtask lifecycle/reconcile wiringだが `read_started` producer monitor とは別である。OmOの task completion はJusticeによるtrusted workflow `read(X)`のorigin宣言と同値でない。

**公開/export対比:** `S:packages/coding-agent/package.json#L1-L36` は package root, `/bun-runtime`, `/rpc-entry`, `/client` を公表し、主に`dist`を配布する。`S:packages/coding-agent/src/index.ts#L100-L210` は `ExtensionAPI`, `MessageEndEvent`, `ToolCallEvent`, `ReadToolCallEvent` を再exportするが、今回確認した型にはpre-effect trusted-origin handleがない。`O:packages/omo-senpi/package.json#L1-L94` のroot/extensionと `O:packages/senpi-task/package.json#L1-L90` はprivate workspace exports と Senpi `2026.10.8` peer/dev pinを宣言。**package export存在・source型がある・npm配布物のコンパイル済み実装がある、は各々別立証**。OmO peerDependenciesは公開するSenpiのorigin proofを自動獲得しない。

**Justice lock軸:** `yohi/justice@c428041d:package.json#L1-L105` に既存 `@code-yeongyu/senpi` dependencyの宣言は見当たらず、`bun.lock#L1-L36` workspace宣言も別の既存依存を示す。`bun.lock` の**全パッケージ・全registry解決値の否定検査は未完了**。既存lockのGit blobは`6a7f961d68eaef8d42a1e22609528dadf3a5d438`、packageは`8e154e09d0c6253d104b60e72208c5ff2a3478b4`。新APIは将来のnew pin/lock/package/compiled checkを要求し、今回の静的ソース確認をnpm実行実証と呼ばない。

## 4. 安全性の反例を先に置く

1. **同一callId:** G1 `read(X)`が未完了→abortまたはrestart→G2 `read(X)`が同じcallId→G1旧successがG2 observerに遅着。2事象は公開 `{sessionId?,toolCallId,method,input,content}` では衝突可能。private current signal/actor-owned epochに頼るなら *producerとattemptの同一性の証明*が欠落。攻撃の**現実到達**は本静的調査で未実証、しかしH0事前保証は成立しない。詳しくは03。
2. **provider・nested・synthetic:** 通常 `tool_result` のみ通して `providerToolResults`/`runToolCall` nested/custom/unknown/schema-invalidを漏らす。`S:packages/agent/src/agent-loop.ts#L293-L335,#L1370-L1402` と `types.ts#L1711-L1726,#L2435-L2452`。nested call IDは`parent/n`でtranscriptに同じ形で現れない (`types.ts#L1711-L1722`)。完全検査できない一経路があれば H0不可。
3. **postappend ID代用:** unknown-tool `message_end` で `message.id=null`、後の`entry_appended`でも `entry.message.id=null`。`entry.id`は別の新規キー。`null == null`を同一性証明と呼ぶ偽陽性。原本 `yohi/justice@c428041d:docs/reports/omo-native-v5.1.17-senpi-2026.10.8-contract-evidence.md#L487-L522` は実観測として両nullを記録。
4. **Case A negative→positive混同:** `G1`が届かなかったことは `preFailureReadResultRejected` の成功ではない。Case B `PROVEN`は独立control。固定Senpiのhard-terminal, abort releaseはCase Aの5件を充足しない。

## 5. 固定PR295原本の状態維持

`yohi/justice@c428041dfb5779b6b6dc8db7bf14928225a00373:docs/reports/omo-native-v5.1.17-senpi-2026.10.8-contract-evidence.md#L425-L557` を独立読取。

- canonical **31/32 PROVEN**, unknown-tool canonical1件 **BLOCKED** (`messageId = null` pre/post、token-positive removalも未観測)。
- Case A **BLOCKED**: `cachedActivationReissueRejected`, `preFailureReadResultRejected`, `freshReadReauthorized`, `lateAssistantSanitized`, `lateToolResultSanitized` の5つは未観測。
- Case B **PROVEN**（Case Aの代替にしない）。`RG-310-B-001 BLOCKED`, `RG-310-B-002 NOT_PROVEN` はcanonical32の分母外。required runtime/safety aggregates trueでもTask1総合 **BLOCKED**。
- Source上のabort/hard-terminalはCase Aの実際のsuccessful G1 late arrivalを**保証するとも禁止するとも一律には主張できない**。当該positive runtime predicateの構築可能性は upstream ownerによる証跡を要する。

## 6. H0/H1/H2/H3を混ぜない

`H0` = 起動**前**にhost origin・all-ingress・non-actor enforcementを仕様・source・配置で確証する事前能力保証。`H1` = 実際に届く個々のイベントのoriginal generation/attempt authentication。`H2` = 旧G1 resultが**実際に**到達した後拒否された runtime結果。`H3` = 独立永続証拠。H2/3をH0の代用入力にしない。この調査はH0のsource不足の特定まで。host/runtime/IPC/Storage検証を行っていない。

## 7. 未調査枝・監査可能な残件

1. Senpi private `agent-session-runtime.ts`, `agent-session-services.ts`, `agent-abort-provenance.ts`, `agent-settled-delivery.ts`, `external-admission.ts`, `nested-tool-calls.ts`, 全 `extensions/runner` 構築/dispatch、`sdk.ts`の全factory/constructor経路、SessionManager `appendEntry` external transportとcontext entry mapの全使用箇所。
2. Senpi RPC全 `multi-session-host`, `session-worker`, `session-event-writer`, `socket-event-fanout`, `connection-handler`, `rpc-client`, `rpc-types`後半／全codec、`get_protocol_info`能力、セッションattach/park/handoff/replay provenanceの全結合と全 inbound/outbound union。
3. 全provider `cursorExecHandlers` producer、`providerToolResults`全操作、`message_end`前に bypassする追加provider、nested/custom/unknown/incomplete/invalid-schemaの全execute/append branch、retries/compactions/shutdown/hard-terminal全例。
4. OmO `senpi-task` RPC host/session transport/client/manager/runnersおよび direct in-process、Desktop Thread、custom task DSL、plugin extension hooks の全callsite、task lifecycle reattachとproducer authority。OmO `bun.lock`全解決状態・公開npm tarballの実ファイル/ABI、Senpiビルド済み`dist`。
5. fixed Superpowers のmethod `read`使用・相互運用owner経路、Justice runtime package dependency slice とすべての lock key／published buildの完全同値。

**上記は`NOT_EXAMINED`、不存在と判定していない。** OmO/Senpiの特定ファイルを静的閲覧済みとしても、これらのtransitive call graphが閉じたと主張してはならない。

## 8. 次に取得すべき証拠とSTOP

- **B検証継続の必要条件:** 未調査枝を閉包し、現pinでhost-minted immutable attempt＋同一G1 completion＋pre-effect全経路仲介が**公開サポート契約**かhost-external trusted adapterとして提供できることを一次コードと脅威モデルで提示。独立red-teamがG1/G2 alias・unknown ID・provider bypassを反証試験に設計。host/runtime実行には**別権限**が必要。
- **C候補へ移行する条件:** 上記が現pinで証明できなければ `04_Option_C_Minimum_Upstream_API_Contract_PROPOSED.md` の仕様を upstream ownerへ提案し、新public exports、新pin/lock、R'/D'/P'の正式人間承認、新しい独立 Gate、別 scoped HSA、Task1 actual pinned runtime再実証を要求。これはC採用決定ではない。
- **別owner依存:** 参照モニタの完全mediation (`RG310-FEAS-002`) と trusted one-transaction accepted+publish (`RG310-FEAS-003`) は調査AのH0解消と独立のCRITICAL OPENである。

**不変状態:** R11 `UNAPPROVED` / Formal Fresh R11 Gate `NOT_ESTABLISHED` / R'/D'/P' `NOT_ADOPTED` / PR295 Task1 `BLOCKED` / `NO HOST RUN` / Tasks2–14 `NOT_AUTHORIZED`。GitHub write、source/test/evaluator/Requirements/Design/Plan変更、build/test、署名・実装 **一切なし**。組織上の正式独立reviewer/Owner資格は未取得。
