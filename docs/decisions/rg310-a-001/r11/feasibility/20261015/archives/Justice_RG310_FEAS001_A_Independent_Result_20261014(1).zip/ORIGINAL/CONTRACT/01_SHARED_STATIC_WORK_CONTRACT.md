# 共通作業契約 — Justice RG-310 / R11 静的実現可能性 2026-10-14

## 権限と禁止事項

- この作業は **新規・独立した技術調査（読み取り専用、静的）**。R11著者、既存Feasibility調査者、旧reviewer、Requirements Owner、設計採択者、実行Gate signatory とは役割分離する。別AIセッションは技術レビューの役割分離の助けとなるが、**組織・法的な独立性や正式Gate reviewer資格、署名は証明しない**。
- 禁止：GitHub push/commit/branch/PR変更、既存設計・計画・Requirements・fixture・evaluator・コードの変更、依存install、build、test、SDK/HTTP実験、任意のHOST/RPCプローブ、プロセス実行、PR295 Task1の再走、B0/B1/B2/HSA署名・RA発行・ACTIVATE・実装。ローカルでZIP整合性、静的読取、表・差分比較、レポート作成のみ許可。
- 外部GitHubを利用する場合、**固定SHA/タグのexact sourceに対する読み取り専用の取得のみ**。取得失敗を別branchの近似ソースで置き換えない。必要なソースが確認できなければ `NOT_VERIFIED` とする。
- R11 proposalとPR325は**未承認の参考候補**。既承認 Requirements / Design / Planの改訂・採択・実行許可ではない。調査の終了判定は形式的Gate採択に結び付けない。
- `H0` はRUN前の actor-external/host-source capability **事前保証**、`H1` は各イベントの本来のgeneration/attemptとingress認証、`H2` は旧G1結果が実際に到達した後の個別真偽検証、`H3` は独立の証拠保存。`H2`/`H3`を`H0`の事前入力にせず、source閲覧を実際のruntime Rと称さない。
- 変更不可のTask1状態：canonical **31/32 PROVEN**、Unknown-tool canonical1件 `BLOCKED`、Case A `BLOCKED`（5未観測）、Case B `PROVEN`、Task1総合 `BLOCKED`、B-001 `BLOCKED` / B-002 `NOT_PROVEN`（両者ともcanonical 32の外）、required runtime/safety aggregates true。元evaluator変更禁止。`R`実runtime/`P`compiled/`I`本番統合は相互代用不可。
- R11 technical status `ACCEPTABLE_AS_STATIC_CANDIDATE`、Formal Fresh Independent R11 Gate `NOT_ESTABLISHED`、R'/D'/P' `NOT_ADOPTED`、Actor-external monitor/atomic publication/H0 `NOT_PROVEN`、`NO HOST RUN`、Tasks2–14 `NOT_AUTHORIZED` を維持する。

## 固定Baseline（変えてはならない）

| 種別 | 参照 |
|---|---|
| PR295 Evidence HEAD | `yohi/justice@c428041dfb5779b6b6dc8db7bf14928225a00373` — PR https://github.com/yohi/justice/pull/295 |
| approved R/D/P | `yohi/justice@8a2e4f1536e9cad499ee7e9d996ff163df132fd4` |
| R11 archival HEAD | `yohi/justice@74cac6f61946a30583e61e4004ae6f66a0abdd76` — PR https://github.com/yohi/justice/pull/325 |
| R11 proposal ZIP SHA256 | `1df24d4250132a3df1bc2c4d39b53baebbe1b1d8ad8060862c0531743601d185` |
| original R11 feasibility result ZIP SHA256 | `b879c369cacdda126caf22b0633af137187d5fa4920a615dd232a9d58527ef99` |
| fixed Senpi | `code-yeongyu/senpi@d56e6a260d9468418a39bc9120945cf98e06b840` |
| fixed OmO | `code-yeongyu/oh-my-openagent@091728d274f20d62504b0b5e1edbc3970671dd8b` |
| fixed Superpowers | `obra/superpowers@8ca22dba9a94f28898bbce59f2537ff4d87c747d` |

## 受領→証拠→出力の順序

1. `INPUT/`の添付ZIPのSHA256・CRC・内部 `SHA256SUMS` を独立検証する。`SOURCE/`に抽出したファイルと入力ZIP原本が一致することを比較する。検証不能なら理由、対象、expected/actual、処理可否を明記。**同梱報告の自己検証記述だけを検証済みと認めない**。
2. `SOURCE/01_Independent_Static_Feasibility_Report.md` と元result ZIP全12成果物（とくに02・03・04・05・06・07・08・09）、R11 `01`/`04` の**必要な全文**、Task1 evidence最終節、固定SDK内の関連sourceを読む。初回レポートを再提出するのでなく、新しい証拠・反例・限界を調べる。
3. 一次sourceに正確な `repo@SHA:path#Lx-Ly` のanchorを必須とする。**観測済み事実／設計上の推論／調査不足／推奨**を列で分け、反例を先に置く。
4. 成立の主張は対象経路の網羅性・誰がidentityをmintするか・actorによる偽造可能性・事前強制位置・crash/replay/restart時不変性で裏付ける。**未調査を `INFEASIBLE` と断定しない。** API名の存在だけで `FEASIBLE` としない。
5. 新たなfindingsは `RG310-FEAS-001..008` と衝突しない独自識別子を付け、既存Findingは source/evidenceが変わらない限りOPENを維持する。
6. Outputはすべて提案・静的証拠と明記し、owner署名欄は未署名、GitHub変更なし、Host未実行を明記する。成果をPR295/325へ書き込まない。

## 納品物の共通条件

- 日本語の新規報告書（結論、exact inputs/ハッシュ、照合方法、発見、反例、限界、依存判断、STOP）
- machine-readable一次根拠マトリクス（CSV）、新規/継続finding register（CSV）、調査未済sourceのリスト、Option A/B/Cの人間向け短い*未署名*判断資料
- 原本比較できるSHA256SUMSとMANIFEST。`PASS`ラベルはZIP完全性とruntime安全性に共用しない。
- 自身で判定者や正式reviewerを兼任したと主張せず、別の新規独立再審査へhand offできるようにする。
