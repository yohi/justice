# READ FIRST — 受領後の作業順

1. 外側のZIP SHA256を依頼文に示された値と比較（SHAは同梱不能なので外部に記載）。CRC、内部SHA256SUMS、MANIFESTを独立計算。
2. `INPUT/`内の4原本ZIPもSHA256、CRC、内部SHA256SUMSを独立再計算。`SOURCE/`の原本派生資料のbyte consistencyを確認。
3. `01_SHARED_STATIC_WORK_CONTRACT.md` と `02_...FULL_WORK_CONTRACT.md` を全文読んでから調査開始。独立性や権限を自動獲得しない。
4. 既存結果を受け入れるのでなく、固定GitHub SHAsの一次コードを独立取得して source graph/attack evidence を記録。R11とR11 Feasibilityは未承認input。
5. `NO HOST RUN`。GitHub/実装/ビルド/テスト/評価器/承認状態は変更しない。できない部分は `NOT_VERIFIED` で明示。
6. 必須提出物を作成し、証拠と判断・提案を区別した新規独立審査handoffにする。
