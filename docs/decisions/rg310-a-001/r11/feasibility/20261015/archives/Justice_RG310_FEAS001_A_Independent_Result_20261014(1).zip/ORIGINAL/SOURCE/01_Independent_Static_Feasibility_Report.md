# Justice v5 / RG-310-A-001 / R11 — Independent Static Feasibility Report

**審査日:** 2026-10-14 JST
**役割:** 新規静的調査者（技術的独立評価。組織・法的独立性を示す人間の署名は未取得）
**判定:** **`INDETERMINATE_REQUIRES_FURTHER_STATIC_EVIDENCE`**（H0 は確認できず B 実行不可。固定 pin の公開経路全体を構造的不可能と断定するには private/RPC/host producer 網羅調査が不足）
**Formal independence:** `FORMAL_INDEPENDENCE_NOT_ESTABLISHED`
**Formal Fresh R11 Gate:** `NOT_ESTABLISHED` / **R11:** `UNAPPROVED` / **R'/D'/P':** `NOT_ADOPTED`
**実行状態:** `NO HOST RUN`, `OP_PREPARE_ALLOWED=UNKNOWN/BLOCKED`, `B0/B1/B2/RA/ACTIVATE/HOST NOT_AUTHORIZED`, `Tasks2–14 NOT_AUTHORIZED`.

## 1. 方法・原本・完全性

配布 ZIP: SHA-256 `bbc40f2712fc0e016807648825c68481ad214fcb6b3cf6961aa33ba05cac095b`; CRC PASS; internal SHA256SUMS 15/15 MATCH。内包4原本 ZIP は CRC PASS・所定 SHA 一致・内部 manifest 全件一致（Proposal 8/8, review 3/3, diff 3/3, history 12/12）。独立した Python stdlib の ZIP/sha256 静的検証でありプロジェクトの build/test/runtime は実行していない。`01_FULL_WORK_CONTRACT.md` のSTOP・証拠クレーム規則を全採用。

原本 ZIP SHA-256:
- R11 architecture `1df24d4250132a3df1bc2c4d39b53baebbe1b1d8ad8060862c0531743601d185`
- R11 independent technical review `bd1abee742d1a495f7e8a7bed9e2fb7a99f8358efbf5f835451e20cff67fc14b`
- R10→R11 complete diff `797bb62ff36a0df9ff76e532738ff015bae525c7c87edde76a6752bfc93b9db6`
- Historical handoff `6d4009a0272539b22707607f4e32e931829eda83e3e6ec52aa748c51dd2fc591`
- R11 technical report SHA `32c74276d7e9f9690e0eefae91b35173fbe63e8e8c3b225f0497babdc54c0a3d`.

GitHub connector から **immutable commitを明示**して独立取得し、Git blob を比較した：

| 対象 | pinned commit | Git blob (MATCH) | 適用範囲 |
|---|---|---|---|
| Approved Requirements | `8a2e4f1536e9cad499ee7e9d996ff163df132fd4` | `d335c34b747cafd6ac3b2e81d710fdcc61fb777e` | `docs/superpowers/requirements/2026-09-27-justice-v5-requirements.md` |
| Approved Design | 同上 | `64acdf177d2fd207861eb477af7c8a265eed71e8` | `docs/superpowers/specs/2026-09-27-justice-v5-semantic-control-plane-design.md` |
| Approved Plan | 同上 | `10dfba4c199feff19ee387b244daf6c0fd30d5e3` | `docs/superpowers/plans/2026-09-28-justice-v5-semantic-control-plane.md` |
| PR295 final evidence | `c428041dfb5779b6b6dc8db7bf14928225a00373` | `7df0887402d1d4eaf34a09e44213cf75b630b813` | 末尾 `Final Task 1 evidence gate repair` |
| PR325 preservation index | `74cac6f61946a30583e61e4004ae6f66a0abdd76` | `6400f14c2c9ef1ea02301690ec9a3646a4e2e43f` | unapproved archive |
| package.json at PR295 | evidence pin | `8e154e09d0c6253d104b60e72208c5ff2a3478b4` | declared deps and scripts |
| bun.lock at PR295 | evidence pin | `6a7f961d68eaef8d42a1e22609528dadf3a5d438` | lock source |

Other verified upstream pinned source Git blobs: Senpi `types.ts` `278432ae2bb98098ef69ecdea7d508bb7aa59bc2`, `agent-session.ts` `2ba84efe75090fb9b34562fba41048233367a260`, `agent-loop.ts` `6c2e6983e7f9e64ad8d3c1c8c17eb47785050fe5`, `src/index.ts` `99f0c8e2bfbb51a3ec17e9df81c05c0ad332304d`, `packages/coding-agent/package.json` `28270015f9a3db3b561da6831bdf1eb9f6bd3949`. OmO fixed host-prewarm `f261b69c05646b3bfa5e8206e7bd6a9bea6672f5`; Superpowers executing-plans pinned source `49077ad961268a840d7dcb5d8c5d06c46fc276ae`. `tsconfig.json` at fixed evidence commit: Git blob `c9894f496abc59587f0dd39cffe57a7cc6c34a3a` **independently MATCHED**。現在の PR state/head のライブ API は別途照合できなかったため、Draft/OPEN は引継ぎ上の前提であり独立現在値としては未検証。

## 2. 総合判定（技術的範囲）

固定 Senpi public `ToolCallEvent`, `ToolResultEventBase`, `MessageEndEvent`, `ExtensionAPI`, `ExtensionContext`, package root export において **producer-bound で host-minted な G1/G2 の read start/completion generation/attempt と complete ingress を対で渡す契約を確認できない**。実際の `agent-session.ts` が hook を生成する箇所と `_processAgentEvent` persistence は存在するが、callback を受けた今の session/signal は古い結果の独立認証に十分という証明がない。したがって**Option B の現固定 public extension path の H0 実行前証明は成立していない**。

`INDETERMINATE_REQUIRES_FURTHER_STATIC_EVIDENCE` は **調査済み public extension path で G1/G2 非偽造 binding が未確認で、別経路の不存在までは証明していない**という限定技術判定。Senpi の全内部/private/RPC reachable interface の網羅不能性を留保する。新しい、検証済み public binding を現在 pin 内で発見すれば再判定、上流 API 追加なら Option C として別 baseline・別 Gate。参照 monitor と atomic publication は H0 とは独立して未構築の P0 である。R11文章が非循環でも B 実装の安全性は直ちに得られない。

**意思決定上の方向:** 現状 A（STOP）を維持し、Option C の最小 API 公開または同等の真正 producer-binding を H0 の先行ブロッカーとして調査・仕様化する。同時に actor-external monitor + atomic acceptance/publication を具体的サービス方式として設計評価する。B の自動採用・先行実装は推奨しない。

## 3. F-01：真正 result-origin / stale G1-G2

| Node | source pin/line | confirmed | critical gap |
|---|---|---|---|
| G1 read tool_call | [types.ts L1711–1780](https://github.com/code-yeongyu/senpi/blob/d56e6a260d9468418a39bc9120945cf98e06b840/packages/coding-agent/src/core/extensions/types.ts#L1711) | public `tool_call`, `toolCallId`, `toolName`, args | per-attempt host-minted identity absent in verified event type |
| Pre/post result bridge | [agent-session.ts L1680–1723](https://github.com/code-yeongyu/senpi/blob/d56e6a260d9468418a39bc9120945cf98e06b840/packages/coding-agent/src/core/agent-session.ts#L1680) | host creates public `tool_result` with callId/content | no G1 producer lineage carried |
| Abort/retry queue | [agent-session.ts L2664–2733](https://github.com/code-yeongyu/senpi/blob/d56e6a260d9468418a39bc9120945cf98e06b840/packages/coding-agent/src/core/agent-session.ts#L2664) | event queue preserves a source `signal` internally | no verified end-to-end host origin binding to every tool result |
| G2 read | [ExtensionAPI L2198–2294](https://github.com/code-yeongyu/senpi/blob/d56e6a260d9468418a39bc9120945cf98e06b840/packages/coding-agent/src/core/extensions/types.ts#L2198) | public hooks, session context | no named `read_started`, no authenticated generation binding in examined types |
| Provider result bypass | [agent-loop.ts L302–315](https://github.com/code-yeongyu/senpi/blob/d56e6a260d9468418a39bc9120945cf98e06b840/packages/agent/src/agent-loop.ts#L302) | providerToolResults `message_end` before terminal finish | tool_result is not the only result entry path |
| message end | [types.ts L1564–1570](https://github.com/code-yeongyu/senpi/blob/d56e6a260d9468418a39bc9120945cf98e06b840/packages/coding-agent/src/core/extensions/types.ts#L1564), [session.ts L3620–3688](https://github.com/code-yeongyu/senpi/blob/d56e6a260d9468418a39bc9120945cf98e06b840/packages/coding-agent/src/core/agent-session.ts#L3620) | extension callback can sanitize message | pre-append synthetic ID may be null; no source generation |
| append/entry | [session.ts L3106–3141](https://github.com/code-yeongyu/senpi/blob/d56e6a260d9468418a39bc9120945cf98e06b840/packages/coding-agent/src/core/agent-session.ts#L3106), [L2198–2202](https://github.com/code-yeongyu/senpi/blob/d56e6a260d9468418a39bc9120945cf98e06b840/packages/coding-agent/src/core/agent-session.ts#L2198) | append after callback; RPC only emits entry_appended | generated entryId too late for unmodified message.id join |

G1 `read(X)` start → abort/restart → G2 `read(X)` same `callId` → **old G1 success** after new context: externally indistinguishable event tuples `{sessionId?,toolCallId,input,content}` can exist. `ctx.signal` on *current* callback and actor-local epoch do not independently certify original producer. External monitor needs `(durableSessionId, processGeneration/sessionIncarnation, attemptId, hostSequence, toolCallId, readStartSeq, terminal result origin)` attached at producer, all ingress covered before authority/effects, and host-owned nonforgeable association. A signature is optional if trusted IPC channel+isolation provides integrity; self-entered IDs never qualify.

Option C minimal upstream API contract:
1. `read_started` before real dispatch with host-minted `(sessionIncarnation,processGeneration,attemptId,readStartSeq,toolCallId,method,sessionId)` and monotonic invalidation ordering.
2. `read_succeeded|read_failed|read_cancelled` on every producer completion, same immutable origin, including after provider failure and restart, or explicit authenticated no-delivery terminal guarantee; same-callId G1/G2 MUST remain distinguishable.
3. `message_end` stable host `messageIntentId` available preappend and `entry_appended` links exactly that intent to canonical entry+JSONL identity, including synthetic unknown/invalid-schema paths.
4. Independent non-actor ingress monitor receives all of tool_result, providerToolResults, nested tools, message_end, RPC, persistence, and rejects unknown/duplicate/ambiguous source before auth/receipt/evidence/effect.
5. Export via supported package/public API, new pin+lock, independent typed/compiled/actual-runtime proof, source trust attestation; do not transplant old runtime PASS.

**NO HOST RUN** until genuine complete H0 public capability is independently proven. Even with H0, H2/H3 actual old-success arrival/rejection is future runtime evidence, not present now.

## 4. F-02：Case A / unknown-tool / B-001 / B-002（混同禁止）

At verified [PR295 final report](https://github.com/yohi/justice/blob/c428041dfb5779b6b6dc8db7bf14928225a00373/docs/reports/omo-native-v5.1.17-senpi-2026.10.8-contract-evidence.md#L420): `canonical 31/32 PROVEN`, `Case A BLOCKED` (5 predicates unobserved), `Case B PROVEN`, `unknown-tool BLOCKED` (pre/post messageId both null), `Task1 BLOCKED`。Actual provider stream error and error `message_end`, session/JSONL sanitation, captured receipts invalidation WERE observed; old result success after error and five required follow-ups WERE NOT observed. Hard terminal route [agent-loop.ts L313–321](https://github.com/code-yeongyu/senpi/blob/d56e6a260d9468418a39bc9120945cf98e06b840/packages/agent/src/agent-loop.ts#L313) occurs after `providerToolResults` + `finishTurn`, and is no proof that callbacks from prior generation cannot arrive.

| Control | fixed observation / status | independent required evidence |
|---|---|---|
| Cached activation reissue | `cachedActivationReissueRejected` missing | same-session exact cached issued token rejected |
| Pre-failure read old result | `preFailureReadResultRejected` missing | old read actually started G1, success arrives after invalidation, old origin authenticated, authority denied |
| Fresh selected-method read | `freshReadReauthorized` missing | newly started verified G2 selected-method read with actual fresh success |
| Late assistant | `lateAssistantSanitized` missing | token-positive assistant, real sanitizer changed, exact postappend readback |
| Late toolResult | `lateToolResultSanitized` missing | token-positive toolResult, real sanitizer changed, exact postappend readback |
| Unknown-tool identity | callback.id=`null`, append.messageId=`null` | non-null exact `sessionId/toolCallId/messageId` join, real `message_end→entry_appended→JSONL` |
| B-001 | `BLOCKED` fixture-only track | separate owner; **canonical32 outside** |
| B-002 | `NOT_PROVEN` positive removal | before token-present + real sanitizer changed + after token-absent/readback; **outside canonical32** |

R11 F.2/F.3 keep `evaluateTask1Acceptance()` existing canonical32 + CaseA/B + runtime+mandatorySafety unchanged. Static feasibility MUST NOT modify evaluator or generate a fictitious 33rd contract. Note `Case B PROVEN` preserved from fixed report, not independently rerun in this investigation.

## 5. F-03：external complete Reference Monitor

Reviewed `registerFilesystemPolicy` only registers deny-wins policy for **Senpi built-in read/write/edit/ls/find/grep** [types.ts L2327](https://github.com/code-yeongyu/senpi/blob/d56e6a260d9468418a39bc9120945cf98e06b840/packages/coding-agent/src/core/extensions/types.ts#L2327); `exec()/executeTool()` are available [types.ts L2435](https://github.com/code-yeongyu/senpi/blob/d56e6a260d9468418a39bc9120945cf98e06b840/packages/coding-agent/src/core/extensions/types.ts#L2435). These hooks are not proof of complete, actor-independent effects mediation. External mediator must fence all write/read/process/network/host/CI/custom providers, prevent privileged bypass and independently store policy/key/clock/revocation and accepted ledger. The detailed 12-route matrix is `04_Trusted_Operation_Atomic_Publication_Matrix.csv`.

A realistic candidate can be OS-isolated actor (filesystem readonly authoritative volume, writable private stage only), blocked network/exec by independent sandbox, trusted operation broker that owns all promotion and emits attested operation records. But this is an **architecture sketch, not `STATICALLY_CONSTRUCTIBLE` proof of coverage**, because host writers/admin/CI and full confinement are not established. Trust graph and residual bypasses = NOT_VERIFIED. `OP_PREPARE_ALLOWED=UNKNOWN/BLOCKED`.

## 6. F-04：one atomic ACCEPT+PUBLISH / crash safety

R11 matrix §2.3 requires **one** `OP_COMMIT_ACCEPTED` linearization point, simultaneously authenticating independent durable accepted record and authoritative visible bytes. A two-phase implementation with durable acceptance ACK then ordinary filesystem rename (or reverse) leaves C2/C3 forbidden split windows. Thus simply saying external recorder or file lock exists is insufficient.

The minimal plausible *future* construct is a single trusted transactional publication gateway: (i) stage bytes content-addressably and verify mode/hunks/root; (ii) independently verify signer/expiry/revoke/scope/root at transaction time; (iii) transactionally update both acceptance record and authoritative snapshot manifest pointer in the same durability domain; (iv) force **all** readers/writers through that gateway. If ordinary paths can read newly renamed source bytes directly, the construction fails despite a committed manifest. None of service/durability/reader fencing/atomic transactions is evidenced here. Therefore `ATOMIC_PUBLISH_PROVEN=NOT_ESTABLISHED` and even speculative B0 source-write is stopped. `05_Crash_Replay_Linearization_Matrix.csv` accounts for crash before/mid, accepted-only, bytes-only, atomic boundary, lost ACK, revoke, concurrent writer.

For rejection: independently prove no external effects, durable `OP_ABORTED`+seq tombstone. Unknown crash/replay/history gap → `IN_DOUBT / QUARANTINE / STOP`; only independently confirmed **actual** violation may be `REVOKED+STOP`. Never conflate with ordinary evidence supersession/expiry.

## 7. F-05/06：DAG、38×7、14 invariants / import feasibility

**Spec DAG (no back-edge)**:

```text
B0 → B1(EAF0) → DEP_START → B2-DEP → B2-HOST-PREP → EAF_final freeze
   → B1-REATTEST-FINAL → human ACTIVATE → H0(capability pre-run)
   → START → H1(actual ingress) → H2(origin after arrival) → H3(evidence seal)
   → B3-T1(submit) → existing Task1 Gate → usual Tasks2–6 → full Task6 → product I
```

This DAG separates necessary types and does not create operations. Reading local R11 matrix §5 plus audit CSV independently verifies IDs `01..38` map to the indicated R11 lines, 38/38 unique ordered and 7-axis flags all True. R11 proposal F lines 715–730 contains A01..A14 and six-column boundary. **This is static text consistency, not full formal proof** that invariants are implementable. `H0` requires only present producer-capability; not H2 future result. `R` actual Task1, `P` compiled partial, `I` production integration are noninterchangeable.

Static pin/export facts: Justice `package.json`, `bun.lock`; Senpi package exports package root, `/client`, `/rpc-entry`; index.ts exports `ExtensionAPI`/`MessageEndEvent`/`ToolCallEvent`; OmO pinned host-prewarm imports separate task engine. Superpowers workflow owners remain separate from OmO native task ownership. No Bun/Node execution, package install, compile, test or host runtime was performed. Exact prospective new public export of read generation/intent is NOT VERIFIED; separate build/compiled gate required. R5 original independent review missing (no escalation by author summary).

## 8. F-07：Option A/B/C 技術評価（人間決裁は行わない）

| axis | A maintain stop | B R11 staged candidate | C upstream public host API/re-pin |
|---|---|---|---|
| Current technical status | supported *policy* for stopping, Task1 still BLOCKED | blocked on fixed public origin proof + independent monitor + atomic commit | design candidate, not implemented/approved |
| H0 generation/source | remains unresolved, no waiver | not established on examined current public event path | purpose is to expose immutable producer attempt + total ingress |
| Operation safety | no new B write permitted | reference monitor+atomic publish P0 gaps | same P0 gaps still exist; C not magic fix |
| Existing evidence reuse | PR295 historic runtime unchanged | 31/32 fixed baseline, cannot bootstrap runtime G1/G2 | historic claims reusable only as historical comparisons, not new-pin PASS |
| R/D/P delta | document STOP/backlog as necessary | substantial E.1–E.10 owner adoption + new scope gates | requirements + design/plan rebaseline and new pin/lock+independent review |
| Time to proof | not reliably estimable | not estimable until monitor/atomic design | not estimable pending upstream change |
| Human decision | continue A by present safety policy; no signature issued | authorizing architecture/Owner/independent normative/HSA later | commission upstream change and independent new-pin evidence |
| STOP trigger | any missing current Task1 evidence | H0 or monitor/atomic UNKNOWN, identity mismatch, revoke | unsupported exported API/new pin unverified, monitor/atomic UNKNOWN |

## 9. F-08：Requirements → Design → Plan FIX delta map (proposal only)

| approved file / anchors | candidate exact IDs/sections | required change if B selected | gates |
|---|---|---|---|
| `docs/superpowers/requirements/2026-09-27-justice-v5-requirements.md` (approved blob `d335c34…`) | `JUS5-HARNESS-03`, new `HARNESS-05`; `JUS5-AUTH-02/04/06/07/08`, new `AUTH-10`; `JUS5-ACC-02`, `COMPLETE-01`; R11 E.1–E.4 | staging HSA vs Task1, per-op exact actor/root/hunks/revocation, no evaluator alteration, independent accepted proof and separate product readiness | Requirements Owner adoption then normative review |
| `docs/superpowers/specs/2026-09-27-justice-v5-semantic-control-plane-design.md` (approved blob `64acdf…`) | §7.5.1–7.5.3 (R11 E.5) | explicit host origin trust tiers, epoch/4 states, sync activation invalidation, sanitation separate from authority; external mediation/atomic storage design | Design Owner exact adoption |
| `docs/superpowers/plans/2026-09-28-justice-v5-semantic-control-plane.md` (approved blob `10dfba…`) | Task1 (E.6); Task2 (E.7); Task6 (E.8–E.9.2) | B0 isolated stage and independent B1 compiled proof; DEP after initial EAF0; Host test-only PREP/RA/ACTIVATE with H0–H3; Task1 existing evaluator unchanged; Tasks2–6 normal grants afterward | Plan Owner exact adoption, independent normative review |
| Fixed Senpi/OmO pin | Option C additional APIs and package/lock | new source pins, immutable baseline R'/D'/P' and independent review; existing R proof not inherited | Human C commission then new formal Gate |

Sequence: authenticated Requirements decision → Design amendment → Plan amendment → *fresh independent normative review of exact R'/D'/P'* → human Architecture Decision → separate phase HSA only upon independent host/operation preconditions → implementation READY per phase. **This output is NOT one of those authorizations**. Requirements Owner, Design Owner, Plan Owner, Fresh Reviewer, Architecture Authority, Phase HSA signers all remain blank.

## 10. Per-obligation evidence / remaining findings

All **F01–F20** rows each have (a) anchored observation, (b) falsifier, (c) confirmation, (d) existing/new evidence, (e) exact stop, (f) owner dependency, (g) status in `03_20_Obligation_Adjudication.csv`. Ten adversarial static traces with dispositions in `06_Adversarial_Trace_Assessment.csv`. New FEAS-001..008 findings are separate from R11 historical FI and PR295 fixed blocked cases; see `07_Finding_Register.csv` and `08_Unresolved_Evidence_Ledger.csv`. No new human signature, runtime claim, Gate or GitHub state was produced.

## 11. Limitations & handoff verdict

The verdict `INDETERMINATE_REQUIRES_FURTHER_STATIC_EVIDENCE` is bounded by incomplete public/private/RPC/host reachability; on the reviewed exported event/dispatch/publication surfaces, H0 remains unverified. Additional fixed-pin host-internal adapters, RPC contracts, process generation/handoff and actor-external policy are not universally disproven; any new positive candidate must independently prove trustworthy pre-effect origin and total mediation, not merely supply a matching field name. End-to-end OmO task engine producer/source and private Senpi host path are **PARTIAL** not exhaustively eliminated. All cited source lines are pinned; `tsconfig.json` at PR295 commit independently matched blob `c9894f496abc59587f0dd39cffe57a7cc6c34a3a`, while live PR states require later verification. This is a **static feasibility investigation, not an independent organizational/human formal Gate**. R11 is archival/unapproved, PR295 Task1 BLOCKED; do not change/elevate earlier evidence or perform host experiments.

**Next technical action:** Commission a distinct source/API owner for Option C minimum immutable source + stable synthetic message identity, plus an independent infrastructure/storage owner for a complete reference-monitor/one-transaction publish *design*; give their falsifiable output to actual human Architecture Decision Authority and R/D/P Owners. Until evidence closes FEAS-001/002/003, do not FIX/adopt/implement B. No signed approval is implied.
