# 調査A 専用作業契約 — 固定Senpi/OmO API到達可能性・Option C候補

**案件:** `RG310-FEAS-001` (CRITICAL) を主要対象とし、`RG310-FEAS-004/005` および関連 F01–F07/F15 の従属証拠を追跡する。目的は**R11のcurrent fixed pinを最終的に実装可能と主張できるか／API追加と再pinを要するか**を、静的・完全な source reachabilityで切り分けること。Option C採択や実装は対象外。

## 独立にトレースする source graph

- `code-yeongyu/senpi@d56e6a260d9468418a39bc9120945cf98e06b840` を固定し、公開型・公開package exports、private実装、RPC server/client、session lifecycle、agent loop、tool execution、tool_result、`providerToolResults`、`message_end`（assistant + toolResult）、`entry_appended`、SessionManager append、abort/retry/compaction/restart、nested/custom toolsを**全経路**で辿る。
- 調査済source anchorの出発点：`packages/coding-agent/src/core/extensions/types.ts` L1564–1570, L1711–1820, L2198–2294；`packages/coding-agent/src/core/agent-session.ts` L1680–1723, L2664–2733, L3077–3141, L3620–3688；`packages/agent/src/agent-loop.ts` L302–335, L600–655, L1015–1047, L1510–1525；`packages/coding-agent/src/index.ts` exportsと `packages/coding-agent/package.json` exports。
- `code-yeongyu/oh-my-openagent@091728d...` の Native host/task producer/RPC経路、および Superpowers固定方法所有者とのインターフェースを追跡。private APIやUI識別子が実際の public exported nonforgeable provenance かを厳密に区別する。
- 新たに取得できないpath, mount, dependent packageバージョンは `NOT_EXAMINED` で残し、推測で埋めない。

## 必須の攻撃反例（positive/negative を混同しない）

1. **G1/G2同一callId**：G1 read(X)のin-flight旧結果→abort/restart/session incarnation change→G2 read(X)開始→G1 successがG2 contextに遅延到達。`sessionId/callId/content/current ctx.signal/actor-local epoch`だけで同一event tupleに見える場合、**前段でG1を認証できること**を示せなければSTOP。旧G1 resultが「実際に到達して拒否された」事実をsource readingから捏造しない。
2. **経路完全性**：通常read tool_result以外の providerToolResults、unknown/incomplete/invalid-schema synthetic results、nested/custom tools、RPC、message_end、未捕捉結果の経路が authority/effect/receipt/persistより前に actor-external boundaryで仲介できるか。見逃しが1つでも `H0=NOT_PROVEN`。
3. **pre/post identity**：実Host生成unknown-tool synthetic resultで`message_end`時 `message.id=null`、`entry_appended`後にentryIdがつく。必要な `(sessionId,toolCallId,messageIntentId,entryId,JSONL)` のnon-null結合を、独立producer authorityにより満たせるか。`null==null`は不可。
4. **Case A**：現実の5未観測 `cachedActivationReissueRejected`、`preFailureReadResultRejected`、`freshReadReauthorized`、`lateAssistantSanitized`、`lateToolResultSanitized` と Case B(既PROVEN)を混ぜない。上流の hard-terminal/error-retry設計から**到達可能な実証経路**があるか静的に査定し、ない場合は必要APIを列挙する。
5. **published support**：public `package.json` export, type aliases/overloads, compilation targets, lockfileと供給npm pinを区別。新APIを現pin実装済みと称しない。

## 必須のOption C **仕様案**（実装禁止）

- 真正Host minted `read_started` → `read_succeeded|read_failed|read_cancelled` に、`sessionIncarnation/processGeneration/attemptId/readStartSeq/toolCallId/method/sessionId` をimmutable producer-boundで運ぶ最小契約、cancel/completion/retryを網羅。
- unknown/synthetic含む `message_end`でpreappend `messageIntentId`、`entry_appended`で同じintentとcanonical entry/JSONL idを関連付けるsupported contract。
- ingress前の真正性を誰が担保するか（署名 or trusted IPC+OS隔離等）、duplicate/out-of-order/cross-epoch、no-delivery terminal保証、external monitorへのtrust transfer、actor側偽造防止を明示。
- 新旧APIの比較表、型とimport/exportのprospective sketch、最小 upstream patch候補の**仕様文書のみ**、new pin/lock/compatibility gate、PR295 runtime再実証条件、要承認R'/D'/P'差分（採用不可の未承認案）を記載。
- 「現pin既存非公開経路が成立」「現pin公開経路は不足」「網羅未達」「C候補API」を混同せず分岐判定する。

## A専用提出物（必須）

1. `01_Independent_Source_API_Reachability_Report.md`: evidence-led結論。`CURRENT_FIXED_PIN_H0_VERDICT` と `EXHAUSTIVENESS` を別記、未取得枝を列挙。
2. `02_Source_Producer_Ingress_Reachability_Matrix.csv`: 各hop/producer/writer/consumer、本来のsource、bound identity、actor forgeable、public export、pre-effect位置、反例、証拠、未調査枝、H0判断。
3. `03_G1_G2_and_Synthetic_Identity_Adversarial_Assessment.md`: 両方向positive/negative、Case A 5件とunknown-toolの証明ギャップ。
4. `04_Option_C_Minimum_Upstream_API_Contract_PROPOSED.md`: host-minted fields、typed public exports、ingress trust、failure semantics、new pin/no implicit approval。
5. `05_A_Findings_and_Unresolved_Queries.csv`: FEAS-001/004/005の状況と新規Finding/未調査path。
6. `06_A_Human_Option_B_vs_C_Brief_UNSIGNED.md`: A維持／B追加証拠／C上流API/re-pinの条件つき比較。署名なし。
7. `MANIFEST.json`, `SHA256SUMS`。GitHub write/runtime/署名はしない。

## 報告時に守る判定

- `EXAMINED_PUBLIC_API_LACKS_PROOF` と `ALL_FIXED_PIN_ROUTES_STRUCTURALLY_IMPOSSIBLE` は**違う**。後者は全source branch網羅・閉鎖の厳格な証拠が必要。
- `POSSIBLE_ON_PIN` は公開/exportされたproducer信頼境界と完全pre-effect ingressの一次証拠が揃う場合に限る。単にprivate `AbortSignal` があるだけでは不可。
- B用H0保証が未実証なら `NO HOST RUN`、Task1 `BLOCKED` のまま。C API提案は設計材料に留める。
