# Justice RG-310 / FEAS-001 — 調査A 人間向け Option A / B / C 判断資料

**2026-10-14 JST | STATIC INVESTIGATION ONLY | HUMAN DECISION PACKET — UNSIGNED**

## 判定対象と不可変前提

- PR #295 Task1 `BLOCKED`（32 canonicalのうち `31/32 PROVEN`、unknown-tool `BLOCKED`）、Case A `BLOCKED`（5項目未観測）、Case B `PROVEN`。前者を後者で代用しない。
- PR #325 R11 `UNAPPROVED`、Fresh Independent R11 Gate `NOT_ESTABLISHED`、R'/D'/P' `NOT_ADOPTED`、`NO HOST RUN`、Tasks2–14 `NOT_AUTHORIZED`。
- 今回の `CURRENT_FIXED_PIN_H0_VERDICT=NOT_PROVEN`、`PUBLIC_API_SUBVERDICT=EXAMINED_PUBLIC_API_LACKS_PROOF`、`EXHAUSTIVENESS=PARTIAL_WITH_EXPLICIT_UNEXAMINED_BRANCHES`、`ALL_FIXED_PIN_ROUTES_STRUCTURALLY_IMPOSSIBLE=NOT_ESTABLISHED`。
- 本文は選択肢の比較資料であり、**人間の選択・Requirements Ownerの決裁・Gate signatory・上流APIの承諾・実行許可を代行しない**。

## 現在の意思決定テーブル

| 選択肢 | 何をするか | 使用できる条件 / 獲得する証跡 | 現在の判定 | 限界・依存事項 |
|---|---|---|---|---|
| **A: STOP / 現状維持** | 既存PRを保持、Task1とhost起動を停止。文書のみ引継ぎ | 直ちに適用できる防御的な選択。審査をPASSにしない | **推奨する現在状態** | H0は解消せず、独立監視・atomic publicationも未証明 |
| **B: current fixed pin の追加静的証拠取得** | Senpi/OmO全private/provider/RPC/nested/host producer枝とpublic export・version pinを閉包調査し、actor-externalであることを証明 | ① host-minted origin+attempt+readStartSeq ② G1/G2同一callIdの帰属 ③ すべてのauthority/effect/receipt/persist ingressの前段 ④ private→公開のsupported APIと独立認証が揃う場合**のみ**継続検討 | `NOT_PROVEN`；BはH0のPASSではない | 裸のAbortSignal／sessionId／entryId／OmO routing／source型だけでは不足。未調査経路は不可能としない |
| **C: upstream 最小API追加の提案** | `04_Option_C_Minimum_Upstream_API_Contract_PROPOSED.md` に沿って、host-minted immutable `read_started`→terminal、pre/post synthetic ID結合、complete trusted pre-effect ingressの追加を上流に**提案** | 上流による実装・公開 exports/decl/compiled artifact、新version/re-pin/lock、正式R'/D'/P'差分決裁、独立Gate、後続runtime検証の全てが必要 | `PROPOSED_ONLY`, **NOT ADOPTED** | API提案は現pin機能ではない。new pin を無承認で選定しない。C後も FEAS-002/003 は残る |

## 判定者に必要な安全境界の事実

1. **G1/G2同一callId**: `sessionId + toolCallId + X + result bytes` だけでは、同じtupleに見える旧G1のread結果を偽造不能に識別できない。真の発行元から署名またはtrusted IPCと隔離/信頼境界が必要。actorローカルepochやmutable extensionsが自称するstart eventは別物。
2. **providerToolResults**: 通常tool_result hookを通らない `message_start/message_end`への経路が一次コードにある。nested/custom、unknown/incomplete/schema-error synthetic、RPC/replay、abortsも含め、**一個の見逃し**でH0 fail-closedになる。
3. **unknown tool identity**: 実ホスト原本でpre `message.id=null`、post `entry.message.id=null`。postappend `entry.id` はpreappendを遡及証明しない。tokenは元から存在せず、正のtoken除去も未観測。
4. **Case A**: `cachedActivationReissueRejected`, `preFailureReadResultRejected`, `freshReadReauthorized`, `lateAssistantSanitized`, `lateToolResultSanitized` は5件とも未観測。Abort releaseが旧成功を無視した場合、その事実を旧G1結果が**到着して拒否された**との実証に数えない。
5. **別々の設計責任**: FEAS-001はhost origin+ingress、FEAS-002はactor-external complete monitor、FEAS-003はtrusted one-transaction accepted+publish。前者の解決を後二者の閉鎖と混同しない。

## Option Bの追加証拠取得要求（現在は読み取り専用に限定）

- Senpi fixed `d56e6a260d9468418a39bc9120945cf98e06b840`: private `AgentSession`全dispatch、`agent-loop`のprovider実装全件、`providerToolResults`、unknown/abort/retry/compaction、RPC server/client/worker/event fanout、`SessionManager` append/appendEntry、nested/custom、公開型/exports/distの実到達経路を完全調査。
- OmO fixed `091728d274f20d62504b0b5e1edbc3970671dd8b`: in-process・RPC process・RPC host・Desktop hostの producer/consumer、handoff/replay、route metadataのtrust境界を完全調査。
- Superpowers fixed `8ca22dba9a94f28898bbce59f2537ff4d87c747d`: `read(X)` methodsとowner/operator境界の実対応を確認。
- Actorが偽造できない source-authenticated `attemptId`・`generation`・`readStartSeq`、否認できない `messageIntentId`→`entryId`→JSONLの同一性、per-path fail-closed pre-effect mediationを一次コードとthreat modelで提示する。
- 現pinの完全な成立証明が得られないなら `POSSIBLE_ON_PIN` を主張せず、C契約の上流検討を要請する。ただし**現pinの全経路が構造的に不可能と断定しない**。

## Option Cに進む場合に人間が決めるべきこと（すべて未決裁）

- Host producerの責任者、認証形式（署名／専用trusted IPC＋OS主体分離）、read terminalのno-delivery保証、補完イベントのordering、abort/retry/compaction/reattachの仕様、coverage of all bypasses。
- 新SDKのowner・distribution APIとbinary artifact・lockfile・verifiable pin、新規method capabilityの扱い、旧版fail-closed／downgrade阻止、rollout rollback。
- 正式Requirements・Design・Planの差分起案、独立Gateによる新しい静的証明、**別途許可された後**のPR295 runtime Case A/unknown-tool再実証、FEAS-002/003の独立閉鎖。
- 技術候補の作成と正式採択を分離し、新pinやHSAをこの文書で実行許可しない。

## 署名欄（未署名・未承認）

| 役割 | 担当 | 意思表示 | 日付/署名 |
|---|---|---|---|
| Requirements Owner | **未特定／未取得** | `NO DECISION` | — |
| Senpi upstream API owner | **未取得** | `NO DECISION` | — |
| OmO host owner | **未取得** | `NO DECISION` | — |
| Fresh Independent Gate Reviewer | **未任命／未取得** | `GATE NOT ESTABLISHED` | — |
| Human release/host authorization | **未取得** | `NO HOST RUN` | — |

**最終処理:** この資料と残りの成果物を後続の独立調査・正式決裁担当者に引き継ぐだけ。実装、runtime/host/RPC、署名、GitHubへの反映を許可しない。
