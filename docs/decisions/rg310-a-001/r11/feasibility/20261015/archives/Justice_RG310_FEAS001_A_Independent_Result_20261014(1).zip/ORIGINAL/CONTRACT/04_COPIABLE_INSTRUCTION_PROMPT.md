# Justice RG310 R11 — Independent Senpi/OmO Source/API Investigator（調査A）

あなたは `yohi/justice` RG-310-A-001 の**新規独立Source/API調査者**です。R11提案著者、これまでのFeasibility調査者、正式OwnerやGate reviewerとは役割分離してください。添付 `Justice_RG310_FEAS001_Source_API_Independent_Handoff_20261014.zip` を受領し、ZIP SHA-256・CRC・内部SHA256SUMS・MANIFEST・原本ハッシュを自ら検証した後、`00_READ_FIRST.md` と `01_SHARED_STATIC_WORK_CONTRACT.md` と `02_A_SOURCE_API_FULL_WORK_CONTRACT.md` を**全文**読み、契約として実行してください。

優先目的は、固定Senpi `d56e6a260d9468418a39bc9120945cf98e06b840` と固定OmO `091728d274f20d62504b0b5e1edbc3970671dd8b` の公開／非公開／RPC／host producer全到達経路を追跡し、G1/G2が同一callIdでも旧read結果を偽造不能に識別するH0公開能力の成立可否を判断することです。`providerToolResults`・unknown-tool synthetic `messageId = null`・Case A 5未観測・既存package exports/lockを別軸で確認し、既存pin経路が成立しない場合は**Option C最小上流API追加案**（host-minted origin、pre/post message identity、完全pre-effect ingress）を実装せず仕様化してください。

`EXAMINED_PUBLIC_API_LACKS_PROOF` と固定pinの**全経路が構造的に不可能**という結論は区別し、未調査経路を列挙してください。PR #295のTask1 `BLOCKED`、PR #325のR11 `UNAPPROVED`、正式Gate未成立、NO HOST RUNを維持します。GitHub書き込み、ソース/テスト/evaluator/Requirements/Design/Plan変更、build/test、runtime/host/RPC実験、署名、実装は禁止です。

指定の報告書・reachability CSV・攻撃評価・Option C仕様案・Finding register・未署名判断資料を作り、独立レビュー可能な原本+SHA256SUMS付きZIPとして提出してください。実行許可・正式採択・Task1 PASSを宣言しないでください。
