# FEAS-001 — G1/G2・synthetic identity adversarial assessment

**種別:** 静的反例・証拠ギャップ / **実験:** なし / **real stale success arrival:** NOT OBSERVED by this investigation / **対象:** fixed S `d56e6a260d9468418a39bc9120945cf98e06b840`, fixed O `091728d274f20d62504b0b5e1edbc3970671dd8b`

## A. G1/G2同一callId — 同一可観測tupleの反例

| 時点 | 生成元に必要な真正identity | 外側で見えること | 判定 |
|---|---|---|---|
| t1 | G1 `(processGeneration=P, sessionIncarnation=S1, attempt=A1, readStartSeq=11)` | `read(X)` / `toolCallId=K` | G1にKを割り当ててもK自体はproducer proofではない |
| t2 | G1 invalidation、cancel/abort、source incarnation変更 | current `ctx.signal` かlocal epochが変化し得る | 内部のabort/retryは旧結果の出所署名でない |
| t3 | G2 `(P2,S2,A2,seq=18)` で `read(X)` | **同じ** `toolCallId=K`, input=X | `{toolCallId,method,input}`衝突 |
| t4 (adversarial hypothetical) | G1成功結果 `(P,S1,A1,11)` をG2見かけのcontextで受領 | `tool_result {id=K,input=X,content=Y,isError=false}` | 現published event schemaからはG1/G2に一意帰属できない |
| t5 | independent ingress monitor | origin不明なら no-authority/no-receipt/no-effect/no-persist | **deny** が必要。許可した場合H0違反 |

**Negative:** source `S:packages/coding-agent/src/core/extensions/types.ts#L1711-L1820,#L2198-L2305` のToolCall/Result/On-event 型と `S:packages/coding-agent/src/core/agent-session.ts#L1670-L1732` emit object には `processGeneration`, `attemptId`, `readStartSeq` がない。`S:packages/coding-agent/src/core/agent-session.ts#L2664-L2733` のqueued source `signal` は内部情報であって externally verifiable read completion origin tokenではない。`S:packages/coding-agent/src/modes/rpc/rpc-mode.ts#L30-L70` のrouting `sessionId` と host generation はread attempt tupleではない。

**Positive candidate (not a present capability):** producerが `read_started`前に `A1`をmintし、completionで同一originをimmutableに付し、t2 invalidation serial fenceより後に届いたG1 successをmonitorがrejectできれば、別のG2 `A2`と衝突しない。producer trustとpre-effect deliveryとdurable cross-restart fenceも独立保証が必要。

**Important partial counter-evidence:** `S:packages/agent/src/agent-loop.ts#L1344-L1435` はabort時 `Promise.race(execution,abortRelease)`でabortを優先し、実executionのsettlementを消費せずcatchする。この**通常 tool dispatch branch**では abort後旧successが外へemitされない可能性が高く、t4は実到達確認ではない。だがprovider results (`#L293-L335,#L598-L655`)、nested `runToolCall`, RPC旧worker、custom producerすべてに同じno-delivery terminal保証があるとは検証していない。pre-run H0は「t4が都合よく発生しない」推測に依存不可。

**Stop:** `(K, X, Y)` だけで同一attemptだと扱う証明/issuance/receiptは不可。`actor-local epoch`で欠損originを補充する案も不可。必要原本を無理に作るsynthetic eventはH2証跡に認められない。

## B. `providerToolResults` / tool_result 非等価性

`S:packages/agent/src/agent-loop.ts#L598-L655` のcursor/exec `onToolResult`→`providerToolResults`配列と `#L293-L335` の先行`message_start/message_end` は、`S:packages/coding-agent/src/core/agent-session.ts#L1687-L1732` の `tool_result` event bridge に**同一経路で必ず通ると証明できない**。hard terminalはprovider result emitの後にある。`message_end`にはproducer-bound generationがないので、sanitation callbackを通ってもauthority認証とは独立。

`runToolCall` nested path (`S:packages/agent/src/agent-loop.ts#L1370-L1402`) は **hookを適用するがeventsをemitしない**ことを明記。`parentToolCallId`は公開されるが、nested `parent/n` IDはtranscript通常のtool call/resultとは別記録 (`S:packages/coding-agent/src/core/extensions/types.ts#L1711-L1724`)。tool_call hook→tool_result hookとtranscript message-endを同一証拠集合とみなさない。

追加で直接ホスト合成される枝: unknown, incomplete, truncated (`S:packages/agent/src/agent-loop.ts#L937-L977,#L1200-L1268`)、schema-invalid (`#L1270-L1340`)。`createToolResultMessage` は`messageIntentId`をmintしない (`#L1509-L1525`)。このため one hook のみで all-ingress と断定できない。

## C. synthetic ID — positive/negativeを分離

固定Task1原本 `yohi/justice@c428041dfb5779b6b6dc8db7bf14928225a00373:docs/reports/omo-native-v5.1.17-senpi-2026.10.8-contract-evidence.md#L487-L522` に次の **real runtime** 記録がある（本調査で再実行したわけではない）。

- `message_end` eventでunknown-tool synthetic resultを受領: **OBSERVED**。
- `entry_appended`とJSONL readback: **OBSERVED**。
- `event.message.id` **null**、postappend `entry.message.id` **null**。**Exact pre/post messageId join FAILED**（null同士を等価証明に使わない）。
- token `present_before=false`, `absent_after=true`, `changed_content=false`: **token-free persistence observed**、token-positive removal **NOT_PROVEN**。
- invalid-schema類似controlはunknown-toolの代替ではない。canonical 32のunknown-tool 1件が**BLOCKED**。

source explanation: `S:packages/coding-agent/src/core/extensions/types.ts#L1564-L1570` で`message_end`は`message`のみ。`S:packages/coding-agent/src/core/agent-session.ts#L3077-L3141`で先にmessage_end handlerが走り、その後`appendMessage`、`_emitEntryAppended`の順。`S:packages/coding-agent/src/core/session-manager.ts#L1616-L1633`はappend時`entry.id`を発行。現在の`entryId`とモデル・合成結果`message.id`は同一概念ではなく、内部WeakMapによるpostappend位置 (`#L1625-L1635`)もpreappend公開originではない。

**Prospective positive:** hostがsynthetic生成と同時に`messageIntentId`を発行し、append確定までprivileged mappingを引き継ぎ、`message_end`の`messageIntentId`と`entry_appended`の`messageIntentId`, `entryId`, durable JSONL exact record digestを一意結合する。`message.id`をあとで復元するだけではpre-effect proofに不足。

## D. Case A未観測5項目の独立査定

| Case A predicate | fixed final evidence | source上の示唆 | 必要な将来実観測 |
|---|---|---|---|
| `cachedActivationReissueRejected` | MISSING | session abort/retryに即してAuthorityStore lifecycle保証なし | 同一sessionの既発行cached activationを再提示し実拒否 |
| `preFailureReadResultRejected` | MISSING | `Promise.race` abort pathでは旧success emit不達の可能性。provider/nested/再起動枝未閉包 | 事前発行G1 successが**本当に失効後届いて**生成元付きで拒否 |
| `freshReadReauthorized` | MISSING | host hard-terminalとその後のrecover/retryが保証されない | G2成功で独立origin認証と新権限発行 |
| `lateAssistantSanitized` | MISSING | `message_end` replacement seamはあるが到達とtoken-positive変更は別 | tokenを実際に含んだlate assistantのcallback→entry→JSONL full readback |
| `lateToolResultSanitized` | MISSING | synthetic/providerは別loop path、late arrival不明 | tokenを実際に含んだlate toolResultのcallback→entry→JSONL full readback |

この5件はCase Aだけの必要predicateであり**Case B PROVEN**やcanonical31/32によって減らさない。`RG-310-B-001 BLOCKED`, `RG-310-B-002 NOT_PROVEN` はcanonical32の外。runtime `R`、compiled `P`、integration `I` の証明は移し替えない。

## E. リスク軸・可反証条件

**Actor spoofing:** actorが入力・callId・局所mapを制御してもorigin certificationをmintできない必要。`ctx.signal` identityはhard trust boundary越え未立証。

**Replay:** processGeneration/sessionIncarnation/attempt/monotonic sequence/terminalの複合キーで reject duplicate, out-of-order, stale, concurrent old success. restart across same durable session id must never authorize replay.

**Total ingress:** tool hook + provider results + unknown/incomplete/schema errors + nested executeTool + RPC/SDK + message_end + append/JSONL は全て個別軸。1つ未捕捉ならH0 `NOT_PROVEN`。

**Source static ≠ runtime:** t4 deliveryを実観測したと称さない。新 upstream APIを実装済みと称さない。実行/署名/変更なし。
