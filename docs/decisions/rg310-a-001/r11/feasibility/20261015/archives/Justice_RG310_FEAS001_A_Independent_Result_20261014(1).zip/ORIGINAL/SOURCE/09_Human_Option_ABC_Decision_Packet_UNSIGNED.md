# Justice RG310 R11 — Option A/B/C Architecture Decision Packet (UNSIGNED)

**Record:** RG-310-A-001 / R11 feasibility review 2026-10-14 JST
**Static verdict:** `INDETERMINATE_REQUIRES_FURTHER_STATIC_EVIDENCE` (inspected public extension/result path cannot prove H0; exhaustive private/RPC reachability remains open)
**Formal gate:** `NOT_ESTABLISHED`; **Requirements/Design/Plan adoption:** `NOT_ADOPTED`; **runtime:** `NO HOST RUN`; **PR295 Task1:** `BLOCKED`.

## Human decision context

Fixed baseline PR295 `c428041dfb5779b6b6dc8db7bf14928225a00373`; R11 archival PR325 `74cac6f61946a30583e61e4004ae6f66a0abdd76`; approved R/D/P commit `8a2e4f1536e9cad499ee7e9d996ff163df132fd4` (blobs d335c34 / 64acdf1 / 10dfba4).

| Option | Feasibility disposition | Safety blockers | New contracts or pins | Proof reusable | Execution now |
|---|---|---|---|---|---|
| A – stop/unchanged gate | valid fail-closed baseline policy only | Case A five missing; unknown synthetic messageId null; canonical31/32 | no automatic new R11 contract | preserve exact existing evidence | **NONE** |
| B – R11 limited staging | **BLOCKED on examined fixed-pin public H0** + external monitor/atomic gaps | FEAS-001/002/003, source+true origin, independent signer/clock/ledger, single record+bytes transaction | adopt R11 E.1–E.10 by human Requirements→Design→Plan; exact scoped HSA | historic evidence only, not H0/Task1 PASS | **NONE** |
| C – upstream API and repin | proposed route, API not verified implemented | still needs external reference monitor and atomic publication, actual Case A & unknown tool evidence | host read_started+result producer attempt, immutable origin, pre/post stable message intent; new Senpi/OmO pin, lock and RDP baseline | historical comparison only; new pin needs new proofs | **NONE** |

### Proposed technical resolution (not a decision)

Maintain A as mandatory safety state. Evaluate C first for trusted host minted producer identity and immutable synthetic result identity; simultaneously design independently enforced writer isolation and same-transaction atomic accepted-record/public bytes publication, required whether B or C. Do not issue phase HSA, execute host, or mark B implementable until each failure path has an independent proof and a separate human Architecture Decision and owner-approved normative revision.

### Falsifying negative controls / exit criteria

- Same `callId`, old G1 result after G2 started must remain authenticated as G1 *before* any receipt/authority/effect/persist; without producer binding, fail closed.
- Unknown/invalid-schema synthetic toolResult must have stable non-null same ID before message_end and at entry_appended/readback, or an explicitly separately approved evaluator contract; do not pass null=null.
- `exec`, network, symlink, temp, CI, admin, host private I/O bypass must be impossible under trusted isolation, not simply audited afterward.
- Accepted durable proof and published canonical bytes appear together at a single linearization point, including crash/ACK/replay/revoke/parallel writers; show concrete transactional semantics.
- Keep canonical32/CaseA/B and B001/B002 separate; existing `evaluateTask1Acceptance()` unchanged; H0 before H2; R vs P vs I separate.

### Decision checklist — blank for authorized humans

- [ ] A — formally continue existing fail-closed route
- [ ] B — authorize **proposal only**, after new independent proof, exact R'/D'/P' Owner approval, fresh normative review and later phase HSA
- [ ] C — commission upstream public host API/re-pin, preserving STOP until rebaseline/review
- [ ] Hold awaiting more independent static evidence

**Requirements Owner:** UNSIGNED  
**Design Owner:** UNSIGNED  
**Plan Owner:** UNSIGNED  
**Fresh Independent Normative Reviewer:** UNSIGNED  
**Human Architecture Decision Authority:** UNSIGNED  
**Phase HSA Signer:** NONE  
**Formal independence:** NOT_ESTABLISHED

Architecture decision date / immutable signature evidence / approved R'/D'/P' blobs: **BLANK — NOT ESTABLISHED**.
