# C1-FULL P1 — Coverage, Absent Proof, STOP Ledger

**Status: NOT_EXHAUSTIVE. Completion criterion not met; prohibit interface freeze.** Date 2026-10-22 JST. Performed only offline archive inspection, static CSV/text parsing and exact-SHA **read-only** GitHub source fetch. NO project checkout, GitHub writes, Git/CI invocation, build/test, native/OS execution, DB/network/host RPC action, secrets, credential introspection, deployment, HSA or human signature.

## 1. Input verification — exact limits

| Input | Measured/checked | Result |
|---|---|---|
| Attached handoff ZIP | local SHA-256 `1a01cbe4263c76aba8495d538c35405e84608859a3c484970d2f36289867a8f9` | bytes measured; expected sender SHA-256 was **not separately supplied** in the task, so sender hash comparison **NOT_VERIFIED** |
| Attached outer ZIP | ZIP CRC, all declared 5 `SHA256SUMS` entries, all declared 5 `MANIFEST.json` entries | **PASS** (not a sender identity signature) |
| Nested R1 remediation ZIP | CRC; 8 internal SHA256SUMS and 8 MANIFEST entries | **PASS** |
| Nested R1 independent review ZIP | CRC; 6 internal SHA256SUMS and 6 MANIFEST entries | **PASS** |
| Nested original R11 ZIP | CRC; 8 SHA256SUMS entries | **PASS**; original `MANIFEST.json` **ABSENT** (cannot verify a nonexistent manifest) |
| Earlier parent historical archive | asserted historical SHA `735d9f0ce2b97d2b1543fb6a7a5d9a839b2ada30cb5a41e732f1115725d30160` | **NOT_ATTACHED / NOT_VERIFIED**, no parent provenance inherited |
| MASTER_PLAN.md | all 119 lines read as input data; approved R/D/P and R11 distinct | **READ**, **not authorization** |
| Fixed Justice source | exact `c428041dfb5779b6b6dc8db7bf14928225a00373` via read-only GitHub connector, 28 logged source blobs | path-level source **VERIFIED_SOURCE**, not full repository tree or running deployment |
| Approved normative R/D/P | `docs/superpowers/plans/2026-09-28-justice-v5-semantic-control-plane.md@8a2e4f1536e9cad499ee7e9d996ff163df132fd4:42-85` read and differentiated | **VERIFIED_SOURCE**, no spec changes |

For audit detail see `07_ARCHIVE_INPUT_VERIFICATION.json`; its `expected_sha256` is explicitly **NOT_SUPPLIED_SEPARATELY**. Archive CRC and content-hashes provide local *consistency*, not external independent provenance/authoritative signature. Original R11 38×7 and INV-A01..14 were included as unmodified reference bytes; do not transform them into certified outcomes.

## 2. Census accounting and evidence type

| Register | Count | What it establishes |
|---|---:|---|
| Existing CE-01..28 | 28 | preserved complete from R1 census; imported provenance retained; multiple original rows are design-only/externally unverified |
| New source path N-01..N-46 | 46 | distinct path/entrypoint effects **source-anchored** at fixed SHA; no execution inferred |
| Total P1 census rows | **74** | **64** `VERIFIED_SOURCE`, 7 `DESIGN_PROPOSAL`, 3 `NOT_VERIFIED`; “verified” means pinned source code evidence **only**, not absence of all bypasses |
| Credential/effect/bypass matrix | **70** | selected source paths/CE threats; actual secret/token values and configured controls **NOT_VERIFIED** |
| Existing independent Findings | **22 OPEN** | no Finding closed in P1 |
| Existing adversarial counterexamples | **37 NOT_EXECUTED** | no NC executed or falsified |
| Original matrix | **38 states × 7 axes** | no R11 row edited, approved, passed, or substituted |
| Invariants | **INV-A01..A14** | original 14 unchanged; no new runtime PASS |
| Original Task 1 | **31/32 PROVEN** | Case A `BLOCKED`, Case B `PROVEN`, unknown-tool `BLOCKED`; Task 1 unchanged |
| HOST/RUN, Tasks 2–14 | **no HOST RUN, NOT_AUTHORIZED** | no P1 action altered Gate/Authorization |
| DS-01..DS-06 | **all formally PENDING** | DS-02 preference = C1-FULL **direction only**, no decision/signature |

`05_P1_FINDING_NC_DEPENDENCY_MAP.csv` preserves one row for each of 22 and each of 37. New CE/NC linkages are *P1 hypotheses only*; historical `related_NC` missing or blank stays **NO_EXPLICIT_FINDING_LINK_IN_SOURCE**, not magically resolved. P1 cannot certify another team's workstream.

## 3. Directly covered from fixed source

- `.github/workflows/ci.yml:3-40` preview/push triggers, dependency setup, OpenCode install, Rust/Bun tests/builds and artifact upload.
- `.github/workflows/release.yml:3-73` `contents/pull-requests/packages: write`, release-please, checkout tag, JS/Rust build, `npm pack --dry-run`, direct GitHub Packages publish, **separate npm pack** plus gh release upload.
- `package.json:12-80`, `tsconfig.json:2-25`, `native/review-artifact-linux/Cargo.toml:1-19`, `native/review-artifact-linux/Cargo.lock:1-35`, `bun.lock:1-41`, `src/index.ts:108-125`, README install alternatives.
- `src/opencode-plugin.ts:35-130`, `src/runtime/opencode-adapter.ts:182-190,227-304,646-710`, `src/runtime/justice-tools.ts:20-96,195-299`; distinguish exposed `justice_review` from defined but **unregistered** `justice_status` and `justice_gate`.
- `src/runtime/node-file-system.ts:51-113,118-239`, `src/runtime/observation-log-store.ts:127-220,248-404`, `src/runtime/write-queue.ts:35-106`, `src/runtime/state-projection-cache.ts:19-60`, `src/runtime/gate-loader.ts:55-109`, `src/core/atomic-persistence.ts:103-217`, `src/core/justice-plugin.ts:208-262`, `src/core/telemetry-store.ts:47-57`.
- `src/runtime/linux-review-artifact-provider.ts:68-106,190-202`, `native/review-artifact-linux/src/lib.rs:12-19,100-120,181-209,268-315`; optional native file descriptor operations, NOT universal enforced boundary.
- `src/runtime/doctor-cli.ts:109-205,220-309,320-460,494-539`; spawn, dynamic import, unrestricted local diagnostic reads.

The tracked path inventory records *source paths* and known effects. It is **not** a complete module import graph, every syscall/FD, every dependency, every shell body effect, or an exhaustive list of other repositories/actors. GitHub code search yielded default-branch candidates, but source evidence rows were populated through pinned-SHA `fetch_file`; **directory-based recursive full tree enumeration was not available**. Do not infer absence of extra workflows from individually missing paths.

## 4. Explicit incomplete universe and falsification questions

| Gap ID | Unverified path / missing source | Why P1 is not exhaustive; required negative proof | Downstream |
|---|---|---|---|
| U-01 | full pinned Git object tree, all workflows, GitHub Apps, hook/matrix, submodules, action script contents | exact read-only tree walk + branch/tag/event dispatch graph; unlisted workflow or alternate publisher disproves closure | P1/P2/P4 |
| U-02 | GitHub repository permissions, branch/tag protection, environment approval, secret inheritance, admin override, machine accounts | source `permissions:write` is NOT effective token proof; out-of-band API/ref writer may bypass monitored workflow | P2/P4 |
| U-03 | all CI release execution traces, checkout metadata, actual runner image, action dependency downloads, toolchain/network, build reproducibility | frozen lock is not fetched-byte closure; build/test not run; no immutable CI provenance | P1/P4 |
| U-04 | complete `bun.lock` transitive installs/scripts, Cargo crate/build.rs graph, GitHub Action nested effect graph | pin source and all download byte hashes, emitted blobs and file metadata; script/native may perform unobserved effects | P1/P2/P4 |
| U-05 | actual `dist/` full emitted contents, native `.node` ELF, `npm pack` dry-run vs `npm pack`, registry stored tarball, release asset bytes | no computed package digest/seq equivalence or `t_use` proof; repackage divergence possible | P4 |
| U-06 | OpenCode/OmO/Senpi exact pinned host source and ingress, package resolver, runtime module cache, FD path, start-origin, hot reload | only Justice's side traced; genuine A1 H0/G1/G2 and Case A cannot be imported as PASS | P-A1/P4 |
| U-07 | third-party clients that already downloaded/pinned/modified artifacts, direct TS/npm/core imports | externally published consumers cannot be *forced* to call private Gateway; needs exact Owner threat/scope decision, cannot silently exclude | P2/P4/P7 |
| U-08 | alternate root/admin, rollback, backup restore, old primary, DB privileges, OS uid/mount/net/eBPF, GitHub API writers | no running topology or OS/network enforcement configuration inspected; no administrator/backups negative proof | P2/P3/P4 |
| U-09 | PostgreSQL acceptance transaction, external signer, ACK prefix, COMMIT time, revoke-issued timestamp, expiry-crossing check | DB not inspected; no atomic DB/externally signed-public-effect primitive proven; strict contract may be structurally incompatible | P3 |
| U-10 | full correlation of all 22 Findings, 37 symbolic NC and R11 38×7/INV14 to future enforcer cases | no executable counterexamples; source-based mapping is prioritization, not falsification/closure | P5/P6 |
| U-11 | sender-provided outer expected ZIP hash, historical parent 735d... original | byte hash can be computed locally but independent expected comparison and historical ancestry are not verified | P0/P6 |
| U-12 | pre-effects of host `justice doctor` dynamic imports/child execution and other possible CLI surfaces | doctor is code-execution-bearing; untrusted imported code may run outside plugin Gate; require full host process graph | P1/P2/P4 |

## 5. Proposed interface freeze STOP and axis-specific finding

| Axis | Outcome | What is missing before claiming more |
|---|---|---|
| A. Full consumer/source closure | `STRUCTURAL_CONFLICT` in current topology; `NOT_EXHAUSTIVE` in census | all Git/CI/native/host/third-party ingress resolved; currently unmediated external effects remain |
| B. Before-effect B1 enforcement | `REVISION_REQUIRED` | trustworthy effect monitor that every legitimate protected principal must traverse, including spawned children, filesystem, native, GitHub token and admin roots |
| C. DB/single-domain acceptance | `FEASIBLE_DESIGN_CANDIDATE` **only for restricted domain**; external C1-FULL `STRUCTURAL_CONFLICT` | exactly serialized accepted byte state and independent remote signature/publish/host boundaries reconciled |
| D. Issuer revoke / expiry through COMMIT | `STRUCTURAL_CONFLICT` absent proven cross-domain serialized time | issuer-issued instant vs observed authority order and actual durable COMMIT proof |
| E. Signer/ACK/restore/crash | `REVISION_REQUIRED` | cross-domain in-doubt handling and externally verified durable prefix across backup/old primary |
| F. Normative matrix & invariants | `REVISION_REQUIRED` | fresh separate 38×7+14 impact review, R'→D'→P' human adoption if needed |
| G. Provenance/host origin | `NOT_VERIFIED` | historic parent and sender hash; A1 producer source; runtime closure, host-loaded EAF/seq |

### Explicit STOP conditions

1. No full-source-tree/consumer graph completeness proof: **NOT_EXHAUSTIVE**, do not freeze P2/P3/P4/P5 interfaces or claim P1 completion.
2. Existing direct consumers/remote effects still can avoid a proposed Gateway: **current C1-FULL cannot be treated implemented, Gate-ready, or approved**.
3. Public third-party reader not under the producer TCB: **unfenceable third-party guarantee** must be recorded, not silently excluded.
4. No signer+publish+DB atomic proof, no issued-revoke/common-serial-order proof and no expiry-through-COMMIT proof: retain structural/strict-semantic conflicts.
5. Existing Task 1 **31/32**, Case A/unknown-tool **BLOCKED**, Case B **PROVEN**; no HOST RUN, Tasks 2–14 **NOT_AUTHORIZED**, PRs #295/#325 and R11 original unchanged.

**Completion verdict: `NOT_EXHAUSTIVE / REVISION_REQUIRED FOR INTERFACE_FREEZE`.** P1 delivered a traceable *partial source census*, with necessary unresolved evidence identified, not a global no-bypass demonstration. This is a separate P1 research outcome, not P6 independent review of a new architecture.
