# Justice RG-310-A-001 R11 — C1-FULL Design/Research Master Plan (DRAFT)

**Created:** 2026-10-21 JST  
**Decision status:** `DS-02_DIRECTION_PREFERENCE=C1-FULL`; **`DS-02_FORMAL_DECISION=PENDING`**; `DS-01/03/04/05/06=PENDING`; Owner signature absent.  
**Authority:** Static design/research planning only. R11 remains `UNAPPROVED`, proposed R'/D'/P' `NOT_ADOPTED`, B0/B1/B2 and HOST `NOT_AUTHORIZED`.

## 0. Purpose and fixed premises

Owner's stated design preference is **C1-FULL**, meaning all legitimate Justice product lifecycle consumers and controlled effects must be addressed by a proposed enforceable accepted-authority contract, including Git/source/worktree, GitHub Actions CI, JS+native builds, release/tag publication, GitHub Packages/npm distribution, and host/package loading. This is **not** a claim that external arbitrary readers can be forced to invoke Gateway, or that PostgreSQL can atomically roll back public package distribution. This remains a technical hypothesis to be either demonstrated with a concrete migration/enforcement design or rejected with a counterexample.

**R1 independent review outcome:** `REVISION_REQUIRED`; the present direct-consumer topology is `ARCHITECTURAL_REDESIGN_REQUIRED`; restricted C1 was only `CONCEPTUALLY_PLAUSIBLE`, not an implementable full consumer design. Prior **22 findings OPEN** (B1B2-FI-001..014 and B1B2-NEW-015..022), **NC-01..37 NOT_EXECUTED_DESIGN_ONLY**, original R11 **38 states × 7 axes**, **INV-A01..A14**. Independent historical parent archive (`735d9f0c...`) was unavailable; do not imply its provenance has been verified.

**Pinned baselines:** Justice Evidence HEAD `c428041dfb5779b6b6dc8db7bf14928225a00373`, approved R/D/P HEAD `8a2e4f1536e9cad499ee7e9d996ff163df132fd4`, R11 proposed archival HEAD `74cac6f61946a30583e61e4004ae6f66a0abdd76`, Senpi `d56e6a260d9468418a39bc9120945cf98e06b840`, OmO `091728d274f20d62504b0b5e1edbc3970671dd8b`. GitHub archival PR #325 is *evidence*, not normative approval; PR #295 Task1 remains separate and blocked.

**Source-confirmed at fixed Evidence HEAD:** `.github/workflows/ci.yml` uses checkout, bun/Rust/native build and artifact upload; `.github/workflows/release.yml` can create release/tag, check out tag, build JS/native, run `npm publish --ignore-scripts` to GitHub Packages and `gh release upload`; `package.json` exports dist code/native closure; Node filesystem and JSONL observation/write-queue use ordinary FS reads/writes/rename. Static config observation **does not prove a run took place**.

## 1. Required safety properties, without waiver by design prose

1. **Complete legitimate-consumer/effect scope:** no Git, CI, release, publisher, package/host or direct actor path may be silently omitted or relabeled non-authoritative to make C1 appear safe. If the design can secure only a non-public workspace (C2), call that a **counterexample to C1-FULL** and offer C2 only as a separate Owner scope change.
2. **Pre-effect reference monitor:** before each protected effect, identify actual enforcing principal and a nonbypassable boundary against actor/child/native/shell/FD/mount/network/Git/CI tokens/admin. Explicit trusted root/CI publisher/DB superuser TCB and who can reconfigure the monitor; never claim untrusted actor controls root.
3. **Byte and use identity:** scope+seq+digest must bind accepted source, lockfile/toolchain, build inputs, derived JS, native `.node`, package tarball bytes, release tag and *actual host-loaded* closure. Re-hash/attestation at materialization/use; block TOCTOU, stale artifact, replaceable dependency and replay.
4. **Internal acceptance linearization:** exact bytes, immutable accepted operation and result, head/root, guarded gap-free accepted seq, writer fence and relevant revocation state atomically commit in one *chosen* authority domain. PostgreSQL 18 is only a candidate, not an adopted solution.
5. **Issuer revocation/time:** explicitly distinguish `issuer-issued revoke time` from `authority-enforced revoke order` and `preflight expiry check` from **actual durable COMMIT**. Produce a verifiable common serialization / commit-bound mechanism that satisfies current strict semantics; otherwise mark the strict contract incompatible and prepare a human-reviewable normative alternative—do not quietly redefine the rule.
6. **External signature and ACK:** DB COMMIT, independent signer output, public artifact effect and ACK are different transaction domains. Choose genuinely single-domain custody with credible enforcement **or** propose a two-threshold durable/externally-sealed semantics as a material R'/D'/P' change. A post-COMMIT signature cannot retroactively be the same atomic event.
7. **Irreversible public effects:** GitHub tag/release, package publication and host actions cannot be undone by DB rollback. Use fenced effect initiators, idempotent intent/delivery/verification or explicit `IN_DOUBT+STOP`; do not claim universal exactly-once or atomic cross-domain success without proof.
8. **Recovery and freshness:** same accepted high-water prefix after ACK/restart/restore; physically fence old primary; reject stale cache/replica reads and unverified materialization; account for PREPARED/ABORT tombstones without assuming timeout means no effect.
9. **A1 and Task1 separate:** H0/G1/G2 genuine host origin, same callId/old G1 success, synthetic `messageId=null`, Case A and B-001/B-002 are independent. Task1 canonical32 is `31/32 PROVEN`, Case A `BLOCKED`, Case B `PROVEN`, unknown-tool `BLOCKED`; Tasks 2–14 unauthorized. No alternative design can promote any of those statuses.

## 2. Work breakdown and dependency DAG

```text
Owner's DS-02 C1-FULL direction (nonbinding)
    ↓
P0: fixed source/review baseline + review-contract pin
    ↓
P1: full consumer/effect/source closure (Git/CI/native/release/host)
    ├── P2: trusted execution/Reference Monitor migration contract
    ├── P3: acceptance, revocation, time, external proof and recovery contract
    ├── P4: irreversible release/package/host publication contract
    └── P-A1: separately continue fixed Senpi genuine origin research (independent dependency)
    ↓  [P2–P4 inputs and interface reconciliation]
P5: integrated C1-FULL redesign R2 candidate + falsification matrix
    ↓
P6: FRESH independent static technical review (different reviewer)
    ↓  [only if sufficiently supported]
P7: human DS-01..06 architecture decisions (unsigned until separately acted)
    ↓
R' requirements proposal → independent review/adoption
    ↓
D' design proposal → independent review/adoption
    ↓
P' plan proposal → independent review/adoption
    ↓
Separate gate/phase-specific human authorization and future controlled evidence
```

### P0 — Baseline and limits (this coordinator / no repo mutation)

**Inputs:** provided R1 proposal ZIP, latest R1 independent-review ZIP, original R11 ZIP, read-only GitHub pinned HEAD. Verify outer bytes/CRC/SHA256SUMS/MANIFEST for available inputs. Preserve `735d9f0c...=NOT_VERIFIED` for missing historical original.

**Output:** `BASELINE_MANIFEST.md`, source/evidence map, STOP ledger and project-preference note. **Gate to P1:** no source confusion: proposed docs != adopted R'/D'/P'.

### P1 — Complete legitimate consumer/effect census (separate source-investigation AI agent)

**Investigate:** all workflows and triggers incl. CI, release-please and release job; Git tag/ref/PR/branch writers; source and lockfile consumers; JS/Rust/native builders; test artifacts and dist; GitHub artifacts/releases/Packages; package extraction/install/import runtime; Senpi/OmO host and exposed tools; JSONL and write queue; external dependency fetch, deploy/owner/admin routes, privileged tokens, backups and caches. Trace entrypoints to actual effects, actor principal, credentials and defenses. Start with prior CE-01..28 as **non-exhaustive** input, not an exhaustive claim.

**Each path row:** ID, entrypoint, source-commit/file/lines, process identity, read/write/effect, protected domain, source bytes/digest, destination, secret/token/mount/FD capability, origin/Gateway interaction, enforcement before-effect, denied adversarial alternative, negative proof needed, evidence type, migration/compatibility status.

**Outputs:** `P1_FULL_CONSUMER_EFFECT_CENSUS.csv`, `P1_SOURCE_TO_EAF_NATIVE_CLOSURE.md`, `P1_BYPASS_AND_EFFECT_MATRIX.csv`, `P1_ABSENCE_AND_UNVERIFIED_PATHS.md`. **Exit:** each known real consumer/effect accounted for, zero silent exceptions, explicit `NOT_EXHAUSTIVE` if systematic source closure not possible. Do not call coverage proven from static inspection.

### P2 — Actor isolation / B1 reference-monitor technical design (independent security/OS architect)

Define actor/descendant/build/CI/token/admin principals and actual enforcing substrate: process namespaces/capabilities, read-only mounts or private staging, FD leakage controls, sandboxed native children, artifact gateway, network egress, GitHub release/publisher credentials and CI branch/workflow policy. Specify before-effect admission boundaries, trust custodian, revocation loss and denied bypass. For GitHub Actions, study Environment approval, secrets segregation and deployment protection as *candidate controls*, and verify whether the necessary publication effect occurs before such a rule; do not assume controls currently configured or stronger than their documented scope.

**Outputs:** `P2_TRUST_CAPABILITY_GRAPH.md`, `P2_EFFECT_TO_ENFORCER_MATRIX.csv`, `P2_MINIMAL_PRIVILEGED_ROOT.md`, `P2_ESCAPE_COUNTEREXAMPLES.md`. **Exit:** concrete platform-valid boundaries proposed, or explicit impossibility/required architecture replacement; P1 source trace anchoring every claimed mediator.

### P3 — B2 accepted-state/time/revocation/proof/recovery technical design (independent protocol architect)

Evaluate at least (a) single custody/serializing authority binding durable bytes/receipt, issuance/revocation and proof; (b) DB internal acceptance with *externally sealed visible* two-threshold alternative with explicit normative amendment; (c) reject or state unresolved where strict expiry-before-durable-COMMIT cannot be assured. Include opId/idempotency, PREPARED/IN_DOUBT/ABORTED, serializable conflict, no nontransactional acceptedSeq, revocation race, signer crash/partition, independent ACK prefix, WAL/backup restore and old-primary fencing. **PostgreSQL `pg_xact_commit_timestamp` is not a trusted externally attested, indefinitely retained commit-time proof**; evaluate suitability without assuming it solves R11.

**Outputs:** `P3_AUTHORITY_SERIALIZATION_PROTOCOL.md`, `P3_TIME_REVOKE_AND_SIGNER_ADVERSARIES.csv`, `P3_RECOVERY_PREFIX_STATE_MACHINE.md`, `P3_NORMATIVE_INCOMPATIBILITIES.md`. **Exit:** a coherent falsifiable design candidate or explicit `NO_FEASIBLE_STRICT_PROTOCOL`, not fictional PROVEN. Indicate exact changes requiring Owner review.

### P4 — Release/public effect/actual host-use protocol (independent CI/release architect)

Design a **nonauthoritative preview lane** (CI tests may build but cannot claim accepted product or use protected publisher credentials) and an **accepted immutable build/release lane**. Require independent pre-effect release admission, exact accepted manifest EAF and toolchain binding; freeze package tarball and emitted native closure, isolate publisher token to authorized job, record external publish intent/proof separately from DB acceptance, reconcile retries and unknown remote result. Prove or fail closed on the cutover from current `release-please` and direct tag checkout to accepted-pinned bytes. Distinguish gateway-fenced publisher from arbitrary third-party artifact readers (the latter cannot be forcibly made to call Gateway after external distribution); define what can be guaranteed and what would need a normative scope clarification.

**Outputs:** `P4_WORKFLOW_CUTOVER_DESIGN.md`, `P4_PACKAGE_DIGEST_AND_USE_BINDING.md`, `P4_EXTERNAL_EFFECT_ORPHAN_CASES.csv`, `P4_RELEASE_TRUST_AND_CREDENTIAL_GRAPH.md`. **Exit:** no path for an unaccepted digest to acquire trusted publish/host effect under the proposed TCB; report direct bypass or impossible third-party guarantees explicitly.

### P-A1 — Host-origin separate dependency (separate track)

Keep `RG310-FEAS-001/004/005` and genuine producer attempt/source binding unresolved. Research fixed Senpi public/private/RPC + OmO ingress, and only if needed prepare supported minimal upstream Option C API inquiry for human approval before sending. Do not synthesize start origins or `messageIntentId`; maintain Task1 external STOP. This track runs alongside P1–P4 but cannot be consumed as success without its own independent evidence/review.

### P5 — Integration (new candidate's architecture author; not reviewer)

Reconcile the actual P1 graph and P2–P4 interfaces into a **single coherent C1-FULL R2 architecture candidate**. Explicit artifact flow/source/native closure, principal/permission flow, acceptance-event linearization, release and host-effect transitions, rollback/ACK/restore; give at least one trace demonstrating rejected unaccepted release, stale load, issuer revoke before acceptance, expiry crossing and signer outage. Do not assume a one-DB pattern if P3 shows it is unfit. Produce `R2_ARCHITECTURE_CANDIDATE.md`, `R2_INTERFACE_AND_TRUST_BOUNDARY.md`, `R2_FINDING_22_TRACE.csv`, `R2_NC_37_PLUS_NEW.csv`, `R2_R11_38X7_AND_INV14_IMPACT.md`, `R2_RDP_REDLINE_CANDIDATES_UNSIGNED.md`. **Exit:** design that can be falsified and scoped; otherwise record `ARCHITECTURAL_REDESIGN_REQUIRED` with exact blockers.

### P6 — Independent static architecture review (new session distinct from all authors)

Reconfirm input hashes and GitHub pinned source. Falsify P1 universe and P2–P4 effect mediation, time/revoke/ACK semantics, release/host use at t_use, native/secret/CI bypass, 22 findings, 37 prior traces, 38 original state rows and 14 invariants. Distinguish DESIGN_COMPATIBLE_WITH_CONSTRAINTS from runtime PROVEN. **Exit:** axis-specific `REVISION_REQUIRED`/`STRUCTURALLY_INCOMPATIBLE` or limited design-readiness; no self-certification or normative adoption.

### P7 — Human decision and the controlled normative sequence

Record DS-02 as **preference only**, not signer approval. After the independent design review, the human Owner decides DS-01..06 on exact documents and revisits DS-02 if full mediation is not feasible. Any change to strict timestamp, issued-revocation, independent signing or accepted authority semantics is **Requirements-first normative redesign** with separate R'→D'→P' technical and governance reviews. Only following separate authorized Gates may implementation agents begin a specifically scoped implementation; R11 B0/HOST permission is never implied by this plan.

## 3. Preserved STOP, falsification and no-go criteria

- One legitimate CI/release/host publisher or loader can bypass accepted proof and still be trusted → **C1-FULL not established; redesign**.
- Accepted record + published bytes + exact root/seq split across unaudited commits → **B2 reject**.
- `revoke_issued(t0)`, accepted COMMIT at `t1`, DB sees epoch only `t2` under strict issued-at semantics → **reject**, unless proven common serializer or human-reviewed new requirement.
- `precheck < grant_expiry < durable_COMMIT`, or actual COMMIT bound not provable → **reject strict temporal claim**.
- Separate signer/ACK fails after DB COMMIT, or restored DB loses acknowledged prefix → **IN_DOUBT/STOP**, no post-hoc fake atomicity.
- GitHub Packages/release upload or host effect occurs before enforceable effect gate, regardless of DB outcome → **incompatible with claimed full mediation**.
- Fixed pin H0/Case A/messageId remains unresolved → **Task1 BLOCKED** even if independent C1 architecture can be designed.

## 4. Source, research and permissions

Source basis: user's 2026-10-21 R1 `Remediation R1` and `Fresh Independent Architecture Review` ZIPs; original R11 proposal archive; independent read-only GitHub fetch of `.github/workflows/ci.yml`, `.github/workflows/release.yml`, `package.json`, `src/runtime/node-file-system.ts`, `src/runtime/observation-log-store.ts`, and `src/runtime/write-queue.ts` at pinned `c428041d`. PostgreSQL 18 official transaction isolation/commit-time documentation and GitHub environment protection documentation are illustrative research inputs, not proof of configured controls.

**NO GitHub writes/PR changes, implementation, tests, CI/DB/host/cloud/OS execution, credentials, Owner signature, HSA, formal Gate, or Tasks2–14** during P0–P6 unless a **new explicit permission** establishes a narrowly scoped later task. PR #295 and #325 must remain OPEN/Draft. Store P1–P6 candidate docs as unsigned research evidence only.
