# C1-FULL P1 — Source → EAF → JS/Native → Package → Actual Host-Use Closure

**Basis:** 2026-10-22 (JST). Independent, **static/read-only** source investigation. **NOT_EXHAUSTIVE; INTERFACE_FREEZE_STOP**. This paper is not a design adoption, human approval, runtime verification, HSA, signed release admission, or authority to run anything.

**Pinned Justice:** `yohi/justice@c428041dfb5779b6b6dc8db7bf14928225a00373`. **Approved normative R/D/P:** `8a2e4f1536e9cad499ee7e9d996ff163df132fd4`. **Original R11** is UNAPPROVED. Source paths below are `yohi/justice/<path>@c428041dfb5779b6b6dc8db7bf14928225a00373:<line range>` unless an explicit alternate SHA is printed. “Verified source” means source bytes returned by an exact-ref *read-only* GitHub fetch; it does not verify a process executed those bytes. Git object/blob SHA-1 and expected accepted SHA-256/sequence are different identities.

## 1. Directed source-to-effect graph established by pinned source

```text
[G1] master push / PR to master
     ├─ CI: .github/workflows/ci.yml:3-40
     │  └─ actions/checkout + setup-bun + global opencode-ai@1.18.29 + Rust
     │      └─ bun install --frozen-lockfile; Cargo native build/test; tsc/bun build
     │          └─ dist/ -> actions/upload-artifact (NOT an accepted release proof)
     └─ release-please: .github/workflows/release.yml:3-73
         ├─ release-please-action (GitHub PR/ref/tag/release producer)
         └─ if release_created: actions/checkout(ref=tag_name)
             └─ frozen Bun install + Rust -> native .node -> JS dist
                 ├─ actions/upload-artifact(dist/)
                 ├─ npm pack --dry-run --json --ignore-scripts (presence check only)
                 ├─ npm publish --ignore-scripts -> GitHub Packages
                 └─ separate `npm pack` -> gh release upload <tag> <tarball>
                      └─ PUBLIC/EXTERNAL THIRD-PARTY CONSUMERS

[G2] package.json exports + bin + README install alternatives
     ├─ registry-installed package -> OpenCode plugin loader
     ├─ local dist JS path -> OpenCode plugin loader
     ├─ JS import of @yohi/justice/opencode and /core and /runtime
     └─ `justice` bin / doctor -> dynamic import(entryFile) + Bun.spawn

[G3] OpenCode host -> src/opencode-plugin.ts
     └─ OpenCodeAdapter -> observation / gate / review / local/global filesystem
         ├─ NodeFileSystem -> read/write/mkdir/rename/link/unlink under process OS identity
         ├─ .justice/events/*.jsonl + archive/ + state.json + gate.yaml + telemetry/wisdom
         ├─ global ~/.justice/wisdom.json or JUSTICE_GLOBAL_WISDOM_PATH
         └─ optional native provider -> createRequire(dist/native/index.linux-x64-gnu.node)
                -> Rust N-API -> openat2/renameat2 / file descriptor IO

[MISSING AUTHORITY EDGES] No verified `acceptedSeq + acceptedDigest + root`
from R11 acceptance is checked, atomically fenced, and consumed by each G1/G2/G3
actor at its effect/use point. The absence claim is confined to P1-traced paths.
```

Source anchors: `.github/workflows/ci.yml:3-40`; `.github/workflows/release.yml:3-73`; `package.json:12-53`; `README.md:72-96,115-165`; `src/opencode-plugin.ts:35-130`; `src/runtime/opencode-adapter.ts:182-190,227-304,646-710`; `src/runtime/linux-review-artifact-provider.ts:68-106,190-202`; `native/review-artifact-linux/src/lib.rs:12-19,100-120,181-209,268-315`; `src/runtime/doctor-cli.ts:109-205,220-309,494-539` (all at fixed Justice SHA).

**Graph scope precision:** CI and release workflow definitions prove *possible dispatch and effect declarations*, not that a specific job/release was triggered. Package exports prove a declared module path, not which bytes any host loaded. `git push`, third-party installer, old release, arbitrary downstream package consumer, root/admin/backup operations are **hypothesized or externally exposed** until separately grounded; do not describe them as executed.

## 2. Git ref/source graph, transition identities and bytes required by EAF

| Edge | Currently visible identity | Required stronger accepted/use identity, **not deployed** | Present gap / negative counterexample |
|---|---|---|---|
| Git event → runner checkout | `master` event or `release.outputs.tag_name` checkout in workflow | immutable tree object and every used path+mode+submodule and accepted scope/root/seq/digest; protected Git ref writer | a tag advances or contains source not equal to an accepted byte root; current runner not required to consult Gateway |
| Dependency input → third-party fetching | `bun.lock`, `native/review-artifact-linux/Cargo.lock`, `package.json`, Cargo manifest; `setup-bun@v2` and other GitHub actions | exact fetched archives, registry integrity, transitive build-time scripts, toolchain/runtime container hash, offline/reproducible derivation and provenance | same lock text does not independently attest to fetched code/toolchain or network downloads; no actual fetched-byte evidence |
| JS + `.d.ts` + sourcemaps + native `.node` → `dist/` | `tsconfig.json:3-25`, `package.json:43-44`; Rust cdylib | *all emitted* JS/types/maps/bundle/native ELF metadata and effective loader input file identities | checking only `dist/native/index.linux-x64-gnu.node` exists or is in dry-run pack does not attest its bytes |
| `dist/` → GitHub Actions artifact | `ci.yml:36-40`, `release.yml:51-56` | immutably bound accepted source and derived SHA-256 and independent attestation | CI-preview artifact might be mislabeled as a canonical accepted product |
| `dist/` → GitHub Packages | `release.yml:57-66`, `NODE_AUTH_TOKEN` | one frozen `npm pack` payload hash, upload registry receipt, pre-effect publisher admission, restricted token | `npm publish --ignore-scripts` is a direct remote publication operation; DB transaction cannot roll it back |
| tarball → GitHub Release asset | `release.yml:67-73`, distinct `npm pack` invocation | same frozen tarball identity as registry publish or explicit pair of digest-bound receipts; GitHub release asset digest; remote result reconciliation | separate pack invocations may produce bytes not proven identical; `gh release upload` uses a separate API/effect |
| registry/source → actual host | `package.json:12-41` exports + README alternate installs | installed package integrity, module resolution, actual loaded JS bundle, `import()` targets and on-disk native inode/hash at **use** | third-party users can import cached/locally built versions without invoking central Gateway |
| host JS → native N-API | `linux-review-artifact-provider.ts:190-202` `require(addonPath)` | verified ELF blob, loader-visible inode, descriptor/code-signature binding to accepted digest at `require` time | native addon replaced after package validation, or ABI/mount/loader differs |

Code anchors: `package.json:12-53,55-80`; `tsconfig.json:2-25`; `native/review-artifact-linux/Cargo.toml:1-19`; `native/review-artifact-linux/Cargo.lock:1-35`; `src/index.ts:108-125`; `src/runtime/linux-review-artifact-provider.ts:190-202`; `README.md:115-165`.

**Accepted identity finding:** No accepted `seq`/`digest` selection was established in *these traced* Git/CI/build/publish/install/runtime code paths. A Git ref SHA or `Cargo.lock` checksum cannot be substituted for an authoritative accepted `scope + seq + digest`, and the local JSONL record sequence is not a B2 accepted sequence. Source-to-EAF closure is **NOT_VERIFIED** end to end. This is not a statement that no other code path, later system, or platform feature could ever provide it.

## 3. Local effect and read edges are not PostgreSQL commitment

`src/runtime/node-file-system.ts:51-113,118-239` resolves paths but invokes ordinary Node path-based file operations. `src/runtime/write-queue.ts:35-106` serializes per-shard appends and swaps temporary files with `rename`; `src/runtime/observation-log-store.ts:127-220,248-404` reads/writes JSONL and archives and excludes malformed shards. `src/runtime/state-projection-cache.ts:19-60` maintains an independently mutable cache, while `src/runtime/gate-loader.ts:55-109` reads a local, caller-modifiable `.justice/gate.yaml`, including error fallback to default gates. `src/core/atomic-persistence.ts:103-217` uses a local tmp/hard-link-claim/rename routine; it does **not** prove a PostgreSQL acceptance transaction or unforgeable independent ACK. `src/core/justice-plugin.ts:208-262` creates a separate global wisdom directory. `src/core/telemetry-store.ts:47-57` defines `.justice/telemetry.json`.

Security reading: the native `openat2`/`renameat2` lease provider constrains its specific review-artifact operations; it is **not** a universal reference monitor for all host filesystem, Git, network, child, CI, or admin effects. Path checks are not evidence of an OS-enforced global no-bypass fence. A configurable source root or alternate global path introduces additional closure and custody obligations.

`src/runtime/opencode-adapter.ts:182-190` registers **only** `justice_review`. Although `src/runtime/justice-tools.ts:20-96` defines `justice_status` and `justice_gate`, these are **not exposed by this plugin registration** at the pinned SHA; retain CE-14/15 as definitions and potential imported consumers, not verified currently registered OpenCode tools. The public `justice_review` path (`justice-tools.ts:195-299`) reads JSONL and can request host approval to emit a resolution artifact; it does not consult an accepted B2 seq/digest.

`src/runtime/opencode-adapter.ts:646-710` skips `justice_*` tools, and catches before-hook errors by returning `PROCEED`. That visible fail-open branch is incompatible with claiming this adapter alone enforces a universal mandatory C1 admission barrier. **This is a source-level bypass opportunity, not a measured exploit or observed outcome.**

The `justice doctor` bin (`package.json:39-41`) is a materially different host entrypoint: it scans project/global config and logs (`doctor-cli.ts:220-309,320-460`), can spawn the external OpenCode process (`doctor-cli.ts:109-205`) and dynamically `import(entryFile)` (`doctor-cli.ts:494-539`). The latter two are runtime execution effects rather than passive static inspection and were **not executed** in P1. Include CLI diagnostics, config-reader and imported module graph in later trusted-domain planning.

## 4. External publication, issuer and reference-monitor trust limitations

Current `release.yml:3-11` requests GitHub token permissions that include writes to contents, pull requests and packages. This is source configuration evidence only; it does **not** establish an actually issued token, administrator rights, repository branch protection or organizational controls. At `release.yml:17-22,62-73`, release-please and release publication can reach external GitHub API effects without a source-visible C1 accepted-digest/seq precondition. GitHub Packages installation and third-party runtime use are not under the publisher's reversible transaction domain. A package previously published or copied outside the intended producer trust domain **cannot be compelled retroactively** to invoke Gateway. Address this explicitly as a potential C1-FULL scope/feasibility conflict, not by relabeling the canonical release or external consumers as irrelevant.

A P4 **proposed** split can keep PR/CI preview as **untrusted** (no trusted publishing), but currently `ci.yml` uploads artifacts and the canonical `release.yml` performs real release effects. Both remain in-scope until source-anchored migration and independent recheck. Necessary P2/P4 *candidate* controls include isolated trusted builder, sealable immutable source+output/EAF, a single credential-holding publish service whose effect is pre-authorized, complete effect receipts, and explicit IN_DOUBT handling for unknown external outcomes. The requirement to fence Git writes/tags/workflows, out-of-band API writes, privileged admins and backup/restore cannot be discharged by a PostgreSQL feature or GitHub environment protection feature description alone.

## 5. Typed proposed workstream interfaces — not certifications

| Producer → dependent track | Information P1 supplies now | Missing proof/required interface design (future only) | Status |
|---|---|---|---|
| P1 → P2 reference-monitor/OS | `01` path IDs, principals, direct effect methods and `03` credential matrix | `(effect_id, actor_identity, inherited capabilities/FD/mount/egress, pre-effect admission, trusted monitor owner, bypass denial)` including CI/GitHub API/shell/native/admin and root TCB | `INPUT_ONLY; P2 NOT_REVIEWED` |
| P1 → P3 authority/time/recovery | source/actual consumption points and concurrent local writer channels | `(scope, opId, acceptedSeq, sha256/EAF-root, issuer issue/revoke event, effective revoke order, expiry-vs-COMMIT instant, durable ACK prefix, restore/old-primary fence)`; explicitly resolve cross-domain signer limits | `INPUT_ONLY; P3 NOT_REVIEWED` |
| P1 → P4 external publication/host | workflow triggers, two packs, npm/GitHub token sites, package exports/native load | `(immutable build root, sealed package bytes, publisher custody, pre-effect admission, publish intent, GitHub receipt, ambiguous outcome, actual host-loaded bytes at t_use)` and third-party boundary | `INPUT_ONLY; P4 NOT_REVIEWED` |
| P1 → P-A1 independent host origin | host entrypoint map and fixed-loader assumptions | genuine H0/G1/G2 producer origin, same callId, messageId-null Case A, Senpi/OmO verified public API/host evidence | `NOT_VERIFIED; A1 SEPARATE` |
| P1/P2/P3/P4/P-A1 → P5 integrated redesign | only preliminary path inventory and STOP findings | reconcile producer/consumer trust scopes without circular acceptance, falsify all 22+37 and R11 38×7/INV14; prepare unsigned redlines | `STOP: P1 NOT_EXHAUSTIVE` |
| P5 → P6 / P7 | no adopted or independently proven interface | later fresh independent review; later separate DS-01..06 Owner decisions and normative R'→D'→P' sequence | `NOT_STARTED/NOT_AUTHORIZED` |

## 6. P1 axis outcomes (source-focused; not design validation)

| Axis | Outcome | Source-specific reason |
|---|---|---|
| A — consumer/source closure | **STRUCTURAL_CONFLICT** (current topology) | tag checkout, CI artifact, registry/release effects and arbitrary host import are not known to reference accepted EAF/seq; counterexample to *currently enforced* C1-FULL |
| B — B1 reference monitor | **REVISION_REQUIRED** | GitHub token, shell/native/FD, host FS and admin/bypass not fenced by any evidenced universal pre-effect custodian |
| C — B2 internal atomic acceptance | **FEASIBLE_DESIGN_CANDIDATE** for a **restricted single authority domain only**; cross-domain **STRUCTURAL_CONFLICT** | no deployed PG authority or single transaction coupling remote effects, signer/ACK, tags/packs and actual host bytes |
| D — issuer revocation and commit-time expiry | **STRUCTURAL_CONFLICT** with *unproved current cross-domain temporal semantics* | no verified same-serializer issued-at revocation or expiry-through-actual-durable-COMMIT proof; design cannot silently change R11 |
| E — signer, ACK, crash/backup freshness | **REVISION_REQUIRED** | durable independent signature/ACK and lossless restored prefix/old-primary fence absent from source evidence |
| F — R11 compatibility, 38×7/INV-A01..14 | **REVISION_REQUIRED** | original matrix remains unapproved/unmodified; new trust/dependency boundary requires separate counterexample review |
| G — provenance, A1 and runtime proof | **NOT_VERIFIED** | absent historic parent, sender SHA expected value, complete tree, actual package and host-loaded bytes; Task1 Case A and unknown-tool remain BLOCKED |

Axis C does **not** imply the feasibility of C1-FULL as a whole. `FEASIBLE_DESIGN_CANDIDATE` is a research option, not a tested or approved protocol. Future runtime tests are **NOT_EXECUTED**.

## 7. Decision and migration boundary

**P1 conclusion: `NOT_EXHAUSTIVE / INTERFACE_FREEZE_STOP`; C1-FULL cannot be declared ready.** The current direct release/package/host topology has an independently source-backed bypass of the *proposed* accepted authority; no incumbent valid enforcer has been verified. A C1-FULL replacement may remain a design research target, but the cross-domain authority, actual byte use and arbitrary public consumer guarantee must be explicitly resolved or reported structurally incompatible. No new Requirements/Design/Plan, R11 matrix, Owner signature or Gate outcome was created. See `04_P1_COVERAGE_AND_UNVERIFIED.md` for enumerated scope limits.
