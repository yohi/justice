# Justice RG-310-A-001 — Independent Source Provenance and Limitations

## 1. Independent byte-chain inspection (local file I/O only)

| Level | Expected / observed SHA-256 | Result |
|---|---|---|
| User-delivered outer ZIP | `41c36f387b7121a827c8b27d3c46214aae6c1b658aea466820305b64224da93a` | exact sender value MATCH; 5,274,025 bytes |
| R1 author original | `2a42e39450eb76f15f6a4df84af4ff68b56c538987544265e8881a6d0302dec7` | MATCH; 47,635 bytes; 8/8 R1 payload hashes |
| Prior remediation handoff | `16b1e4eb370aed9e282d2f9891c22cfd2d2ffae61a7dddc2c964d6a1454d8c81` | MATCH; 5,092,564 bytes |
| R11 original source ZIP | `1df24d4250132a3df1bc2c4d39b53baebbe1b1d8ad8060862c0531743601d185` | MATCH; 127,433 bytes |
| R11 original 38×7 matrix | `10b24dd4175ee2d5aae7929f8057355ce27e4db129480830549d756802010923` | MATCH; original byte-preserved file |
| Earlier reviewed independent technical result | `eb2957ef46bfea13122ea7a4422277c6d3b7efa1e4a5a48f9820cd929deeb964` | recovered in nested handoff; checksum/CRC consistent |
| Earlier reviewed handoff | `4a2cd007b7de0dc9c26384a15f2c2148c45f092a4b9aae434cee03d90a08ab74` | checksum/CRC consistent |
| Unavailable historic parent review | `735d9f0ce2b97d2b1543fb6a7a5d9a839b2ada30cb5a41e732f1115725d30160` | **NOT_VERIFIED**, source ZIP missing; no substitute allowed |

The historic missing parent is not the same as this handoff or any other archived nested ZIP.

Nested archive audit scanned **61 ZIP occurrences (23 distinct ZIP digests)**, all with passing `testzip()` CRC. Every one of **504 declared SHA256SUMS path/digest checks** matched. Manifest normalization across supported `files`, `sources`, `source_files`, `entries`, `results`, and nested `inputs.*.archive_path` structures verified **183 direct file entries and 8 linked nested ZIP references**, with zero mismatched declared hashes/byte counts. This verifies *contained bytes in this source chain*, not issuer signature, historical provenance beyond the supplied chain, or actual host behavior.

### Deep historical member checksum coverage caveat

Three repeated occurrences of identical nested `11_R9_TO_R10_USER_SUPPLIED_COMPLETE_DIFF_CONTEXT.zip` (`SHA-256 2437f58d5078a01de1b444cddc05b09842d46e7312d7720ad4be69c52d941866`) contain the 586-byte `README_DIFF_SCOPE.md` without an individual member entry in that ZIP's own `SHA256SUMS`. Calculated member digest is `666934f6472449f53eaf33635eb5053fac1f4cb567078d85de0f8d43dab0ec42` and is identical in all three duplicates. Their complete ZIP bytes are covered by the checksum-verified enclosing ZIP chain terminating at the independently supplied outer SHA. **Thus no declared digest disagreed, and byte identity of the nested archive is checkable; individual SHA256SUMS coverage for this one historical README is not complete.** Do not say 'every member SHA256SUMS covered', nor infer any unavailable external original's bytes from that. No incomplete input identity among the three separately expected main source ZIPs was found; if one had mismatched, the review should have stopped.

### Source ownership and fixed GitHub anchors

- User's latest R1 preservation HEAD: [`cf62c67459159febe048611b214732061c2261dc`](https://github.com/yohi/justice/commit/cf62c67459159febe048611b214732061c2261dc). Read-only GitHub commit metadata verified archival commit paths include seven R1 documents, README, MANIFEST, SHA256SUMS and the original ZIP. It is a Draft PR #325 archival event, not an adopted normative decision.
- R1 author-side earlier mentioned `2db995625e37c0573dcafe62ba0cd60e54e9ce0a`, independently resolved as a predecessor design-review/intake documentation commit. It is *not* substituted for the newer user's `cf62c674...`.
- Evidence HEAD [`c428041dfb5779b6b6dc8db7bf14928225a00373`](https://github.com/yohi/justice/commit/c428041dfb5779b6b6dc8db7bf14928225a00373), approved R'/D'/P' [`8a2e4f1536e9cad499ee7e9d996ff163df132fd4`](https://github.com/yohi/justice/commit/8a2e4f1536e9cad499ee7e9d996ff163df132fd4) verified as real commit identities by read-only fetch. Fixed upstream Senpi `d56e6a260d9468418a39bc9120945cf98e06b840` is a pinned claim from source contracts, **not independently re-audited upstream here**.
- Exact pinned source file GETs (read-only) succeeded: `.github/workflows/ci.yml`, `.github/workflows/release.yml`, `package.json`, `src/runtime/node-file-system.ts`, `src/runtime/observation-log-store.ts`, `src/runtime/write-queue.ts`, `src/runtime/justice-tools.ts`, `src/opencode-plugin.ts`. This is a deliberate source sample of real direct-consumer/effect edges, not an exhaustive repository or workflow listing.

## 2. Evidence class and findings limitations

1. R1 author ZIP names **22 current Finding IDs**: `B1B2-FI-001..014` plus `B1B2-NEW-015..022`. Historic parent digest `735d...` is not attached, so the exact literal original parent wording/chronology and closure claims cannot be authenticated. `02_22_FINDING_RECHECK.csv` preserves the current provided register wording and marks parent wording `NOT_VERIFIED`, all **OPEN**.
2. CE-01..CE-28 are **28 named census edges**, but CE-28 records uncensused future consumers. The static eight-file pinned review confirms significant direct routes, **not complete mediation** across GitHub admins/runners/dependencies/native loaders/network/host. A design claim that C1 has no hidden edges is false or unproven.
3. `NC-01..37`: supplied static symbolic traces only. **37/37 NOT_EXECUTED_DESIGN_ONLY**. Their 'expected oracle' represents a safety contract, not a demonstrated result. No future deployed Broker/DB test is demanded *now*.
4. R11 matrix was compared **38/38 exact Markdown rows across eight columns including state ID** between original source and R1 reprint. The 14 R11 F-table invariants are transcribed as exact original R11 cells into the audit; R1 only supplies ID-level retain statements, not their original full six-cell literal reprint. Previous-version R8 independent six-column byte comparison is not claimed. No approved R'/D'/P' file was modified.
5. Local archive self-consistency or archival Git blob does **not** independently establish human decision authority, phase human signature, HSA, production integration, host H0 capability, replay behavior, or any actual packet/release outcome.

## 3. Scope and prohibited activity confirmation

Review consisted only of local ZIP hashes, CRC/manifests, static Markdown/CSV extraction and original-matrix comparisons; plus read-only GitHub commit/file retrieval at supplied immutable refs. No GitHub writes, source/repo changes, OS/runtime/CI/build/DB/cloud/RPC experimentation, staging, host calls, external AWS/Senpi connections, secret retrieval, trusted signers, grants, human signature or formal Gate decisions. The generated output ZIP is a new local review **artifact**, not a change to any source repository or approved Plan.

`R11=UNAPPROVED`, `C1=NOT_ADOPTED`, `TRUSTED_OP_BOUNDARY_PROVEN=NOT_VERIFIED`, `OP_PREPARE_ALLOWED=UNKNOWN/BLOCKED+STOP`, `Task1=BLOCKED (31/32; Case A BLOCKED, Case B PROVEN, unknown-tool BLOCKED)`, `B-001=BLOCKED`, `B-002=NOT_PROVEN`, `DS-01..06=PENDING`, `Tasks2..14=NOT_AUTHORIZED`.
