# Justice RG-310-A-001 — R11 / B1/B2 Remediation R1 Fresh Independent Architecture Technical Review

**2026-10-21 JST | technical/static-only | unsigned | no Owner/Gate authority**  
**Overall technical finding: `REVISION_REQUIRED`; current legitimate consumer topology: `STRUCTURALLY_INCOMPATIBLE` with direct claim of B1/B2 DB authority, requiring `ARCHITECTURAL_REDESIGN_REQUIRED`; proposed restricted C1: `CONCEPTUALLY_PLAUSIBLE` only as an unadopted architectural hypothesis, with structural guarantee gaps.**

This is an independent *evaluation of claims*, not an approval of R1, any storage candidate, or a claim of completed isolation/runtime safety. No implementation, privileged access, host/CI/DB/cloud/OS experiments, signatures, phase HSA, or GitHub writes were undertaken. The source ZIP was parsed as data only. Neither the candidate nor an external independent review is allowed to change the existing normative Task1 evaluator.

## 1. Verified inputs and exact identity

| Input | SHA-256 / finding |
|---|---|
| Outer handoff ZIP (independently compared to sender's supplied expected SHA) | `41c36f387b7121a827c8b27d3c46214aae6c1b658aea466820305b64224da93a` — **MATCH** |
| R1 author ZIP | `2a42e39450eb76f15f6a4df84af4ff68b56c538987544265e8881a6d0302dec7` — **MATCH** |
| Prior remediation handoff ZIP | `16b1e4eb370aed9e282d2f9891c22cfd2d2ffae61a7dddc2c964d6a1454d8c81` — **MATCH** |
| Original R11 proposal ZIP | `1df24d4250132a3df1bc2c4d39b53baebbe1b1d8ad8060862c0531743601d185` — **MATCH** |
| Original R11 38×7 matrix file | `10b24dd4175ee2d5aae7929f8057355ce27e4db129480830549d756802010923` — **MATCH** |
| Missing historic parent independent-review ZIP | `735d9f0ce2b97d2b1543fb6a7a5d9a839b2ada30cb5a41e732f1115725d30160` — **NOT_VERIFIED / not attached** |

The supplied nested archive tree contains **61 ZIP occurrences / 23 distinct ZIP hashes**. All CRC checks and all **504 declared `SHA256SUMS` entries** match. Parsed manifest schemas yield **183 member + 8 nested-reference checks** with no mismatched declarations. **Exception of completeness, not an incorrect hash:** three occurrences of the same deep historical `11_R9_TO_R10_USER_SUPPLIED_COMPLETE_DIFF_CONTEXT.zip` omit the `README_DIFF_SCOPE.md` entry in their own `SHA256SUMS`, although the file and its surrounding whole ZIP are present and byte-identical under the checksum-verified parent chain. The three ZIPs have identical SHA-256 `2437f58d5078a01de1b444cddc05b09842d46e7312d7720ad4be69c52d941866`; unlisted README locally hashes `666934f6472449f53eaf33635eb5053fac1f4cb567078d85de0f8d43dab0ec42`. Do not call those 3 files independently listed/member-SHA-verified, and do not represent the missing historic parent as verified. See 06 provenance for the boundary.

Independent read-only GitHub fetch verified the immutable commits `cf62c674...` (R1 archive), `2db99562...` (older intake), `c428041d...` (Task1 evidence), `8a2e4f15...` (approved R/D/P) and eight direct-consumer implementation/configuration sources at the *exact* evidence HEAD. Current R1 author prose references preservation/intake HEAD `2db995...`; **the user's later actual archival HEAD `cf62c674...` supersedes it as the archival observation**, not as a normative adoption. No exhaustive repo-wide or historic upstream source audit is claimed.

## 2. Seven-axis adjudication — current (I) vs redesigned (II)

| Axis | Actual existing Git/CI/worktree/release/host topology (I) | Proposed C1 Gateway-mediated immutable namespace (II) | Required technical conclusion |
|---|---|---|---|
| **A. Actual source / consumer / effect root** | **`STRUCTURALLY_INCOMPATIBLE`**: CI and release read Git directly and publish JS/native packages without DB acceptance. JSONL is observation, not R11 accepted DB root. External package consumers may use unaccepted bytes legitimately. | `CONCEPTUALLY_PLAUSIBLE` for a new isolated accepted namespace only; migration, all reader/writer/effect graph closure, EAF/manifest identity and consumer transition not defined at implementation-contract completeness. | **`ARCHITECTURAL_REDESIGN_REQUIRED`** before claim over today's product lifecycle; alternative C2 is explicitly limited to a separate non-public acceptance domain. |
| **B. Trust isolation & complete pre-effect mediation** | **`STRUCTURALLY_INCOMPATIBLE`** if actor/workflow/host can execute direct shell, FD, native, Git writes, CI publisher credential or egress independent of Gateway. | `REVISION_REQUIRED`: OS capabilities, FD inheritance, root/admin, mount/namespace, native loader, network and separate CI principal are named but no complete platform enforcement interface/process graph or impossible-to-bypass boundary is specified. | DB RBAC is not a reference monitor. Every protected effect producer must be fenced before a single effect. |
| **C. Transactional accepted bytes + receipt + head + seq** | Ordinary local FS rename, Git ref updates, CI outputs and npm publication cannot enter one PostgreSQL ACID transaction. | **DB-internal `CONCEPTUALLY_PLAUSIBLE`** for immutable exact source bytes/root, receipt, status and acceptedSeq in *one* transaction with row counters. `REVISION_REQUIRED`: detached signing and public effects are outside it; two-threshold accepted-vs-visible model conflicts with existing unmodified accept proof semantics until explicit R'/D'/P' change. | Database atomicity by itself proves neither external signed acceptance nor cross-domain publication atomicity. |
| **D. Attested actual COMMIT-time & issuer revoke** | Uncontrolled job/host effects can start while epoch import is delayed; a timer checked before release does not bound actual upload/COMMIT. | **`ARCHITECTURAL_REDESIGN_REQUIRED`** for combined current strict source-issued revocation and real durable COMMIT-before-expiry: neither common serializer nor independently guaranteed t_commit upper bound is identified. | `now()`/preflight signer time/ACK/timeout are **not** an attested physical durable COMMIT timestamp. Fail closed or change the normative semantics by human review. |
| **E. External proof/ACK prefix/recovery** | Existing publisher ACK and GitHub release are provider effects unrelated to DB WAL rollback. | `REVISION_REQUIRED`: a post-COMMIT signature is a separate failure domain; external monotonic ACK prefix, visibility holdback, orphan recovery, restored-prefix verification and old-primary physical fencing remain conditional. | Need a single independent custody/serializing authority **or** formally accepted two-threshold replacement; recovery must quarantine on ambiguity. |
| **F. R11 matrix / invariants / R'/D'/P'** | Existing Task1 canonical gate unaffected; new DB cannot issue B0/B1/DEP/PREP/RA/ACTIVATE authority. | 38 original rows **identically reproduced** in R1; typed INV-A01..14 referenced but no amendment. Proposed R'/D'/P' changes not adopted. | **`REVISION_REQUIRED`** for normative compatibility if C1 retimes commit/revoke/external proof; no automatic changes to 38×7 or Task1. |
| **G. Source provenance** | Pinned eight code/config files and four commits independently retrieved by read-only GitHub. Not all consumers or all historical sources independently enumerated. | Main ZIP SHA/CRC/manifests verified; deeper 3 README per-member checksum omissions and missing historic parent remain explicit gaps. | **`NOT_VERIFIED`** only for absent parent history and exhaustive historical/consumer assertions, not for the four supplied archive identities. |

`CONCEPTUALLY_PLAUSIBLE` is *not* the same as an implementable full normative proof contract. The current proposal can express restrictions and STOP transitions, but under its existing concurrent issuer/DB/signer/effect topology it cannot establish all demanded guarantees merely by schema selection.

## 3. Direct consumers proven at pinned Evidence HEAD

- [`.github/workflows/ci.yml`](https://github.com/yohi/justice/blob/c428041dfb5779b6b6dc8db7bf14928225a00373/.github/workflows/ci.yml): direct checkout, dependency install, native artifact build, JS build/tests, upload of `dist/`; no mandatory accepted Gateway snapshot. **Observed static config, not proof of a specific actual CI run.**
- [`.github/workflows/release.yml`](https://github.com/yohi/justice/blob/c428041dfb5779b6b6dc8db7bf14928225a00373/.github/workflows/release.yml): `release-please` with `contents: write`, `pull-requests: write`, `packages: write`; conditional checkout of release tag; native compilation; artifact upload; `npm publish --ignore-scripts` to GitHub Packages; `gh release upload`. These are *capabilities/effect paths* not assumed actual executions. Publication may become externally visible independently of DB COMMIT.
- [`package.json`](https://github.com/yohi/justice/blob/c428041dfb5779b6b6dc8db7bf14928225a00373/package.json): distributed `dist/opencode-plugin.js`, `dist/index.js`, `dist/runtime/node-file-system.js` and `dist/runtime/doctor-cli.js`, with native `.node` in build/release workflow. A Git commit or file SHA is not automatically the complete emitted EAF import/native closure.
- [`src/runtime/node-file-system.ts`](https://github.com/yohi/justice/blob/c428041dfb5779b6b6dc8db7bf14928225a00373/src/runtime/node-file-system.ts): ordinary Node FS path operations; no R11 Broker mediation established.
- [`src/runtime/observation-log-store.ts`](https://github.com/yohi/justice/blob/c428041dfb5779b6b6dc8db7bf14928225a00373/src/runtime/observation-log-store.ts) and [`src/runtime/write-queue.ts`](https://github.com/yohi/justice/blob/c428041dfb5779b6b6dc8db7bf14928225a00373/src/runtime/write-queue.ts): `.justice/events/*.jsonl` and archive read/write; serialized shard temp file then rename. **This is an observation/log path, not an accepted R11 authoritative B2 publication** and does not prove either its isolation or equivalence.
- [`src/runtime/justice-tools.ts`](https://github.com/yohi/justice/blob/c428041dfb5779b6b6dc8db7bf14928225a00373/src/runtime/justice-tools.ts), [`src/opencode-plugin.ts`](https://github.com/yohi/justice/blob/c428041dfb5779b6b6dc8db7bf14928225a00373/src/opencode-plugin.ts): Gate/status projection from local logs and ordinary plugin/hooks. The local projection is not a substitute for independently accepted phase/host evidence.

### CE-01..CE-28 census — no claimed exhaustive coverage

| CE | Source named edge | Current documented authority | Independent disposition |
|---|---|---|---|
| CE-01 | CI checkout | `BYPASS_R11_CANDIDATE` | `DIRECT_PATH_STATICALLY_CONFIRMED`; `REQUIRED_BEFORE_B1B2` |
| CE-02 | CI build and upload | `OUTSIDE_DB` | `DIRECT_PATH_STATICALLY_CONFIRMED`; `REQUIRED_BEFORE_B1B2` |
| CE-03 | release-please | `OUTSIDE_DB` | `DIRECT_PATH_STATICALLY_CONFIRMED`; `REQUIRED_BEFORE_B1B2` |
| CE-04 | release tag checkout | `BYPASS_R11_CANDIDATE` | `DIRECT_PATH_STATICALLY_CONFIRMED`; `REQUIRED_BEFORE_B1B2` |
| CE-05 | release Build/native | `OUTSIDE_DB` | `DIRECT_PATH_STATICALLY_CONFIRMED`; `REQUIRED_BEFORE_B1B2` |
| CE-06 | npm GitHub Packages publisher | `UNMEDIATED_REMOTE` | `DIRECT_PATH_STATICALLY_CONFIRMED`; `REQUIRED_BEFORE_B1B2` |
| CE-07 | release asset uploader | `UNMEDIATED_REMOTE` | `DIRECT_PATH_STATICALLY_CONFIRMED`; `REQUIRED_BEFORE_B1B2` |
| CE-08 | npm package consumer | `PUBLIC_EXTERNAL_CONSUMER` | `LEGITIMATE_EXTERNAL_PACKAGE_CONSUMER_NOT_GATEWAY`; `REQUIRED_BEFORE_B1B2` |
| CE-09 | core entry loader | `DIRECT_RUNTIME` | `DIRECT_PATH_STATICALLY_CONFIRMED`; `REQUIRED_BEFORE_B1B2` |
| CE-10 | runtime entry/CLI | `DIRECT_RUNTIME` | `DIRECT_PATH_STATICALLY_CONFIRMED`; `REQUIRED_BEFORE_B1B2` |
| CE-11 | NodeFileSystem | `DIRECT_FS` | `DIRECT_PATH_STATICALLY_CONFIRMED`; `REQUIRED_BEFORE_B1B2` |
| CE-12 | observation JSONL store | `LOCAL_OBSERVATION_LOG` | `DIRECT_PATH_STATICALLY_CONFIRMED`; `REQUIRED_BEFORE_B1B2` |
| CE-13 | write-queue shard | `SINGLE_FS_NOT_DB_ATOMIC` | `DIRECT_PATH_STATICALLY_CONFIRMED`; `REQUIRED_BEFORE_B1B2` |
| CE-14 | justice_status tool | `DIRECT_JSONL_AND_CACHE` | `DIRECT_PATH_STATICALLY_CONFIRMED`; `REQUIRED_BEFORE_B1B2` |
| CE-15 | justice_gate dryrun | `DIRECT_LOCAL_GATE` | `DIRECT_PATH_STATICALLY_CONFIRMED`; `REQUIRED_BEFORE_B1B2` |
| CE-16 | OpenCode adapter | `LEGACY_PLUGIN_PATH` | `DIRECT_PATH_STATICALLY_CONFIRMED`; `REQUIRED_BEFORE_B1B2` |
| CE-17 | approved development workflow | `APPROVED_DIRECT_GIT_REFERENCE` | `APPROVED_GIT_DEVELOPMENT_CONTEXT_NOT_DB_AUTHORITY`; `REQUIRED_BEFORE_B1B2` |
| CE-18 | install scripts | `POTENTIAL_EXEC_EFFECT` | `STATICALLY_NAMED_EXTERNAL_OR_CONDITIONAL`; `REQUIRED_BEFORE_B1B2` |
| CE-19 | Git refs/main branches | `REMOTE_EFFECT_OUTSIDE_DB` | `STATICALLY_NAMED_EXTERNAL_OR_CONDITIONAL`; `REQUIRED_BEFORE_B1B2` |
| CE-20 | Senpi native host | `EXTERNAL_OPEN_A1` | `STATICALLY_NAMED_EXTERNAL_OR_CONDITIONAL`; `REQUIRED_BEFORE_B1B2` |
| CE-21 | Actor child grandchild | `UNTRUSTED` | `FUTURE_OR_UNIMPLEMENTED_OR_UNCENSUSED`; `UNIMPLEMENTED` |
| CE-22 | Protected FDs/mounts | `UNKNOWN` | `FUTURE_OR_UNIMPLEMENTED_OR_UNCENSUSED`; `UNIMPLEMENTED` |
| CE-23 | direct network/CI dispatch | `UNKNOWN` | `FUTURE_OR_UNIMPLEMENTED_OR_UNCENSUSED`; `UNIMPLEMENTED` |
| CE-24 | physical DB authority | `NOT_DEPLOYED` | `FUTURE_OR_UNIMPLEMENTED_OR_UNCENSUSED`; `UNIMPLEMENTED` |
| CE-25 | Gateway current reader | `NOT_DEPLOYED` | `FUTURE_OR_UNIMPLEMENTED_OR_UNCENSUSED`; `UNIMPLEMENTED` |
| CE-26 | backup/restore operator | `NOT_DEPLOYED` | `FUTURE_OR_UNIMPLEMENTED_OR_UNCENSUSED`; `UNIMPLEMENTED` |
| CE-27 | independent phase/RA verifier | `EXTERNAL_OPEN` | `FUTURE_OR_UNIMPLEMENTED_OR_UNCENSUSED`; `UNIMPLEMENTED` |
| CE-28 | unknown future consumers | `NOT_CENSUSED` | `FUTURE_OR_UNIMPLEMENTED_OR_UNCENSUSED`; `BLOCKS_COMPLETE_MEDIATION` |


**C1 replacement question:** Replacing all real legitimate product/build/release consumers requires a signed authoritative source-to-publisher/host cutover, provider-token isolation, exact accepted package identities, audit of loader/native subgraphs, and a compatibility agreement. A restricted C2 accepted-workspace-only namespace may be a useful *different product/security claim*, but it cannot be called equivalent protection over ordinary CI/npm/host behavior. CE-28 explicitly prevents the census from being advertised as complete.

## 4. Mandatory adversarial falsification (symbolic, NOT_EXECUTED)

**CE-X1 / RV-01,02,10 — public effect survives internal abort.** A valid Git release tag `A` is checked out by `.github/workflows/release.yml`; CI compiles and publishes npm package `P(A)` at remote provider time `t_p`. Gateway's accepted head is `B` or the DB later aborts `ACCEPT(A)` at `t_c`. Provider still serves `P(A)`. No database rollback can reverse the remote publication; a compensating unpublish would itself be a new external operation, not atomic rollback. **Finding**: current universal acceptance claim is contradicted. In C1, release publisher itself and its credentials must be independently gated and outcomes categorized `ACKED_WITH_PROVIDER_RECEIPT`/`IN_DOUBT`, never fold into DB COMMIT.

**CE-X2 / RV-03 — materialization-to-use interval.** Gateway hashes/reads source and lock/native closure at `t0` as H1. At `t1` a lifecycle hook, child, mutable hardlink or untrusted native addon replaces source/native `.node` with H2; compiler/host consumes H2 at `t2`. A rehash of the old path at `t0` cannot prove H2. All bytes/modes/symlinks, toolchain and transitive dependency/dynamic-load graph must be frozen in the effective build/use namespace; if arbitrary dynamic code/loaders remain, cannot certify complete exact EAF without scoping or denying those paths. **Do not infer a successful frozen snapshot now.**

**CE-X3 / RV-04 — issuer-effective revocation race.** Revocation source issues `R` with effective claim t0; DB hasn't received it. `ACCEPT` commits at t1; importer fences epoch at t2 (`t0<t1<t2`). If effective semantics is **issued-at-t0**, t1 ACCEPT is unsafe even though DB's local row was fresh relative to its own last-seen epoch. A strict effective order requires synchronous mutually exclusive commit/revoke arbitration; a fence-effective design changes when revocation is allowed to be declared effective, with blackout on uncertainty. **Neither is selected or mechanically specified**; merely polling epochs is not proof.

**CE-X4 / RV-05 — preflight vs actual durable COMMIT time.** `t_pre < t_expiry < t_durable_COMMIT`, perhaps due WAL/lock/scheduler/network delay. Preflight signed clock read, PostgreSQL `now()` transaction start, a timeout/cancellation signal, `clock_timestamp()` without independent attestation, and post-COMMIT ACK all fail to supply a proven safe `[T_commitLower,T_commitUpper]` enclosing actual COMMIT with `T_commitUpper<t_expiry`. A bounded validated commit protocol or explicit normative alternative is needed; if bound unavailable, `C1.COMMIT_ALLOWED=false`. Retrospective `REVOKED` should not be inferred solely from uncertainty; preserve `EXPIRED` or `UNKNOWN/BLOCKED` typed distinctions.

**CE-X5 / RV-06 — DB/signature/ACK not one atomic fact.** (`a`) T commits DB bytes/receipt at tC, external notary refuses at tS; if DB rows are already reader-visible as `ACCEPTED`, unsigned authority is exposed. (`b`) external receipt is pre-signed, then DB aborts; signature exists without accepted bytes. (`c`) DB commit succeeds, ACK lost, client retries while signer reorder delivers stale response; duplicate or mismatched confirmation risks occur. (`d`) external sealing persisted, second visibility marker fails; orphan certificate remains. **Conditional two-threshold protocol** must define non-public internal commit, notary witness, final visible marker, prefix ordering and recovery, and requires formal amendment if existing R11 demands a single atomic accepted+externally attested effect. A failed/timed-out signer cannot mean ABORT without exact no-effect proof.

**CE-X6 / RV-07 — ACK and backup/old-primary divergence.** Final client ACK and independent external witness include `(term1,seq=k,H1)`. A backup restore exposes H0 with `seq<k`, or primary P_old still serves READ_CURRENT while P_new has term2. Logical `physicalTerm` columns alone cannot stop old sockets/write credentials. Before any certified CURRENT, recover exact all-ACK prefix and content/WAL/terminal records, physical fence old primary **and old readers**, fresh time/issuer terms, and certify a monotonic witness. Otherwise quarantine; zero auto-failover is an explicit conservative choice, not evidence it has happened.

**CE-X7 / RV-08 — terminal accounting and inconclusive outcome.** Durable reservation `attemptSeq=7` PREPARED, no terminal after crash. Another operation at `attemptSeq=8` may be accepted only if phase semantics explicitly allow it and preserve unresolved 7 as a blocker; PhaseSeal cannot claim gap-free completion. `ABORTED` for 7 needs an independently durable no-authoritative/no-external-effect witness, not timeout. `acceptedSeq` counts successful accepted transitions only; gaps from native `nextval`/rollback must never be disguised. On unknown remote effect, `IN_DOUBT` rather than safe ABORT.

**CE-X8 / RV-09 — process/admin/CI escape.** Actor with inherited writable descriptor, `SCM_RIGHTS`, bind mount, `/proc`, `ptrace`, docker.sock, writable CI workflow/GitHub token, native `.node` side effects or raw egress can bypass a path-restricting API and affect Git/host/npm before inspection. If root/DB superuser/publisher admin is considered an attacker, stated guarantees fail; otherwise name these classes as trusted TCB and explicitly prove actor's inability to reach them. Role-based app checks do not constrain root or a host runner's secret mount.

**CE-X9 / RV-11,12 — R11 phases and A1 remain orthogonal.** Under fixed Senpi, G1/G2 may reuse `callId`; a DB receipt or ACK never proves genuine pre-run H0 ingress binding, actual H1/real origin-verified H2/H3, or Task1 actual delivered old success rejected. The canonical 32 count remains 31/32, Case A BLOCKED, Case B PROVEN, unknown-tool BLOCKED. `messageId` cannot be invented. `P` compiled, existing `R` runtime and future `I` production are not substitutes.

All nine classes and the additional old edge cases are cross-indexed across **NC-01..37** in `03_37_COUNTEREXAMPLE_ADJUDICATION.csv`. Each trace is a static model, not an experiment or a PASS.

## 5. RV-01..RV-12 review obligations — independent verdict

| RV | Independent check | Outcome |
|---|---|---|
| RV-01 | Real consumer completeness: release/CI direct checkout and packages | `REJECT_UNIVERSAL_AUTHORITY` / CE-01..08; completeness not proven |
| RV-02 | Disjoint Git/worktree/JSONL/EAF/DB roots | `REJECT_IDENTITY_COLLAPSE`; Git and local logs not accepted DB receipts |
| RV-03 | Byte identity actually at native/build/load use | `REVISION_REQUIRED`; immutability and dynamic closure not proven |
| RV-04 | Strict issued-at revoke vs fenced DB epoch | `ARCHITECTURAL_REDESIGN_REQUIRED`; missing common serializer |
| RV-05 | Signed precheck vs durable physical COMMIT bound | `ARCHITECTURAL_REDESIGN_REQUIRED`; missing attestable primitive |
| RV-06 | Independent signer/ACK with DB accepted record | `REVISION_REQUIRED`; externally atomic-equivalent proof not shown |
| RV-07 | ACK prefix, restore, physical fence and stale readers | `REVISION_REQUIRED`; separate witness/recovery service unspecified |
| RV-08 | PREPARED/ABORTED gap-free terminals | `CONCEPTUALLY_PLAUSIBLE` accounting grammar only; closure not established |
| RV-09 | OS root, child, FD/mount, CI/publisher TCB | `REVISION_REQUIRED`; policy/fence implementation-level contract absent |
| RV-10 | Remote npm/GitHub side effect nonrollback | `STRUCTURALLY_INCOMPATIBLE` with one-DB transaction claim |
| RV-11 | Original R11 38×7 and INV-A01..14 | 38/38 row copies exact; original preserved, **normative compatibility of C1 NOT PROVEN** |
| RV-12 | A1/Task1/unknown-tool/B-001/B-002 orthogonality | KEEP `BLOCKED`, no cross-Gate elevation |

## 6. Findings and non-closure

The `02_22_FINDING_RECHECK.csv` independently addresses **B1B2-FI-001..014** (14 from supplied current independent adjudication, **not authenticated literal missing-parent text**) and **B1B2-NEW-015..022** (8 new). **All 22 stay OPEN**; some are *design-response candidates* only, others require re-architecting authority. The words `CONDITIONAL_DESIGN_ONLY`, `REDESIGN_REQUIRED`, `STATIC_SOURCE_VERIFIED_PARTIAL` express evidence class, not resolved Finding. No finding is technically closed. Notably:

- Direct source/CI/release mediation (FI-002/008, NEW-015/019/022): **real structural conflict**, not simply an absent DB test.
- Time and revocation (FI-006/014, NEW-016/017): **normative/linearization incompatibility** until explicitly changed or supplied a qualifying common primitive.
- Internal/external proof and recovery (FI-003/005/007/011, NEW-018/020/021): **partial internal design only**, cannot close before atomic-equivalence, orphan and fencing semantics are fixed.
- H0/Case A/unknown-tool (FI-009) and Owner authority (FI-012): **external persistent blockers**, DB acceptance is irrelevant to their existing Gate.

The independent recheck found no basis for any CLOSED or PROVEN promotion. The counterexamples CEX-1..9 are independent attack reformulations, not newly executed traces. No new current Finding ID is invented to obscure the prescribed 22-ID register.

## 7. Original 38-state × 7-axis and INV-A01..14

The original matrix source is R11 `04-authorization-fingerprint-transition-matrix-R11.md` §§1–7 (original verified file digest above). Its **38 rows, 7 cells per row plus identifier** were compared directly against the reproduction in R1 `05_R11_38X7_COMPATIBILITY_AND_RDP_DELTA.md`; **38/38 full Markdown row lines match exactly**. This is a textual non-regression result, not validation of their implementability or phase predicates. The supplied output `04_38_STATE_7_AXIS_AND_INVARIANTS_AUDIT.csv` has 38 `STATE` records with **each original exact cell**, candidate collision, static decision and future evidence needs; and 14 `INVARIANT` records with the exact original R11 F-table assurance/Task1-R/product-I/negative control/Gate text. R1's INV ID-only summary is not an independent reproduction of all six invariant cells, so that cannot be claimed as a full copy-to-copy verification.

Especially protect row 05/06 (real commit/expiry), 09/22 (gap-free terminals), 16 (DEP_START latch before first edit), 18/19 (`bun.lock` EAF transitions), 25 (freeze at use), 30 (new attempt), 34 (H0 pre-run STOP), 35 (H1/H2/H3 genuine origin), 36 (31/32 and Case A/unknown-tool), and 37 (product `I` separate). INV-A07 requires actual old success to arrive after invalidation and be *rejected*, with genuine identity; INV-A10/A12 require positive raw-token sanitation and canonical JSONL readback; neither is proved by a DB ACK. Option **B** for R11 phased authorization is orthogonal to storage alternative **B** (S3 CAS+Postgres) and proposed **C1**.

### Exact candidate normative delta sequence (never enacted)

| Order | Candidate request for the human-governed R'/D'/P' process | Non-negotiable constraint |
|---|---|---|
| R'-01 | Delimit accepted authority scope: all legitimate product consumers **or** explicitly non-public restricted namespace C2 | No silent redefinition of Git/CI/release acceptance |
| R'-02 | Choose strict issuer-effective revoke total order **or** formally changed fence-effective rule | Expose issued-vs-effective gap, blackout, and stop policy |
| R'-03 | Define meaning and independent proof of operation durable COMMIT-time validity | Must not equate preflight or `now()` with actual COMMIT |
| R'-04 | Decide single-domain independent record atomicity vs deliberately non-atomic two-threshold visible accept | Never call a post-COMMIT signature an atomic original R11 receipt |
| R'-05 | Specify ACK-prefix, restore/fencing/terminal invariant and named accepted custody adversary model | No rollback of acknowledged prefix or guessed ABORT |
| D'-01 | Concrete service principal graph and end-to-end path/effect-to-enforcer table for all consumers and native/toolchain closure | No uncensused privileged or package publisher bypass |
| D'-02 | Physical kernel/FS/FD/network/CI/publisher fence and independent root/time/revocation custody | Model untrusted actor vs root/administrator precisely |
| D'-03 | Transaction and two-threshold recovery state machine, IDs, versioned canonical receipts, prefix and orphans | No accepted head visible without certified proof |
| D'-04 | An explicit implementable serializer/time bound, or abandon strict guarantee | Propose alternatives, not invented deployment proof |
| P'-01 | Static process/effect census, threat and proof matrix, NC-01..37 model checks | Future tests not in this review |
| P'-02 | Separately authorized prototyping/validation only after formally adopted R'→D'→P' | No B0/B1/DEP/PREP/HOST implied authorization |
| P'-03 | Future independent exact-load/commit/ACK/restore/physical-fence checks | Runtime evidence is a *later* separate gate |
| P'-04 | Separate fixed-Senpi A1/Case A/B-001/B-002 evidence acquisition | Never add production-I/B3 to existing Task1 denominator |

**Choice point:** if no attested true COMMIT upper bound and strict revocation serialization can be specified, the corresponding R11 guarantee cannot be met by the proposed loose DB-plus-independent-services arrangement. A restricted C2 domain or changed normative semantics is a **material program decision**, not a minor implementation detail.

## 8. Current STOP ledger

- R11 Option B staged authorization: `UNAPPROVED`; C1: `SPECIFICATION_ONLY`, `NOT_ADOPTED`; C2 alternative: `SCOPE_CHANGE_CANDIDATE_ONLY`.
- Approved Requirements/Design/Plan pinned at `8a2e4f1536e9cad499ee7e9d996ff163df132fd4`, no mutation.
- `TRUSTED_OP_BOUNDARY_PROVEN=NOT_VERIFIED`; `OP_PREPARE_ALLOWED=UNKNOWN/BLOCKED+STOP`; no phase HSA or ACTIVATE.
- A1 `H0/G1/G2=NOT_PROVEN`, origin-bound H1/H2/H3 not proven; fixed Senpi cannot be substituted by DB. NO HOST RUN.
- Task1 pinned `31/32 PROVEN`, **Case A BLOCKED**, **Case B PROVEN**, **unknown-tool BLOCKED** (messageId unresolved); Task1 remains **BLOCKED**. B-001 BLOCKED and B-002 NOT_PROVEN are separate; neither changes canonical 32.
- `INV-A01..A14` preserve gate-specific R/P/I meaning; compiled `P` not existing Task1 `R`, and product `I` not a Task1 required input.
- `DS-01..06=PENDING`, unsigned; Tasks2–14 `NOT_AUTHORIZED`. Design/Plan `FIX`, formal Gate PASS, safety PROVEN, implementation READY, HSA issuance and release authorization are **not conclusions of this review**.
