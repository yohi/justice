# RG-310-A-001 — C1-FULL P1.2 Independent Tracked-Tree / Effect Closure

**Verdict: `TRACKED_TREE_ENUMERATION_VERIFIED / EFFECT_CLOSURE_NOT_VERIFIED / P2_P3_P4_IF_STOP`.** This report is independent **static** research, not human approval or an execution grant.

## Deliverables

- `01_PINNED_TREE_431_COVERAGE.csv` — 431 verified tracked paths, mode, Git object SHA, semantic role, potential consumer, evidence basis, unresolved negative proof. Path-derived role for unreviewed blob bodies is explicitly flagged.
- `02_WORKFLOW_DISPATCH_AND_EXTERNAL_EFFECT_CENSUS.csv` — 31 source-defined edges across all six workflows, plus eight linked script/declarative files; exact blob SHAs and source line anchors, token references, potential writer and negative cases.
- `03_RECONCILED_CONSUMER_EFFECT_CENSUS.csv` — 82 original P1.1 rows with all 32 original column values retained, followed by 13 newly distinct append-only rows N-55..N-67.
- `04_U01_U12_AND_BOUNDARY_ADJUDICATION.csv` — 12 gaps separated into tracked-tree, semantic source, external writer/receiver and runtime/effective-control scopes.
- `05_P1P2P3P4_INTERFACE_READINESS.md` — evidence verdict, P1–P4 conditional proposal and prohibited interface freezes.
- `06_PROVENANCE_AND_LIMITATIONS.md` — measured input integrity and independent Git API evidence; remaining boundaries.
- `07_EFFECT_GRAPH_AND_NEGATIVE_BOUNDARIES.md` — directed conceptual source→runner→dist→published artifact→Host graph and explicit unverified edges.
- `08_OPEN_FINDING_AND_NC_UNCHANGED_REGISTER.csv` — 22 Finding OPEN + 37 NC NOT_EXECUTED, verbatim original IDs/status from the verified P1 input archive, with no promotion.
- `09_VALIDATION_SUMMARY.json` — self-consistency tests for output counts and the original 82-row value preservation.

Current ZIP SHA-256, CRC, SHAs and manifest describe **this** output only; they do not sign it, prove runtime/public effects, alter R11 or grant Owner authority.
