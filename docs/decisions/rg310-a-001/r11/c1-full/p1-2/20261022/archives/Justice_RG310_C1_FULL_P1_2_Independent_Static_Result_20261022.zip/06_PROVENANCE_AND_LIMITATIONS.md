# P1.2 Independent Provenance, Byte Integrity & Falsification Limits

**Date / authority:** 2026-10-22 JST; new independent read-only static investigator; not P1/P1.1 author, P2–P4 architect, human Owner or Gate reviewer. No user-supplied scripts, repository scripts or commands were run. All local parsing/generation was performed using independently authored standard-library Python code. GitHub access was solely GET-only fixed-ref metadata/source reads; no Github writes or live tests.

## Independently measured source artifacts

| Input | Independently measured or independently queried evidence | Verdict |
|---|---|---|
| Current uploaded handoff ZIP | SHA-256 `851b397be2df888e7006bd0edc3616f3dd89493708153f7d450fea6d625cf750`, matching separately supplied expectation | MATCH; archive CRC PASS (7 members) |
| Current ZIP `SHA256SUMS` / `MANIFEST.json` | Five payload files including two Markdown and three nested originals, all SHA-256 & byte counts independently recomputed | PASS 5/5, 5/5 |
| Embedded P1.1 original | SHA-256 `6a1b5915a3d2e6e90f9287b9d8f116e04aa36d54adef365eed4816bbb3003613`; CRC; `SHA256SUMS` (6/6); MANIFEST payload checks | PASS local byte integrity |
| Embedded P1 original | SHA-256 `2407afbe5deedb42f86e1b65ec9be0aeb02b28e13192253d34e77df02142df7e`; CRC; `SHA256SUMS` (20/20); MANIFEST payload checks | PASS local byte integrity |
| Embedded R11 original | SHA-256 `1df24d4250132a3df1bc2c4d39b53baebbe1b1d8ad8060862c0531743601d185`; CRC; `SHA256SUMS` (8/8) | PASS local byte integrity; R11 ZIP contains **no MANIFEST.json**, so no such check claimed |
| Previous historical parent ZIP | SHA-256 cited `735d9f0ce2b97d2b1543fb6a7a5d9a839b2ada30cb5a41e732f1115725d30160` but original bytes not supplied | **NOT_VERIFIED**, cannot infer ancestry |

ZIP CRC and checksum match identify current bytes against claimed digests; they are **not a trusted signature or historical authorship**. No credentials, signing keys, HSA, remote execution environment or cloud resources were accessed.

## New independent GET-only Git evidence, not retrospective P1.1 proof

- `GET /repos/yohi/justice/git/commits/c428041dfb5779b6b6dc8db7bf14928225a00373` returned same commit SHA and its tree SHA `2c1e8bd2f57cdc4eb47cf6a07b5934704c1b18f4`.
- `GET /repos/yohi/justice/git/trees/2c1e8bd2f57cdc4eb47cf6a07b5934704c1b18f4?recursive=1` returned **431 entries**, `truncated=false`, **386 blobs and 45 trees**. Mode breakdown: `100644` 385, `100755` 1, `040000` 45, no observed submodule (160000) or symlink (120000) entry.
- Independently read fixed PR #325 coordinator file `docs/decisions/rg310-a-001/r11/c1-full/p1-1/20261022/PINNED_FIXED_TREE_431_ENTRIES.tsv` at commit `bdf58da13db977bbd0d4a2e82ad7632837c9ccbf`. GitHub returned blob SHA-1 `b0bd93bc0988b88a0b59e00f5932b46789ff9755`. Compared every TSV row against independent Git tree API row in order, on **path, mode, type and object SHA; 431/431 exact matches**.
- The 431-row coverage CSV was reconstructed from the independent Git API, not substituted from the coordinator's claimed summary. Hashes are *Git object IDs*, not local SHA-256 of source contents. Directory entries are tree object hashes, not blob objects.
- Exact fixed-ref source content and blob SHA were fetched for all six workflow files, `package.json`, `scripts/release-version-guard.mjs`, `.github/CODEOWNERS`, `.github/dependabot.yml`, `.release-please-config.json`, `.release-please-manifest.json`, `native/review-artifact-linux/build.rs`, `tests/release/release-version-guard.test.mjs`, `sonar-project.properties`, `codecov.yml`, `.gitignore`, `tsconfig.json`, `src/index.ts`, and `src/runtime/linux-review-artifact-provider.ts`. These 20 source files agree with tree objects.
- P1.1 described 33 source-file SHA matches. In this report, **25 more pinned paths** are retained as P1.1-only claimed witnesses, excluding 8 refetched overlaps; 341 tracked blobs have SHA/path evidence but are **not individually semantically read** for this investigation. A path-only semantic role in `01` is explicitly marked `PINNED_PATH_INFERRED_ROLE` and is not executable source closure.

GitHub source URL templates for independent verification:

- `https://api.github.com/repos/yohi/justice/git/commits/c428041dfb5779b6b6dc8db7bf14928225a00373`
- `https://api.github.com/repos/yohi/justice/git/trees/2c1e8bd2f57cdc4eb47cf6a07b5934704c1b18f4?recursive=1`
- `https://raw.githubusercontent.com/yohi/justice/bdf58da13db977bbd0d4a2e82ad7632837c9ccbf/docs/decisions/rg310-a-001/r11/c1-full/p1-1/20261022/PINNED_FIXED_TREE_431_ENTRIES.tsv`
- Fixed source: `https://github.com/yohi/justice/blob/c428041dfb5779b6b6dc8db7bf14928225a00373/.github/workflows/release.yml`

## Exact source identity for newly anchored effects

| Path | Git blob SHA-1 | Lines/material effect |
|---|---|---|
| `.github/workflows/codecov.yml` | `3767d2f3b187623ebedd0cf9f4b93f1fbba236f0` | L73–78 Codecov, L80–114 SonarCloud; PR write declaration at L84–86 |
| `.github/workflows/release-version-guard.yml` | `4fb66c1b49e022796cd51ff956b7793de8383cfc` | L3–22 guards, L23–40 version check |
| `.github/workflows/semgrep.yml` | `763eec4ff600d8083a97114c209344bc421422ba` | L13–25 external image + SARIF upload |
| `.github/workflows/snyk.yml` | `58fae0a04274384530debc9ce0aed66116faa012` | L15–38 conditional token/Snyk/SARIF and `continue-on-error` |
| `scripts/release-version-guard.mjs` | `885f78af3193b6d2e7037908e327ed9aafc51441` | L4–61 version parse/compare and process exit only |
| `.github/dependabot.yml` | `e71011d733b0b73a75fbfa9de3953412ee8db2ba` | L1–13 weekly npm and monthly Actions PR definitions |
| `.github/CODEOWNERS` | `87062bb86203d3d1d65e69cd0c45671dedfd5a65` | L1–2 owner review routing declaration |
| `codecov.yml` | `7327f3f66e8077f3e9e00edbd771e6803815a3d1` | L1–22 quality status/comment declaration |
| `sonar-project.properties` | `e53b050a254000879f03f760a00979e98b7f0e81` | L1–10 external scanner project and host |
| `native/review-artifact-linux/build.rs` | `0f1b01002b079d101cc8ccc17a3b1fab5d84068e` | L1–3 `napi_build::setup()` build time linkage |
| `tests/release/release-version-guard.test.mjs` | `cb902b3acfc0ac928dc6898d22f1deda648e69c2` | L1–39 subprocess test authored, execution not done |

Sources are untrusted evidence data. No third-party action source, container image digest, lockfile resolved body, `dist` bytes, actual npm tarball, registry readback, released asset, GitHub runner logs, SonarCloud/Codecov/Snyk live result, repo settings, secrets, signer or Host loaded bytes was independently acquired. `ci.yml` and `release.yml` had been partly captured by P1.1 but were re-read now against the same tree.

## Limits, negative proof and preservation rules

1. **Enumeration≠closed semantics:** `truncated=false` excludes missing *tracked rows in the returned tree* only. Source imports/call graph inside the 341 unreviewed blobs, untracked files, generated `dist`, mutable dependencies, CI runner configuration and third-party consumers are outside that conclusion. A complete tracked-tree listing must not be called P1 completion.
2. **Permission request≠effective right:** workflows declare `security-events:write`, `pull-requests:write` or `packages:write`; GitHub installation/repository/org policies, environment rules, branch/tag protection, token attenuation, admin/backdoor writes and external accounts were **not** established.
3. **Source-defined action≠executed action:** workflows/actions and `scripts/release-version-guard.mjs` were read as text only. No lint/tests, `npm pack`, `gh`, `bun`, `cargo`, `semgrep`, `snyk`, `node` review-source code, runtime instrumentation or deployment was run. The new report-builder itself is independently authored, not copied from sources.
4. **Byte equality not transitive:** `package.json` points to expected `dist`/native outputs, while the release workflow verifies only a *dry-run listing* then invokes npm publish and a separate actual npm pack for asset upload. No `dist`/ELF/tarball/registry/release/host bytes can be equated without independent evidence.
5. **Scope C1-FULL conflict remains structural:** no private gateway can force already distributed, uncontrolled third-party copies to consult it. Cooperation and producer-owned future publication can be designed; universal retroactive custody requires an explicit and independently enforceable external platform, not assumption or silent scope weakening.
6. **Unchanged baseline:** P1.1 82 original rows/32 fields preserved value-for-value; N-55..N-67 append-only. Existing 22 Findings OPEN, NC-01..37 NOT_EXECUTED, R11 38×7 and INV-A01..14 unchanged, Task1 31/32 and Case A/unknown-tool BLOCKED, DS-02 PENDING, R11 UNAPPROVED, P2–P4 IF STOP.

**Bottom line:** `SOURCE_TREE_STATIC_VERIFIED`, **not** `FULL_SOURCE_EFFECT_CLOSURE`, **not** `INTERFACE_READY`, **not** `APPROVED`.
