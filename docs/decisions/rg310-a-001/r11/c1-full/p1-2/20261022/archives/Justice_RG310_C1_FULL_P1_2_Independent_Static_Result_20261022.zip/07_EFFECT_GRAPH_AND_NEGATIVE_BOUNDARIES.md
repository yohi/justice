# P1.2 Directed Producer / CI / Host Effect Graph and Counterexample Stops

**Static conceptual graph only.** Solid nodes/links below describe links observable in *source definitions*. The drawing does **not** imply any GitHub workflow ran or any external side effect succeeded. `NOT_VERIFIED` edges require independent runtime/actor evidence. This is not an instruction to run anything.

```mermaid
flowchart TD
  A[Fixed commit c428041d] --> B[Root tree 2c1e8bd2]
  B --> C[431 tracked objects / six workflow YAMLs]
  C --> CI[ci.yml / codecov.yml]
  C --> REL[release.yml / guard.yml]
  C --> SEC[semgrep.yml / snyk.yml]
  C --> PKG[package.json / JS TS / Rust / scripts]
  C --> BOT[Dependabot / CODEOWNERS]
  CI --> ACT[Actions / Bun / Rust / external deps: unverified]
  REL --> ACT
  SEC --> ACT
  ACT --> D[dist JS / native ELF: bytes unverified]
  PKG --> D
  REL --> DRY[Dry run npm pack file listing: not a tarball digest]
  D --> DRY
  D --> PUBLISH[npm publish: effective writer unverified]
  D --> REALPACK[Second npm pack: bytes unverified]
  REALPACK --> ASSET[gh release upload: external receipt unverified]
  PUBLISH --> REG[GitHub Package tarball: bytes unverified]
  REG --> HOST[External installer / local imports / host loader unverified]
  ASSET --> HOST
  HOST --> EFFECT[Potential local FS / native FD / process effects unverified]
  CI --> COVER[Codecov SonarCloud external effects unverified]
  SEC --> SCAN[Code Scanning SARIF external effects unverified]
  BOT --> PR[Dependent external PR/review actor unverified]
```

## Edge semantics / no overreach

| Directed edge | Source-defined evidence | Independent witness needed before effect claim |
|---|---|---|
| Git commit → tree → tracked source | GitHub commit and recursive Git tree API, coordinator TSV 431-row reconciliation | None for *tracked enumeration* at this fixed commit; untracked/external universes remain outside |
| YAML → Actions runner/deps | Six immutable workflow blobs, referenced action identifiers, `package.json` | Live event, runner build logs, action body/digests, dependency graph, constraints and token rights |
| package/native sources → dist | `package.json` build and native scripts; `build.rs` pinned | Reproducible independently hashed JS/ELF build results, external toolchains and input material |
| `dist` → `npm pack --dry-run` | `release.yml` L57–61 checks only `dist/native/index.linux-x64-gnu.node` entry | Actual dry-run report if claiming it passed; listing does not bind tarball or uploaded bytes |
| `dist` → GitHub Packages | `release.yml` L62–66 `npm publish --ignore-scripts`; `package.json` publish registry | Successful token authorization, registry receipts and immutable package bytes/digest |
| `dist` → second pack → GitHub Release asset | `release.yml` L67–73 invokes new `npm pack` then `gh release upload` | Second pack byte hash, asset readback/tag commit/GitHub actor signature and receipt |
| package/asset → JS/N-API / OpenCode loader → protected effect | Package export/CLI paths and runtime/native loader source definitions | Real installed host config, exact loaded JS/ELF byte identity, direct/indirect imports, ingress/origin binding and pre-effect fences |
| scanner YAML → Codecov, SonarCloud, GitHub Security | `codecov.yml`, `semgrep.yml`, `snyk.yml`, quality configs and secret references | Actor/secret availability, event/run, action code and external upload/readback |
| Dependabot/CODEOWNERS declarations → PR/review | `.github/dependabot.yml`, `.github/CODEOWNERS` | Service enablement and GitHub admin/settings/branch protection/reviewer-effective gates |

## Key security and semantic counterexample classes

- **External writer / mutable action:** release workflow YAML requests broad `contents`, `pull-requests`, `packages` write permissions, and scanner jobs request `security-events:write`; source declarations are not proof of effective least privilege or complete admin/app/ref writer enumeration. Scanner and helper action tags such as `@v3`, `@v7`, `@v2` and the Semgrep container can be mutable without an independently pinned digest.
- **Guard scope insufficiency:** version guard only runs on master PRs changing `package.json` or `.release-please-manifest.json`, with `github.head_ref` beginning `release-please--`; a successful version comparison cannot constrain alternative publisher actors, out-of-band refs/tags, workflows or third-party registries. The linked `release-version-guard.mjs` writes only stderr/process exit in its own code.
- **Nonblocking scanner:** Snyk scan is conditional on nonempty SNYK_TOKEN and has `continue-on-error: true`; a `snyk.sarif` existence condition determines upload. Neither source declares a universal publication gate.
- **Artifact divergence:** a dry-run `npm pack` membership check, `npm publish`, and a later real `npm pack` are **three distinct operations**. No source-only SHA/sequence fence connects them to an accepted EAF or eventual host consumption; even two observed tarball names would not establish identical bytes.
- **Host runtime alternatives:** package subpath exports, CLI `bin`, Markdown/manual direct imports, dynamic doctor imports, plugin registration and native addon loading create potential separate consumers. A textual symbol or compiled export is not a published/registered/loaded tool or a verified origin.
- **Strict universal C1-FULL:** a private producer-owned Gateway has no coercive authority over preexisting non-cooperating third-party copies. Signed artifacts and guarded cooperating readers supply positive narrow guarantees, not universal retroactive effect control. **DS-02 remains PENDING**.
- **Temporal and revocation:** DB COMMIT, issuer revoke time, sequence/digest validity, expiry and external signer ACK are distinct trust domains with crash/TOCTOU windows; R11 matrix is a proposal with no formal Gate or runtime proof.

## Negative outcome remains explicit

P1.2 supports **only the first edge (fixed tracked Git objects) as independently verified**. It does not close U-02..U-12, actual CI release publication, non-cooperating third-party effects, GitHub admin writes or real host byte identity. Read `04_U01_U12_AND_BOUNDARY_ADJUDICATION.csv` for category-specific status and `05_P1P2P3P4_INTERFACE_READINESS.md` for the unchanged STOP.
