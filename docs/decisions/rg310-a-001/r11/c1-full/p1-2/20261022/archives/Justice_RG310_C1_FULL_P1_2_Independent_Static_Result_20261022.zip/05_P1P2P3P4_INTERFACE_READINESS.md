# Justice RG-310-A-001 — C1-FULL P1.2 source/effect and interface readiness

**Date:** 2026-10-22 (JST)  
**Decision class:** `INDEPENDENT_STATIC_INFORMATION_ONLY / UNSIGNED / NO EXECUTION GRANT`  
**Fixed Justice commit:** `c428041dfb5779b6b6dc8db7bf14928225a00373`  
**Root tree:** `2c1e8bd2f57cdc4eb47cf6a07b5934704c1b18f4`

## Independent verdict

**`TRACKED_TREE_ENUMERATION_VERIFIED / EFFECT_CLOSURE_NOT_VERIFIED / P2_P3_P4_INTERFACE_FREEZE_STOP`.**

This verdict **replaces no original finding or permission**. A GitHub GET-only fixed commit points to the stated root tree. Its recursive listing returned `truncated=false` and 431 entries (386 blobs, 45 trees; 385 regular non-executable blob modes, one executable `100755`, 45 directory tree modes). The separately uploaded coordinator TSV at PR #325 commit `bdf58da13db977bbd0d4a2e82ad7632837c9ccbf` reports blob `b0bd93bc0988b88a0b59e00f5932b46789ff9755`, and **all 431 TSV entries exactly matched** the independently fetched GitHub recursive tree, comparing path/mode/type/object SHA in sequence. This evidence is new relative to P1.1, not retrospective proof by P1.1.

Tracked-tree enumeration proves **what Git declares tracked at that fixed commit**, not which JS/Rust paths are reachable, which deployment binary is loaded, which secrets/permissions are effective, nor which third-party copies exist. No source-universe/external-effect-universe completeness claim follows. Explicit count of unique blob witnesses represented in `01`: 20 fresh P1.2 fixed-ref content reads, 25 additional carried P1.1 pinned source-file claims, 341 tracked blob paths with SHA/mode only (no source-content semantic verification in P1.2 or documented P1.1 anchor). The 45 tree directories are not executable blobs. The prior witness status remains an imported historical report unless re-fetched.

## Scope and status by workstream

| Workstream | Allowed **conditional research hypothesis** | Important unresolved proof | Interface freeze |
|---|---|---|---|
| P1 source/effect census | Bounded tracked Git tree can now be used as a complete **fixed-tracked-object inventory**. The newly pinned CI workflows and script link into the existing 82 pathways by 13 additive paths. | Many blob bodies/import edges unreviewed; third-party actions/registries/host configs and actual consumers outside tree; effective actor permissions. | **P1 FULL NOT CLOSED**; no `SOURCE_EFFECT_CLOSURE_COMPLETE` |
| P2 producer/publication custody | A proposed publication boundary could combine independent GitHub ref/release/package writers, signed build receipts, immutable artifact digests, and fail-closed publication authorization. | Who can modify tags/branch/rulesets, invoke Actions, publish packages, override PR checks, sign, or backfill old artifacts; exact `npm pack`/published byte identity and external service state. | **STOP** — model only; no custody/interface freeze |
| P3 materialized consumer/host fence | A cooperating reader could verify signed artifact identity, accepted EAF scope/sequence, revocation epoch and exact bytes immediately before *its* protected effect. | Host loader/ingress/origin H0–H3, actual installed OmO/Senpi byte and initialized plugin, native/FD lineage, direct imports and child process/OS bypass. | **STOP** — model only; no middleware/host interface freeze |
| P4 cross-actor proof/gate | A staged symbolic proof plan may enumerate negative tests for commit/revoke/expiry, independent actor acknowledgment and crash recovery without invoking them. | Atomic DB accept vs remote publish, origin and independent signer, authentic ACK, negative NC-01..37, field verifications; R11 not approved. | **STOP** — plan only; no execution/test or phase authorization |

### P2–P4 interface-freeze condition

No interface is eligible to freeze before (1) independently substantiated full **semantic** source/import/effect edge closure (not just pathname enumeration), (2) Owner DS-02 resolution of strict C1-FULL effect scope and external actor custody, (3) reviewable positive/negative proof obligations for GitHub and publication/host byte identity, and (4) formal R/D/P and Gate approvals. Independent reviewers must be able to falsify the claims. A design plan may be drafted provisionally; it does not change STOP.

## Core causal path (directed and evidence-ranked)

- Git commit `c428041d…` → **tree SHA matched** `2c1e8bd2…` → **431 tracked source/config paths verified**.
- Workflow files → **six source-defined GitHub Actions dispatch paths** (`ci`, `codecov`, `release-version-guard`, `release`, `semgrep`, `snyk`) → called actions/runners/toolchains: **source-declared only; running action and permissions NOT VERIFIED**.
- `package.json` exports/CLI and scripts → Rust `native/review-artifact-linux/build.rs`/Cargo and Bun/TypeScript build commands → `dist/` JS and `dist/native/index.linux-x64-gnu.node`: **intended output, bytes NOT VERIFIED**.
- `release.yml` → `npm pack --dry-run --json --ignore-scripts` verifies presence of the named native item **in a dry-run file listing**; it does **not** prove tarball hashing. Workflow separately invokes `npm publish --ignore-scripts` and later `npm pack` again, then `gh release upload`. No hash, byte equality, registry receipt, release asset receipt or actor attestation was obtained.
- Published package/asset → configured installer/importer/OpenCode loader → package export/CLI/JS/native addon → real protected effect: **no host-loaded bytes or actual effect proven**. An independently downloaded or previously distributed copy cannot be forced back through a private gateway by mere producer-owned software design.
- Scanner branches: Codecov/SonarCloud, Semgrep/Code Scanning, Snyk/Code Scanning, and scheduled Dependabot updates create *source-defined external action/potential writer paths*; no completed external write was observed.

The detailed per-edge source line/credential/effect/negative-case record is `02_WORKFLOW_DISPATCH_AND_EXTERNAL_EFFECT_CENSUS.csv`; the DAG and open proof edges are also diagrammed in `07_EFFECT_GRAPH_AND_NEGATIVE_BOUNDARIES.md`.

## Distinct newly identified census paths

`N-55..N-67` were **appended**, never substituted for `CE-01..CE-28` or `N-01..N-54`. They represent separate external target or code path, including Codecov upload and its policy config, SonarCloud PR-capable scanner/config, version guard trigger/script/test, Semgrep security report writer, Snyk conditional security report writer, Dependabot two update ecosystems, CODEOWNERS routing, and native `build.rs`. None is an assertion the component actually ran, a secret existed, or an external report was accepted. Some new rows explicitly cross-reference older generalized build or release nodes; new IDs are not counted as proof that the complete semantic graph is closed.

Source-defined tool vs actual registered tool vs actually invoked host tool must be disambiguated: presence in source/export/package config, command-registration code, test fixtures or README is **not** proof a host loaded or published that tool. The original `justice_status`/`justice_gate` registration uncertainty and dynamic doctor/child import are not silently promoted. Package exports (`.`/`./opencode`/`./core`/`./runtime`) and binary CLI (`justice`) are potential entrypoints, not traced deployed readers.

## Structural conflict: C1-FULL against arbitrary third parties

The strict unconditional hypothesis “the private producer-owned Gateway must be consulted for every effect of every previously distributed copy, including copies held by non-cooperating third parties” is **not implementable using only producer-controlled GitHub/registry/Gateway actors**. Old packages, forks, manually imported source, private copies, and offline/direct loaders can continue to execute if they are already controlled by a third party; new signed artifact policies cannot retroactively rewrite those bytes or coerce their owners. Signed artifacts can allow *cooperating* guarded readers to reject unauthorized material, and publication/producer-controlled environments can fence **future producer-controlled** writes; neither is universal third-party enforcement. Accordingly the strict requirement is a **structural Owner/normative conflict requiring DS-02**, not a missing isolated coding task. **No silent C2-LIMITED substitution or scope reduction is approved.** If an authority outside third-party control is proposed, it must be explicitly stated, auditable and technically substantiated by Owner process.

## Nonregression and authority separation

| Original protected register | P1.2 status |
|---|---|
| R11 proposal and 38-state × 7-axis decision matrix | **UNAPPROVED, unchanged; no authorization uplift** |
| `INV-A01..A14` | **Preserved; no runtime proof inferred** |
| Task1 canonical evidence | **31/32 PROVEN**; Case A **BLOCKED**; Case B **PROVEN**; unknown-tool **BLOCKED** |
| Existing independent 22 Finding IDs | **OPEN, NOT CLOSED** |
| NC-01..NC-37 | **NOT_EXECUTED** |
| DS-02 | **PENDING; no human signature** |
| B0/B1/B2/HOST/CI/DB/cloud/OS/RPC | **No tests, no grants, no activation** |
| P2–P4 interfaces | **STOP / NOT_FROZEN** |
| Previously cited historical parent `735d9f0c…` | **NOT_VERIFIED**, bytes absent |

**This document conveys source evidence, not Owner/Gate approval, R/D/P modification, release authorization, nor permission to execute a proof plan.**
