# P7 — Possible R' normative delta skeleton (NOT_ADOPTED)

**This document is only a diff outline for a future separately authorized Requirements-first revision.** It is not an amendment to approved v5, not a new Design/Plan, and not an executable contract.

| Candidate ID | Requires explicit future decision on | Falsifiable requirement candidate and non-equivalence |
|---|---|---|
| R'-AUTHORITY-01 | DS-01, DS-02 | Define exact actor/credential/clock/DB/sign/SCM/Host trusted computing base, custody and non-bypassable enforcement for each protected effect. P2 library hook does not prove OS/SCM/remote writers mediation. |
| R'-SCOPE-02 | DS-02, DS-05 | Canonical inventory for accepted protected effects vs **never-certified preview** and supported Host populations. Historical noncooperating offline universal coercion must be explicitly added or excluded, never implied from C1-FULL preference. |
| R'-REVOKE-03 | DS-03 | Select issuer-effective Rv-S **or** physically fence-effective Rv-F with global blackout between ISSUE and FENCE. Specify effect-order, epochs, read/write old-leader denial and irreversible prior effects. Rv-F is material weakening/change, not an R11 interpretation. |
| R'-TIME-04 | DS-03, DS-04 | Define durable C and authenticated `C∈[C_lower,C_upper]`, `notBefore<=C_lower<=C_upper<expiresAt`, uncertainty cutoff, failure STOP, where this bound applies across DB/seal/effect/use. Local transaction timestamp cannot be called independently certified durable COMMIT. |
| R'-STATE-05 | DS-04 | Decide original single atomic ACCEPT+PUBLISH vs staged `DB_COMMITTED_UNSEALED -> EXTERNALLY_SEALED_VISIBLE -> effect grant / remote ACK`. Staged partial states must not be silently mapped onto R11 `OP_COMMIT_ACCEPTED`. |
| R'-EFFECT-06 | DS-01, DS-04, DS-05 | Mandatory **first protected writer** fence before release-please/tag/release, artifact, coverage/SARIF, registry, asset/API and manual admin/App/PAT writes. Require per-provider inability to bypass, not policy YAML alone. |
| R'-PROOF-07 | DS-01, DS-04, DS-06 | Independent signer readback, canonical sealed-byte digest and bound scope/op/seq/root/epoch, unsigned UNSEALED state on refusal. Define authentic positive proof, no proof on RPC timeout alone. |
| R'-RECOVERY-08 | DS-06 | Independent durable signed ACK high-water and epoch, deny CURRENT when restored prefix<ACK(k), old primary/reader/publisher physical fence, quarantine of divergent signer or remote unknown, no automatic replay of unknown effect. |
| R'-BYTES-09 | DS-05 | Bind source/tree+lock+toolchain+full build to a **single frozen tarball**, immutable registry/Release readback, installed bytes, JS+ELF/native actual load witness at t_use. Path/hash/filename alone insufficient; custody class per Host required. |
| R'-INTERFACES-10 | all | Version interfaces/invariants and original R11 38x7 A01–A14 preserving old R/I/P distinction. Only an explicitly approved R' may redefine old semantics; runtime proof is still separately required. |
| R'-STOP-11 | all | Unknowns fail-closed on certification and protected effects. Uncertified preview is non-admissible and unpromotable without new authentic authorization. Task1 previous gates unchanged. |

**D' future candidate prerequisites:** Approved R' exact scope → new independent design of real enforcer, issuer clock and sealing, state machine and bytechain with negative oracles, TCB evidence and platform readback.  
**P' future candidate prerequisites:** Independently approved D' → a separate artifact authorization plan; static source closure first; external runtime/Host/GitHub/DB tests only after separately explicit authorization. No task or interface unlock implied here.

**No adoption:** Owner decision `PENDING`, R' `NOT_ADOPTED`, D'/P' `NOT_STARTED/NOT_ADOPTED`, R11 `UNAPPROVED`, Tasks2–14 `NOT_AUTHORIZED`.
