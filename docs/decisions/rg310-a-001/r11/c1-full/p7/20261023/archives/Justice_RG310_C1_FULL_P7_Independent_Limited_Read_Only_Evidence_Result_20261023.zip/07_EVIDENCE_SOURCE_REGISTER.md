# P7 — Independent Read-only Evidence / Provenance Register

2026-10-23 JST. Every line identifies what its source **can** and **cannot** prove. The pinned repository reads were made read-only; no Actions run, token acquisition or provider/host test took place.

## Source tiers

| Tier | Evidence | Read status / observed immutable identity | Admissible conclusion | Does NOT prove |
|---|---|---|---|---|
| 0 | P7 user-uploaded outer ZIP | directly byte-read; SHA256 `45bd2a4faef714eb097d8681b5763812edf54e879ade9343a0f8fa70fd1b86f3` | Actual attached byte string + CRC/included content | Independent outer-hash MATCH (no external expected value provided) |
| 1 | P6 Result ZIP | byte-read from P7; SHA256 `c1152b6fd0be1ad51816b7f68c9fc8db2bcc0110175b59578e9da5d37a444cce` | Included original exactly matches P7 checksum/manifest | Reviewer human signoff or runtime proof |
| 1 | P6 Handoff ZIP | byte-read from P7; SHA256 `f4b9767f60af3e5a8d2c697fbc53eaa597e636dff9e868c03b24fb97f4b37dd4` | Included original exactly matches P7 checksum/manifest; nested originals CRC/hash pass | External source's independent identity or historical parent verified |
| 2 | Approved v5 R from GitHub pinned HEAD | `d335c34b747cafd6ac3b2e81d710fdcc61fb777e`, fetched immutable | Fail-closed acceptance JUS5-GATE-01/02; human chain JUS5-AUTH-* | R11 additional strict distributed release requirements are approved |
| 2 | Approved v5 D from GitHub pinned HEAD | `64acdf177d2fd207861eb477af7c8a265eed71e8`, fetched immutable | INV-04 acceptance denial; INV-06 authority separation | Producer controls arbitrary historical third-party OS |
| 2 | Approved v5 P from GitHub pinned HEAD | `10dfba4c199feff19ee387b244daf6c0fd30d5e3`, fetched immutable | Tasks1/6 have distinct runtime proof dependencies | Task 1 already complete or Tasks2–14 authorized |
| 2 | `.github/workflows/release.yml` fixed commit | `4f984a012f3fa9421a32531a00394f4d654d5284`, fetched immutable | Source order/declared permissions/possible conditional release-first | Actually created tag, real token rights or all-run release creation |
| 2 | `package.json` fixed commit | `8e154e09d0c6253d104b60e72208c5ff2a3478b4`, fetched immutable | Registry and lifecycle/exports source intent | Tarball content equality between independent invocations |
| 2 | `src/runtime/linux-review-artifact-provider.ts` fixed commit | `27b3a430c9015bbaf65ac3ec00e80c23121794c4`, fetched immutable | Native loader chooses require-path | Actual mapped bytes/inode at use time |
| 3 | P1–P6 packaged static analysis and P5 paper traces | 9 originals CRC/SHA verifiable; P6 174 join/350 audit rows; 28 P7 falsifiers | Scope of prior static findings and bounded traces | Runtime negative oracle, privileged writer proof, provenance authentication |
| 4 | Current upstream official GitHub/npm/PostgreSQL documentation | read-only public documentation in links below | Supported semantics of API classes as documented | Justice repo's real deployment settings, provider account permissions or network liveness |

## Pinned repo exact links (fix commit, no mutable default branch)

1. [Approved v5 R](https://github.com/yohi/justice/blob/8a2e4f1536e9cad499ee7e9d996ff163df132fd4/docs/superpowers/requirements/2026-09-27-justice-v5-requirements.md): `JUS5-GATE-01/02`, `JUS5-AUTH-01..09`, `JUS5-HARNESS-01..04`.
2. [Approved v5 D](https://github.com/yohi/justice/blob/8a2e4f1536e9cad499ee7e9d996ff163df132fd4/docs/superpowers/specs/2026-09-27-justice-v5-semantic-control-plane-design.md): `INV-04`, `INV-06`, `J5D-CHAIN-01/02`.
3. [Approved v5 P](https://github.com/yohi/justice/blob/8a2e4f1536e9cad499ee7e9d996ff163df132fd4/docs/superpowers/plans/2026-09-28-justice-v5-semantic-control-plane.md): Tasks 1/6, live evidence dependencies.
4. [Release workflow](https://github.com/yohi/justice/blob/c428041dfb5779b6b6dc8db7bf14928225a00373/.github/workflows/release.yml): first `googleapis/release-please-action` vs post-action dry-run/publish/pack/upload.
5. [Package scripts](https://github.com/yohi/justice/blob/c428041dfb5779b6b6dc8db7bf14928225a00373/package.json): scripts, prepublishOnly, registry, exports.
6. [Native loader](https://github.com/yohi/justice/blob/c428041dfb5779b6b6dc8db7bf14928225a00373/src/runtime/linux-review-artifact-provider.ts): `loadNativeAddon` / `require(addonPath)`.

## Public source/API references checked in this investigation

- [release-please-action official GitHub README](https://github.com/googleapis/release-please-action): conditions for release creation and `release_created` output. Documentation supports **may write on release condition**, not **always**.
- [GitHub REST Releases API](https://docs.github.com/en/rest/releases/releases): creation/write permission classes; token permissions vary with actor and content. API existence does not establish live policy for this repository.
- [GitHub ruleset bypass configuration](https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets/creating-rulesets-for-a-repository): role/App/admin bypass support, requiring actual settings evidence.
- [GitHub ruleset restriction rules](https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets/available-rules-for-rulesets): branch/tag creation/update restrictions as configurable primitives, not a current enforced policy claim.
- [PostgreSQL 18 date/time functions](https://www.postgresql.org/docs/18/functions-datetime.html): `transaction_timestamp()` reports transaction beginning and `clock_timestamp()` moment of call, neither by definition true externally certified durable COMMIT-time.
- [PostgreSQL committed transaction information](https://www.postgresql.org/docs/current/functions-info.html): `pg_xact_commit_timestamp()` exists under `track_commit_timestamp`; local record retention and provenance limits need separate checks.
- [npm publish official docs](https://docs.npmjs.com/cli/commands/npm-publish/): publishing from folder or tarball, dry-run for *files likely included*, registry tarball integrity field. No documented identity guarantee for two independent pack executions in an arbitrarily mutable workspace.
- [npm pack official docs](https://docs.npmjs.com/cli/v12/commands/npm-pack/): `--dry-run` and actual packed tarball distinguishable operations.

## Unsupported or unobserved contracts

1. Proof that the GitHub Release, the GitHub Packages tarball, and CI artifacts are immutable, identical or authorized under a single effective pre-effect veto is `NOT_VERIFIED`.
2. A global issuer-to-DB-commit-to-signer-to-remote-to-Host shared linearization and clock/error bound is `NOT_VERIFIED`. Merely exposing local PostgreSQL timestamps/LSNs cannot be escalated to cross-domain simultaneity.
3. Signer ACLs/refusal semantics, independent ACK(k) preservation, key epoch anti-rollback and physical old-primary/recovery fencing remain `NOT_VERIFIED`.
4. Exact JS and native/ELF bytes *actually loaded*, not only a named file, remain `NOT_VERIFIED`, as does a mandatory trusted host loader for out-of-custody clients.
5. Full repo historical DS search, effective repo rulesets, SCM admin/App/PAT classes, real tokens/secrets, registry/release readbacks and all 207 initially unread blobs were NOT newly acquired. No inference of an `absence` of historical Owner records.

## Nested source references in P7 attachment

- P7 `sources/Justice_RG310_C1_FULL_P6_Fresh_Independent_Architecture_Security_Review_Result_20261023.zip::01_P6_FRESH_INDEPENDENT_TECHNICAL_REVIEW.md`, `02_P5_F01_F08_FINDING_ADJUDICATION.csv`, `03_CROSS_STREAM_JOIN_AND_PROVENANCE_AUDIT.csv`, `04_32_P5_TRACES_AND_R11_38x7_AUDIT.csv`, `05_OWNER_DS01_DS06_DECISION_READINESS_UNSIGNED.md`.
- P7 `sources/Justice_RG310_C1_FULL_P6_Fresh_Independent_Architecture_Review_Handoff_20261022.zip::sources/Justice_RG310_C1_FULL_P5_Cross_Stream_Independent_Integration_Handoff_20261022.zip::origins/U07_NORMATIVE_SCOPE_RESULT.zip::02_U07_REQUIREMENT_VS_ADDED_ASSUMPTION_REPORT.md` and `03_C1FULL_OWNER_MATERIAL_CHOICES_UNSIGNED.md`.
- Corresponding `origins/P1_3_SEMANTIC_SOURCE_RESULT.zip::01_341_BLOB_REACHABILITY_AND_EXCLUSION_AUDIT.csv`, `origins/P2_ACTOR_EFFECT_REFERENCE_MONITOR_RESULT.zip::03_REFERENCE_MONITOR_CONDITIONAL_SPEC.md`, `origins/P3_COMMIT_REVOCATION_ATTESTATION_RESULT.zip::01_ACCEPTANCE_AND_EXTERNAL_EFFECT_PROTOCOL.md`, and `origins/P4_BUILD_RELEASE_HOST_RESULT.zip::02_PUBLISHER_EFFECT_AND_CREDENTIAL_CENSUS.csv`, `03_ACTUAL_HOST_LOAD_ATTESTATION_HYPOTHESIS.md`.

All source material is treated as untrusted static evidence. The existence of a document, archive or new result cannot confer higher authority.
