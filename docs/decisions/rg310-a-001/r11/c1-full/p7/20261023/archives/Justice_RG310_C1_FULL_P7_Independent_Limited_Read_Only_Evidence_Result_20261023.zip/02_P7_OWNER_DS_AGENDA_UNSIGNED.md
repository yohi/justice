# P7 — DS-01..06 / A-B Owner decision agenda — UNSIGNED / NOT A DECISION

Date 2026-10-23 JST. `OWNER_CHOICES_ALL_UNSELECTED / AUTHORITY_NOT_GRANTED`.

## Historical authority ledger

| ID | Identifiable historical tier | Status | What must not be inferred |
|---|---|---|---|
| DS-02 | C1-FULL preferred research direction evidenced in P0/P1.3/U07 unsigned source discussion | `C1_FULL_PREFERENCE_RECORDED / FORMAL_DS02_PENDING` | A signed universal offline mandate, C2 reduction, A/B adoption, execution grant |
| DS-01 | P5 `06_OWNER_ARCHITECTURE_DECISION_READINESS_UNSIGNED.md` proposed authority/TCB agenda | `HISTORICAL_OWNER_ORIGINAL_NOT_VERIFIED / PROPOSED_ONLY` | That a prior Owner record uses these exact words |
| DS-03 | P5 proposed issuer-revocation/clock discussion | `HISTORICAL_OWNER_ORIGINAL_NOT_VERIFIED / PROPOSED_ONLY` | That Rv-F was previously authorized |
| DS-04 | P5 proposed atomicity/seal/remote-state discussion | `HISTORICAL_OWNER_ORIGINAL_NOT_VERIFIED / PROPOSED_ONLY` | That R11 accepted state may be redefined without R' |
| DS-05 | P5 proposed product-lifecycle/bytes/Host custody discussion | `HISTORICAL_OWNER_ORIGINAL_NOT_VERIFIED / PROPOSED_ONLY` | That producer has coercive control over historical noncooperating copies |
| DS-06 | P5 proposed recovery/ACK/key epoch/fence discussion | `HISTORICAL_OWNER_ORIGINAL_NOT_VERIFIED / PROPOSED_ONLY` | That remote/old-leader safety has runtime proof |

The archive includes neither an authenticated human owner signature over these DS texts nor formal adoption of an R' chain. Fixed approved v5 R/D/P was read from pinned HEAD; no independent historical full-repository search for every possible offline Owner record is claimed.

## Future decision questions (all unselected)

### DS-02 — population, scope, and guarantee (separate from A/B protocol)

- **DS02-A:** add universal retroactive physical prohibition for all previously distributed third-party copies, forks and offline devices. Under ordinary producer-only control this is contradicted by the offline independent device trace. Selecting this ambitious obligation requires evidence of universal external mandatory enforcement, not merely a future producer Gateway.
- **DS02-B:** require an external platform with mandatory custody of *all* historical consumers, including offline. Research-only and not established in supplied evidence. Coverage of previously uncontrolled machines itself needs proof.
- **DS02-C:** retain C1-FULL for legitimate producer lifecycle, distributed channels and cooperative/custodied Supported Hosts; explicitly disclose inability to coerce already distributed noncooperating offline machines. This is a research candidate, not silent adoption of C2 or an Owner signature.
- **DS02-D:** defer the population boundary until traceable human intent and enforcer custody can be established.

Do not identify these four DS02 population alternatives with architecture **A** (`literal single atomic ACCEPT+PUBLISH + Rv-S`) versus **B** (`DB_COMMITTED_UNSEALED -> external seal -> separately authorized effects`); they are orthogonal dimensions.

### Proposed DS-01 / 03 / 04 / 05 / 06 deliberation (no fabricated past authority)

- **DS-01 / TCB:** Which issuer/signer/clock/DB/GitHub-admin/App/PAT/registry/Host authorities can write/read protected state and where is a mandatory pre-effect veto actually enforced? Specify owner and auditability by effect, not generic role labels.
- **DS-03 / time:** Retain issuer-effective Rv-S only if a real global ordered admission and worst-case trusted COMMIT clock witness is proven? Or propose Rv-F with issued-pending-fence and all-channel blackout as a *new* norm? Which acceptance, seal, effect and actual-use times require validation?
- **DS-04 / state:** Is an actual common literal transaction across accepted bytes, detached proof and protected publication obligatory? Or is partial-failure staged sealing a newly approved R' contract with UNSEALED, REMOTE_UNKNOWN, ORPHAN and QUARANTINED not equal to original R11 `OP_COMMIT_ACCEPTED`?
- **DS-05 / objects and Hosts:** Classify protected accepted releases versus visibly uncertified previews; separately inventory tags, Release, SARIF, CI artifact, coverage, Snyk/Sonar, registry, direct source and supported Host JS/native loaded bytes. Which Hosts are cooperative, custodied or outside control?
- **DS-06 / recovery:** What authenticated ACK(k) high-water, key epoch anti-rollback, irrevocable remote effect rules, old-primary+stale-reader physical fence and no-retry-unknown rules are mandatory?

## Decision readiness

`ONLY_NEGATIVE_BOUNDARY_AND_COMPARATIVE_EVIDENCE_READY`. No positive `GO` proposal, Owner selection, vote, signature, HSA, Gate authorization, P2-P4 schema freeze release or implementation instruction is contained in this agenda. Any material selection must be captured as a separate authenticated Owner decision and independently reviewed R'→D'→P' chain before subsequent authority can be considered.
