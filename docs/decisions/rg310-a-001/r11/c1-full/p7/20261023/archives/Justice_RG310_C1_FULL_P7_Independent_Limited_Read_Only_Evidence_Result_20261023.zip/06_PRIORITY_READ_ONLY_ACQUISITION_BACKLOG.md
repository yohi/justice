# P7 — Bounded next-evidence backlog (NO EXECUTION AUTHORIZATION)

This is a prioritized **read-only evidence request list**, not an instruction to run CI, query secret material, mutate settings, produce an HSA, or perform negative runtime tests. Unknown / unavailable is the correct outcome when authenticated static evidence cannot be acquired.

| Priority | Needed evidence, minimum scope | What it discriminates | Current boundary |
|---|---|---|---|
| P0 | Authenticated historical Owner DS-01..06 original source and real signatures/approval metadata, if any; exact signed R/D/P revision linkage | R' authority vs invented P5 agendas; C1-FULL / third-party universal scope | NOT_VERIFIED, no search of every off-repo store |
| P0 | Fixed commit `release.yml` release-please condition/order + source-defined first-writer credentials; published GitHub ruleset/tag rules, bypass actor list, branch permissions documented **without tokens** | A pre-effect mediation feasibility for Git writers vs post-npm gate | Workflow source confirmed, effective permission NOT_VERIFIED |
| P0 | Privileged principal class list for `GITHUB_TOKEN`, fine-grained/classic PAT, App installations, admins, deploy keys, manual REST paths; credential scope *metadata* only, NEVER actual secrets | All protected channels mandatory veto vs bypass | Direct writer API and live rights NOT_VERIFIED |
| P0 | DB/issuer independent ordering contract and authenticated COMMIT-time witness proposal with error bound and durable sign/visibility semantics | Rv-S and literal A; whether a strict C_upper proof can exist | No finite worst-case network/clock bound demonstrated |
| P0 | External signer protocol written contracts for byte readback/refusal, key epoch, append-only independent ACK(k) and receipt collision | B's seal validity and restoration safety | Provider ACK/security semantics NOT_VERIFIED |
| P1 | Remote provider Git tag/Release, Packages, SARIF, Codecov/Sonar/Snyk and Actions artifact immutability + effect readback APIs and timing | B's partial effects and remote unknown reconciliation | Remote irreversible effects undefined |
| P1 | Source/tree + `bun.lock`, Cargo lock, package scripts and pinned build toolchain descriptions, immutable artifact naming/digest and registry/release readback conditions | P4 exact tarball same bytes; no dual-pack gap | dry-run and separate publish/pack not proof |
| P1 | Supported Host custody classes; documented loader/OS/package entrypoints, native library load and actual mapped-byte attestation possibility | P4 H0-H3 and TOCTOU requirements | No loaded-process witness |
| P1 | Physical old-primary + stale-reader + publisher credential revocation/fence APIs with recovery/partition safety contracts; restore prefix high-water checks | A and B rollback; fail-closed no-CURRENT | No old-principal physical deny proof |
| P2 | Read-only bounded P1.3 missed 207 triage: start with 177 CI test/fixture executable cases only if path connects to protected output or issuer/credential; 28 docs secondary | Consumer reachability and P4-044 external TCB; not a demand to inspect irrelevant files | Source bodies remaining 207 unverified, 55 P4 semantic unassociated |

**Graduation rule:** Static source/API documentation can support **feasibility and falsifiability**, not operational `PROVEN`. Subsequent runtime negative oracles and host/provider proofs must be separately authorized under future approved lineage. The priority list cannot clear any existing Gate.
