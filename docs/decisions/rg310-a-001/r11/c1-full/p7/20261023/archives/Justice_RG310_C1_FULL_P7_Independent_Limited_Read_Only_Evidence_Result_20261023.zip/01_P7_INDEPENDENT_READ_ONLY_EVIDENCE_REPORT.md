# Justice RG-310-A-001 — P7 Independent Limited Read-only Evidence Acquisition

**基準日:** 2026-10-23 JST  
**役割:** P1–P6の著者・既往レビュアー、Coordinator、人間Owner、正式Gate担当から独立した静的調査担当  
**成果物の性格:** `INDEPENDENT_STATIC_RESEARCH / UNSIGNED / NOT_ADOPTED / NOT_AN_EXECUTION_GRANT`  
**総合判定:** `LIMITED_COMPARATIVE_EVIDENCE_SUPPORTED / POSITIVE_A_OR_B_ADOPTION_NOT_READY / P2_P3_P4_INTERFACE_FREEZE_STOP`

## 1. 入力・完全性・来歴

本P7添付ZIPを直接読み、`00_READ_FIRST.md`, `01_P6_COORDINATOR_VERIFIED_INTAKE.md`, `02_P7_LIMITED_OWNER_DECISION_OPTIONS_UNSIGNED.md`, `03_P7_LIMITED_READ_ONLY_RESEARCH_CONTRACT.md`を全文確認した。P6 Result/P6 Handoff、それらが格納するP5 Result/Handoff、P1/P1.1/P1.2/P1.3/U07/P2/P3/P4/R11の9原本ZIPを**内容実行なし**にバイト単位で再帰検証した。

- **P7外側:** 825,667 bytes; SHA-256 `45bd2a4faef714eb097d8681b5763812edf54e879ade9343a0f8fa70fd1b86f3`; CRC PASS。**独立期待SHA未提示のため外側SHA照合は`PENDING_EXPECTED_HASH`**。P7 SHA256SUMS 7/7、MANIFEST 7/7。
- **P6 Result:** 69,818 bytes; SHA-256 `c1152b6fd0be1ad51816b7f68c9fc8db2bcc0110175b59578e9da5d37a444cce`; P7包内期待値にMATCH; CRC, SHA256SUMS 6/6, MANIFEST 6/6 PASS。
- **P6 Handoff:** 746,586 bytes; SHA-256 `f4b9767f60af3e5a8d2c697fbc53eaa597e636dff9e868c03b24fb97f4b37dd4`; P7包内期待値にMATCH; CRC, SHA256SUMS 5/5, MANIFEST 5/5 PASS。
- **P5 Result/Handoff + 9 originals:** 11 nested ZIPのCRC PASS; 全宣言されたSHA256SUMS/利用可能MANIFEST PASS。**再帰合計14 ZIP、CRC全PASS、checksum 111/111、manifest 103/103**。R11原本ZIPにMANIFESTは存在しないため、その旨区別した。
- **歴史的親:** `735d9f0ce2b97d2b1543fb6a7a5d9a839b2ada30cb5a41e732f1115725d30160` の実アーカイブは本入力内に存在せず、`NOT_VERIFIED`。
- パッケージ内Manifest/ハッシュ整合性は**持ち込まれた同一包の整合**であり、外部発行元の真正性、個別人間決定、GitHub有効権限、実行証明、受入許可を意味しない。独立期待値が将来提示された場合の外側比較は別手続き。
- 全件再帰検証の機械可読結果は`08_INPUT_NESTED_INTEGRITY.json`を参照。

## 2. 権限層を分けた固定事実（独立GitHub read-only再取得）

Approved v5 requirements `docs/superpowers/requirements/2026-09-27-justice-v5-requirements.md`、Design `docs/superpowers/specs/2026-09-27-justice-v5-semantic-control-plane-design.md`、Plan `docs/superpowers/plans/2026-09-28-justice-v5-semantic-control-plane.md`を**承認済みHEAD `8a2e4f1536e9cad499ee7e9d996ff163df132fd4`** からread-only再取得。取得したGit blob SHA-1はそれぞれ `d335c34b747cafd6ac3b2e81d710fdcc61fb777e`, `64acdf177d2fd207861eb477af7c8a265eed71e8`, `10dfba4c199feff19ee387b244daf6c0fd30d5e3`（対象箇所のGET）。R `JUS5-GATE-01/02`およびD `INV-04`は**受入時のPositive evidence不足を拒否**し、JUS5-AUTH-01..09、D `INV-06/J5D-CHAIN-01/02`は厳密なR→D→P・人間承認を必要とする。Task1/6にHost runtime proof要求が存在する。

対照的に、**R11は未承認提案**である。R11 `issuer-effective`失効、独立signature/seal、外部effectを含むliteral single `ACCEPT+PUBLISH`、phase-scoped HSA/IAB、38×7行列の提案を、既存v5に最初から実装義務があるかのように表現してはならない。逆に、R11を満たすと称するA設計の技術可否を検証する際にはR11原文条件を緩めてはいけない。R'/D'/P'は提案・研究対象、未採択。

**Ownerの既存C1-FULL選好**は正当なproduct lifecycleの研究スコープの選好であり、DS-02正式署名やR11採択を意味しない。P5が作成したDS-01/03/04/05/06は**後日判断用の提案設問**であり、過去の正式人間決定原文ではない。提供原本と固定R/D/Pの調査で署名・真正Owner原文が得られていない限り、`HISTORICAL_OWNER_ORIGINAL_NOT_VERIFIED / FORMAL_PENDING`を維持する。全GitHub履歴や外部保管庫を網羅探索して不存在と証明したわけではない。

## 3. A/B 比較の独立結論

### A — literal strict R11 atomic acceptance + issuer-time revocation

`A = NO_GO_FOR_OBSERVED_SPLIT_DOMAINS`。issuer、independent signer、DB、GitHub/registry、remote Hostの異なるcommit/権限・時計境界を、単にAPI呼び出し順で1個のtransactionに見せる設計を否定する。`ISSUE(t0)<DURABLE_DB_COMMIT(t1)<IMPORT(t2)`は旧epochで不正受入し得る。`DB_COMMIT → signer拒否`と`signer署名 → DB_ABORT`は別の非原子性反例。`release-please`によるtag/releaseが先行すれば後段npm検査でその公開は巻き戻せない。外部remote write/ACKはDB transactionのcommitに自然には含まれない。

ただしこれは**現状確認された分離provider構成と非同期輸入／writer権限仮定下の反例**であって、将来の共有serializing authority/原子的効果サービスを含むあらゆるarchitecture Aが普遍不可能という数学的主張ではない。Aの反証可能な再審査条件は「issuer event、accepted bytes、証明、すべてのprotected public effectsが実際に共有する独立認証済み**同一線形化/拒否地点**」の機械可読定義と非迂回性証拠。現資料にその証拠はない。

### B — independently sealed staged candidate + separately authorized external effects

`B = RESEARCH_ONLY / NOT_SELECTED / NOT_COMPLIANT`。DB候補commitを直ちにaccepted/publicとして表示しない`DB_COMMITTED_UNSEALED`を導入し、独立読み返し+signerによるseal後のprotected remote effectを**別のeffect-time authorization**として扱う。外部失敗の`REMOTE_UNKNOWN` / `ORPHAN` / `QUARANTINED`を公開statusへ保守的に区別。Bは単一atomic ACCEPT+PUBLISHとは**異なるmaterial R'意味**であり、R11 `OP_COMMIT_ACCEPTED`に置換できない。物理的に既送信のremote effectを差し戻す能力は仮定しない。

`Rv-S`をBに残すとissuerから全effectまでのstrict共通順序問題は消えない。`Rv-F`は失効発行を`ISSUED_PENDING_FENCE`に保留し、**各protected effectに先立ち、すべての旧reader/writer/credentialで物理的fence完了し、その間はblackout**であることを別途立証して初めて候補たり得る。`Rv-F`はIssuer-effective契約からのmaterial変更であって性能上の便法ではない。Bも独立signer拒否・restore・post-seal revoke・Host actual-loadなどを未証明としてGO不可。

## 4. 観測済みfirst writerと外部公開effect

Evidence HEAD `c428041dfb5779b6b6dc8db7bf14928225a00373`のGitHub**read-only**取得:

- `.github/workflows/release.yml` blob `4f984a012f3fa9421a32531a00394f4d654d5284`。`permissions: contents:write / pull-requests:write / packages:write` L7–10。`googleapis/release-please-action` L16–21がtag条件付き後段の`checkout` L22–25、native/JS build L34–48、artifact L49–53、dry-run L55–59、`npm publish --ignore-scripts` L60–64、再`npm pack`+`gh release upload` L65–71より**前**に置かれる。
- `release-please`のrelease作成は条件付きであり、**すべての実行がtagを書くとは主張しない**。反例はrelease_created条件が真の場合に、後段npm gateがfirst Git tag/release createより後に位置するという**可能な順序**だけを使う。実行run、作成されたtag/release、強制ruleset/branch protection、effective token/App/PAT/管理者迂回は未実証。
- `package.json` blob `8e154e09d0c6253d104b60e72208c5ff2a3478b4`には`publishConfig.registry=https://npm.pkg.github.com`, `prepublishOnly` scriptが存在。`npm pack --dry-run --json --ignore-scripts`と`npm publish --ignore-scripts`と後続の別`npm pack`は**同一凍結tarballを使う操作ではない**。不一致が必ず発生すると断定できないが、byte equalityの証明を全く与えない。後続`npm pack`でscript/lifecycle差や中間mutabilityの可能性を遮断していない。
- P4原本46行: P4-004/007/015 actions artifact、008 Codecov、010 Sonar/PR writer、017 Registry、018 GitHub Release、020/023 SARIF、021/022 Snyk、026 Dependabot、040 GitHub App/PAT/admin、041 preview artifact、042/043 remote readback、032/033/034/037 package・Host loader。**Protected accepted effect / uncertified preview**のclassを先に規範決定し、各channelに初回write前のnon-bypassable checkを要求する。ただし現在どのchannelが正式protectedかは未定義。YAML宣言やtoken参照をeffective permissionと呼ばない。

参考API/documentation evidence: `release-please-action`公式README（release/tagを作り得る）、GitHub releases API（Contents writeなど）、GitHub rulesets（App/admin等へのbypass設定可能）、npm publish/packドキュメント。`07_EVIDENCE_SOURCE_REGISTER.md`に固定ソース/URLと証明上限を記載。

## 5. 失効・COMMIT時間の必要条件（紙上有限trace）

- **Rv-S反例:** `ISSUE_REVOKE(g,t0); OLD_LEADER_COMMIT(g,t1); IMPORT_REVOKE(t2)`かつ `t0<t1<t2`。issuer外側の非同期配達だけではstrict禁止が満たされない。DBの`SERIALIZABLE`は**DB内**順序のみを与え、外部issuerを暗黙に組み込まない。
- **Expiry反例:** `PRECHECK=08, expiresAt=10, durable C=12` ⇒ valid precheckでもexpired commit。`transaction_timestamp()` = transaction start。`clock_timestamp()` = sampling時刻。`pg_xact_commit_timestamp()`が有効な版・設定下で過去commit timestampを返しても、別独立authority clock+issuer serialization+持続・完全性・遅延上限の証明を自動で提供しない。
- **必要定理（strict COMMIT時刻要求を採る場合）:** 独立認証された`C∈[C_lower,C_upper]`を実durable linearizationが満たし、`notBefore <= C_lower`かつ**`C_upper < expiresAt`**。失効issuer orderingも同じeffect-order中で証明。`C_upper = expiresAt`、区間overlap、未認証遅延、時計飛び、古いepoch、receiptとcommitの対応が不明なら`UNKNOWN/BLOCKED`。後置signed clock値は因果関係と保守的遅延境界がなければcommit witnessにならない。
- **能力境界:** PostgreSQL transaction timestamp/LSN/commit timestampは限定的なローカル証拠。外部signer、GitHub ref/API、Host実ロードの同時commit境界はドキュメント上自動保証されない。実装可否評価にはissuer/clock/DB/publisher間のAPI契約、最大不確実性bound、global fence成功・失敗を表す再現可能仕様が必要。

## 6. Seal / remote / recovery / Host effect

`04_P7_FAIL_CLOSED_STATE_TABLE.csv`に12以上の失敗状態を列挙。最重要:

1. **Signer refuses**: DB commit `UNSEALED` → signer拒否。公開不可、acceptedと投影不可。signer事前署名→DB ABORTでも同様に署名を正規acceptedとみなさない。
2. **Remote unknown**: external effect request送信後timeoutは「失敗・未実行」ではなく`REMOTE_UNKNOWN`。重複が不可逆なら自動再試行禁止、外部readback/権限根拠の独立照合まで停止。
3. **ACK(k)→restore(k-1)**: 外部独立署名済みhigh-waterがkなら、復元されたDBがk-1のCURRENTを発行してはならない。old primary/read replica/publisherは**物理的**read/write fenceが必要。論理term変更だけで古い権限の効果を消せない。
4. **Revocation after seal before effect**: sealは旧時点の証明、effect時点のauthorizationではない。effect前の最新auth/epoch/fence再検証が必要。key epochが失効・未知/巻戻りなら`QUARANTINE`。
5. **Host exact-byte proof**: source→lock/toolchain→built JS+native→single frozen tarball→registry + assetのimmutable digest readback→installed JS/native→`require`/loaderで**実際にmapped/readしたinode・bytes**→使用時刻t_useのtrusted witness。`hash(path,t0)`後のsymlink/FD/native map replacement at t1はTOCTOU。製品作者が現Hostに全OS/loader custodyを保持すると仮定しない。noncooperating offline Hostに現時点のproducerが命令できるとは主張しない。
6. **H0–H3** (ingressの媒介、origin本人性、sealed proof等)は引き続き`NOT_PROVEN`。H0–H3の将来証明は、既存Task1 Case A/unknown-tool/真のactual old-successの`R`判定と置換できない。

## 7. P6-N01〜N06 の独立処置

| P6観察 | P7判定 | 新たに必要な限定証拠 | 影響 |
|---|---|---|---|
| N01 規範の格上げ誤り | `CONFIRMED_TIER_RISK` | 正式v5 R/D/PとR11/R'の別ID/署名・lineage | R'前にv5 obligationと誤称しない |
| N02 P4-044 unmapped | `CONFIRMED_EXTERNAL_TCB_SENTINEL` | DS-02のHost population、旧バイト実行主体/非協調性の信頼境界 | 53/108等のsemantic linkをclosureと誤称しない |
| N03 first writer述語 | `CONFIRMED_POSSIBLE_SOURCE_ORDER_ONLY` | release-createdが真のrun、effective pre-write enforcement、全publisher principal | every-run作成主張は禁止 |
| N04 independent commit witness | `NOT_PROVEN` | true durable C containment、issuer-clock auth、最大遅延・uncertainty | 厳格時刻要求の条件付きSTOP |
| N05 Host actual loaded bytes | `NOT_PROVEN` | loader/OS custody、JSとnative in-memory mapping、nonce/use-time proof | pathname/pack listingをHost証拠にしない |
| N06 post-seal recovery | `NOT_PROVEN` | per-effect auth/key, signer prefix high-water, old leader physical fence | Bにも不可逆remoteリスク残存 |

新たなN01〜N06は**P6観察6件**であり、既存22のformal Findingsを閉じたり勝手に増加させたりするものではない。元のP5-F01〜F08は**8件とも OPEN_NOT_PROVEN_NO_FORMAL_CLOSURE**を維持。

## 8. P1 coverageの非誇張

固定P1.3 `01_341_BLOB_REACHABILITY_AND_EXCLUSION_AUDIT.csv`を今回再集計: **341行、134件本文静的scan、207件`NOT_VERIFIED_NO_BODY_READ_P13`**。未読207の内訳は155 `CI_TEST_EXECUTABLE_OR_FIXTURE`、22 `TEST_FIXTURE_EXECUTABLE_INVOKABLE`、28 `DESIGN_REPORT_MANUAL_OR_AGENT_INPUT`、1 `OTHER_PROJECT_INPUT`、1 `SPIKE_MANUAL_EXECUTABLE_OR_DATA`。実行可能テスト/fixtureは合計177。この数は静的リスク分類であり、全177が製品releaseへ到達すると証明したものではない。

P6のtyped join 174行 = P1.3 108 + P2固有20 + P4 46。P1.3のP4関連53/108 manual semantic association、残り55未関連。P4の31 workflow exact linkと14 semantic associationは実効権限・効果の実観測ではない。`P4-044`は歴史的third-party sentinel（1:1 pinned executed pathなし）。優先取得はpublisher/Host/credential/CI入口と到達辺を持つread-only sourceに限定し、残り未読を閉鎖扱いしない。無関係な資料の一律読了をB feasibilityの前提にしない。

## 9. 非退行・禁止事項

- `22 ORIGINAL FINDINGS = OPEN`、`37 ORIGINAL NC = NOT_EXECUTED`。P2 56 / P3 33+31 / P4 40 / P5 32 のpaper negative casesは`NOT_EXECUTED`。
- Approved v5 R/D/P `8a2e4f15...`不変、Task1 `31/32 PROVEN; Case A BLOCKED; Case B PROVEN; unknown-tool BLOCKED`。`H0/H1/H2/H3 NOT_PROVEN`。
- R11 `UNAPPROVED`; R'/D'/P' `NOT_ADOPTED`; DS-01..06 `FORMAL_PENDING`; C1-FULL research scope preserved。
- P2/P3/P4 IF/schema `FREEZE_STOP`、B0/B1/B2/HOST `NOT_AUTHORIZED`、Tasks2–14 `NOT_AUTHORIZED`。
- 全GitHub書き込み、commit/push、正式R/D/P修正、CI/Host/DB/OS/cloud実験、秘密/鍵取得、人間署名、HSA、Gate承認、IF freeze解除は実施せず権限も発行していない。

**結論:** P7によりA/Bの反例の条件と次の静的証拠探索優先順位を具体化できた。**Aの現在分離構成下のstrict主張はNO_GO、Bは研究候補に留まり、どちらもOwnerの技術採択GOを支えない。** 正式な人間DS、独立R'→D'→P'審査、別の実行許可を要する。
