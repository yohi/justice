# P8 — Strict A falsifiers versus hypothetical staged B interfaces

基準日: 2026-10-23 JST / `INDEPENDENT_STATIC_RESEARCH / NOT_ADOPTED / NO_RUNTIME`. 2026-10-23以降の状態は未確認。既存v5承認済み R/D/P `8a2e4f1536e9cad499ee7e9d996ff163df132fd4` と R11 **未承認**を混同しない。

## 0. Provenance and evidence tiers

- `READ_ONLY_SOURCE_VERIFIED`: 添付P8→P7→P6→P5→P1..P4/U07/R11の文字列とSHA/CRC; repo固定HEAD `c428041d...` の release/ci/codecov/semgrep/snyk/version guard/source, package.json。これらは*source-defined* actor/effect orderだけを証明する。
- `READ_ONLY_PROVIDER_METADATA`: 2026-10-23時点のGitHub repository rulesets API: `14286365` enforcement `disabled`, master `protected:false`。PR325 Draft/未マージ。過去v4.3.1 release immutable:falseでasset sha256 metadata取得。実writeのpolicy proofではない。
- `PUBLIC_DOCUMENTED_API`: [PostgreSQL18 Date/Time](https://www.postgresql.org/docs/18/functions-datetime.html), [PG committed timestamps](https://www.postgresql.org/docs/18/functions-info.html), [PG18 WAL / synchronous_commit](https://www.postgresql.org/docs/18/runtime-config-wal.html), [GitHub rulesets](https://docs.github.com/en/rest/repos/rules), [GitHub release API](https://docs.github.com/en/rest/releases/releases), [release-please-action](https://github.com/googleapis/release-please-action), [npm lifecycle](https://docs.npmjs.com/cli/using-npm/scripts), [npm publish](https://docs.npmjs.com/cli/commands/npm-publish/).
- `HYPOTHETICAL_CONTRACT` ≠ API implemented, performance/security tested, remote rights observed, human approval or HSA. `NOT_VERIFIED` ≠ nonexistence.

## 1. Architecture A — literal strict issuer-effective Rv-S with atomic ACCEPT+PUBLISH

**Bounded conclusion:** `NO_GO_FOR_OBSERVED_SPLIT_DOMAINS`; not a universal impossibility theorem. The present distinct issuer/independent signer/PG/GitHub/registry/Host domains possess no evidenced common atomic commit protocol, trusted global time/fence or all-actor mandatory ingress. No provided R11 approval. The following are falsifiers of shortcuts, not runtime test results:

1. `ISSUE_REVOKE(g,t0) < OLD_LEADER_DB_DURABLE_COMMIT(g,t1) < ASYNC_IMPORT_REVOKE(t2)`: Old epoch accepted after issuer-effective revocation. Serializable PG ordering of local DB transactions alone does not serialize the independent issuer.
2. `PRECHECK at 08 < expiry 10 < true durable commit 12`: successful check at admission does not prove expiry at COMMIT. `now()/transaction_timestamp()` are transaction-start, `clock_timestamp()` is sampling instant, `pg_xact_commit_timestamp` (if configured and retained) is DB-local after-the-fact information, not an authenticated common issuer+signer clock.
3. `DB COMMIT -> independent signer refuses`; reversing order gives `signer seal -> DB ABORT`; remote write and external ACK are outside DB. A literal atomic ACCEPT+PUBLISH is not created by deterministic sequential RPCs, two-phase naming or WAL replay. PostgreSQL `synchronous_commit=remote_apply` can wait for certain standby durable visibility, **not** signer/GitHub/npm consensus.
4. `.github/workflows/release.yml`: conditional release-please tag/Release/PR step is placed **before** npm dry-run/publish and GitHub Release asset upload. A subsequent gate cannot retroactively veto an already-committed public first write. A fixed-run release creation is not independently observed.
5. Per-actor bypass: a protected branch/tag ruleset must be **active** and effective for all scoped writers. As retrieved, repository ruleset 14286365 is disabled and branch master reports protected:false; `bypass_actors: []` for the disabled rule is not a global capability census. The branch protection subresource returned 403; do not infer total absence of all policy alternatives.

**Only possible future A reconsideration (unmet):** produce a verifiable *single serialization/refusal authority* spanning revocation `ISSUE`, durable committed accepted bytes, detached proof, **every** protected GitHub/registry/CI/manual write and relevant Host effect under an independently audited first-effect veto, or an equivalent exact atomicity/refusal protocol with formal partial-failure/partition proof. Identify each linearization point and causal readback, inaccessible principals, clock attestation and proof of denial under network partition/old-credential replay. These are strict requirements **if** A is selected, not already-existing v5 obligations.

## 2. Authenticated bounded durable COMMIT clock witness: necessary acceptance rule

For a proposed strict commit-time validity rule, define actual *durable* linearization instant `C` (not SQL transaction start and not when a client receives ACK). Produce independently authenticated causal evidence that `C in [C_lower,C_upper]`, tied to `(op, root, epoch, seq, txnID/WAL durable record, issuer-order id)`. Authentication must survive restoration and separate witness clock from DB/issuer authority.

Admit only if simultaneously:

```text
notBefore <= C_lower <= C_upper < expiresAt
issuer_revoke_order permits this exact commit/effect (strict issuer-effective Rv-S)
proof freshness, scope, epoch, key and high-water match
all protected first writers share an effective pre-effect veto
```

If `C_upper >= expiresAt`, proof interval overlaps expiry, issuer sequence uncertain, witness is delayed without *proven* bounded latency, clocks jump/uncertainty unknown, old leader not fenced, receipt cannot be causally tied to **durable** record => `UNKNOWN/BLOCKED`, never optimistic accepted. A signed **post-commit** clock sample alone cannot upper-bound the true commit if max causal delay is not bounded and independently authenticated. `C_lower` must equally exclude too-early commits. Required accuracy, availability, latency bound, authentication, quorum recovery and epoch protocol are unselected research prerequisites; none are evidenced by an ordinary PostgreSQL clock function.

## 3. Architecture B — hypothesis **requiring material R' revision**, not R11 compliance

The candidate sequence (not a permitted deployment) is:

```text
REQUESTED_NO_PROOF
  -> DB_COMMITTED_UNSEALED  (private only, no accepted/public projection)
  -> EXTERNALLY_SEALED_VISIBLE  (signer readback + canonical digest; still no protected remote write)
  -> fresh, individually scoped EFFECT_AUTHORIZATION under current epoch/fence
  -> REMOTE_ACKED_CONDITIONAL only after provider readback of expected digest/identity
  -> separately verified supported Host JS/native actual loaded byte witness at t_use
```

Failed signer `UNSEALED_SIGNER_REFUSED`; signer ACK loss `SEAL_OUTCOME_UNKNOWN`; signer seal with DB abort `ORPHAN_SEAL_NO_COMMIT`; remote send/timeout `REMOTE_UNKNOWN` (never safe blind retry); some remote writes succeed `PARTIAL_REMOTE_ORPHAN`; post-seal revoke `REVOKED_PRE_EFFECT`; rollback `RESTORED_BEHIND_HIGH_WATER`; old credential `OLD_LEADER_NOT_PHYSICALLY_FENCED`; signer key mismatch `KEY_EPOCH_UNKNOWN` => no accepted/current projection. **B is neither selected nor equivalent to R11 `OP_COMMIT_ACCEPTED`.** These are projected fail-closed *design states*, not emitted by a real system.

### Rv-S versus Rv-F

Keeping literal `Rv-S` in B **does not solve** issuer→all-effect common ordering. Candidate `Rv-F` would intentionally change effective point to *verified global physical fence* after `ISSUE_REVOKE`, with `ISSUED_PENDING_FENCE_BLACKOUT` preventing all protected reads/writes/claims between ISSUE and successful fence. If an old App/PAT/admin/runner/old-primary/Host bypass has not been physically denied, blackout remains. Issued-but-unfenced is **not** equivalent to issuer-effective R11 and cannot be adopted by P8.

## 4. Minimal *falsifiable interfaces* (names below are illustrative; no code/runtime exists)

| Hypothetical endpoint/contract | Minimum input/output/authenticated witness | Negative oracle / failure state | Evidence classification |
|---|---|---|---|
| `ISSUER.revoke_issue` / `query_fence` | monotonic issuer event id; epoch; issuer-signed timestamp/sequence; affected principals and channels | issuer quorum partition, unavailable fence: deny strict Rv-S or proposed Rv-F blackout | `HYPOTHETICAL; NOT_IMPLEMENTED` |
| `AUTH.authorize_commit` | policy/root/op/seq/epoch; issuer-order checkpoint; bound `C_lower,C_upper` and clock uncertainty + witness identity | stale or overlapping expiry, imported epoch lag, rollback: BLOCKED | `HYPOTHETICAL; NOT_IMPLEMENTED` |
| `DB.commit_durable_receipt` | DB txn id + durable WAL position + epoch; signed *independent* witness ties true C to record (not merely PG now) | ACK precedes durable boundary or only SQL sampling: UNKNOWN | `PG WAL primitives DOCUMENTED; independent timing receipt NOT_VERIFIED` |
| `SIGNER.readback_and_seal` | canonical accepted-candidate bytes digest/root; strict seq/epoch scope; issuer+DB proof; detached seal; independent signer id | DB ABORT, refuses, ACK lost, root/key mismatch: UNSEALED/ORPHAN/UNKNOWN | `HYPOTHETICAL; signer service absent` |
| `EFFECT_GRANT.authorize_once` | exact provider/account/ref/tag/registry/version/asset/hash/attempt nonce; monotonic epoch; before **first** externally observable write | role/App/PAT/admin alternate writer, stale revoke: denied/blackout | `SCM scope/ruleset APIs DOCUMENTED; deployment nonbypassability NOT_VERIFIED` |
| `REMOTE.readback` | provider-issued stable id, object digest, version/eTag or ref OID, actor, final status, idempotency key where truly supported | timeout, partial commit, mutable tag, duplicate id: REMOTE_UNKNOWN/ORPHAN | `GitHub Release API historical asset digest OBSERVED, v4 only; end-to-end NOT_VERIFIED` |
| `ACK.high_water` / `RECOVERY.fence` | independent durable signed `(k,root,key_epoch,remote_effect_set)` and irrevocable old-primary/stale-reader/publisher credential fencing before current restoration | `ACK(k)` then restore `DB(k-1)`, signer rollback, dual leader: NO_CURRENT/NO_WRITES | `HYPOTHETICAL; no independent ack registry or fencing evidence` |
| `HOST.attest_actual_use` | signed at-use nonce, Host/OS/loader trust root, JS+native/ELF *mapped/read actual bytes/inode* and digest, source→frozen tgz→installed chain at `t_use` | symlink/FD replacement, native alternate map or third-party offline copy: unproven use | `PINNED loader source only; no Host witness or universal custody` |

## 5. Byte chain, first writers and remote limits

Full expected chain: immutable source tree + lockfile + native/JS toolchain + build inputs => *one frozen exact* `.tgz` checksum => registry digest/readback == GitHub Release asset digest/readback => package install actual bytes => runtime use-time JS and native mapped bytes. Current `npm pack --dry-run --json --ignore-scripts`, `npm publish --ignore-scripts`, and separate `npm pack` are **three stages** and do not prove byte identity; `prepublishOnly` and pack lifecycle may differ (source/script capability only, no observed divergence asserted). Historical `v4.3.1` GitHub release asset SHA256 exists in current REST metadata but has `immutable:false`; it is not a v5 accepted object or cross-provider bytechain witness.

`03...` supports only **conditional static API feasibility**. Exact Host attestation can be promised only for designated cooperating/custodied Supported Hosts, if proven. It cannot retroactively coerce independently operating old third-party offline copies. DS-02 C1-FULL legitimate producer product lifecycle remains the research scope; no silent C2.

## 6. Independence, stop and future evidence tests (none performed)

Minimum future *paper*-verifiable artifacts: publisher class + effect classification ledger, provider policy snapshots with version/time/actor/bypass scope, issuer-signature/clock/DB causal diagram with formal latency bounds, signer refusal and detached-seal spec, remote readback digest semantics and ambiguous outcome contract, monotonic independently persisted ACK/key epoch spec, and supported Host OS/loader custody definition. A real runtime test would require separately approved R'→D'→P' plus explicit human execution authority. No user/CI/Host/cloud/DB run, token retrieval, repo write, Gate, HSA or signature occurred.

Status: `A = NO_GO_OBSERVED_SPLIT`; `B = RESEARCH_ONLY_NOT_ADOPTED`; `P2_P3_P4_INTERFACE_SCHEMA = STOP`. Task1 and formal Findings remain unchanged.
