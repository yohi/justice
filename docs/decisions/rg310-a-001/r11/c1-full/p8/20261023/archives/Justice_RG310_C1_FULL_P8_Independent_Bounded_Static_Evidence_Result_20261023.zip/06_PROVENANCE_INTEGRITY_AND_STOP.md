# P8 Provenance / Input integrity / Sources / STOP

Date 2026-10-23 JST; `STATIC / UNSIGNED / NOT_AN_EXECUTION_GRANT`. The **separately user-supplied** expected outer SHA for the attached P8 handoff is identical to the computed SHA (below). This independent P8 outer expectation **does not retroactively change** what the P7 reviewer could state when its P7 Handoff expected SHA was unavailable in its original context.

## 1. Outer and nested byte verification (non-executing archive reads)

- Input ZIP actual mounted file: `Justice_RG310_C1_FULL_P8_Bounded_Static_Evidence_Independent_Handoff_20261023(1).zip`, bytes **860,274**.
- Expected & measured P8 SHA-256: `9483bbe0d120e0abe9800a7abe50ed572b9ab0de395c14474560c9dbdb250afc` => **MATCH**.
- P8 CRC PASS, SHA256SUMS **4/4**, MANIFEST **4/4**.
- Nested P7 Result SHA-256 `15159e65bb32c68cfbd5dd051e37630a817613315fcee93f97631839b0edc056` (expected exact **15159e65bb32c68cfbd5dd051e37630a817613315fcee93f97631839b0edc056**) => **MATCH**. Embedded P7 Result CRC PASS, SHA **8/8**, MANIFEST **8/8**.
- Nested P7 Handoff SHA-256 `45bd2a4faef714eb097d8681b5763812edf54e879ade9343a0f8fa70fd1b86f3` (expected exact **45bd2a4faef714eb097d8681b5763812edf54e879ade9343a0f8fa70fd1b86f3**) => **MATCH**. P7 Handoff CRC PASS, SHA **7/7**, MANIFEST **7/7**.
- **All levels:** **16/16 ZIP CRC PASS**; **123/123 SHA256SUMS entries PASS**; **115/115 available MANIFEST entries PASS**, no mismatch or missing entry. MANIFEST absent for contained `R11_ORIGINAL_PROPOSAL.zip`; its SHA256SUMS **8/8** checked; `N/A`, not fail.
- Historical parent original SHA-256 `735d9f0ce2b97d2b1543fb6a7a5d9a839b2ada30cb5a41e732f1115725d30160` is **not attached** => `NOT_VERIFIED`, even if other documents refer to it.

### Archive-level count reconciliation

| N | Archive terminal name (or P8 root) | ZIP CRC | SHA entries verified | MANIFEST entries verified |
|---:|---|---|---:|---:|
| 1 | `P8_INPUT` | PASS | 4 | 4 |
| 2 | `sources/Justice_RG310_C1_FULL_P7_Independent_Limited_Read_Only_Evidence_Result_2` | PASS | 8 | 8 |
| 3 | `sources/Justice_RG310_C1_FULL_P7_Limited_Owner_Decision_Readiness_Handoff_202610` | PASS | 7 | 7 |
| 4 | `sources/Justice_RG310_C1_FULL_P6_Fresh_Independent_Architecture_Review_Handoff_2` | PASS | 5 | 5 |
| 5 | `sources/Justice_RG310_C1_FULL_P5_Cross_Stream_Independent_Integration_Handoff_20` | PASS | 13 | 13 |
| 6 | `origins/P1_1_SOURCE_CLOSURE_RESULT.zip` | PASS | 6 | 6 |
| 7 | `origins/P1_2_TRACKED_TREE_RESULT.zip` | PASS | 10 | 10 |
| 8 | `origins/P1_3_SEMANTIC_SOURCE_RESULT.zip` | PASS | 6 | 6 |
| 9 | `origins/P1_SOURCE_EFFECT_RESULT.zip` | PASS | 20 | 20 |
| 10 | `origins/P2_ACTOR_EFFECT_REFERENCE_MONITOR_RESULT.zip` | PASS | 6 | 6 |
| 11 | `origins/P3_COMMIT_REVOCATION_ATTESTATION_RESULT.zip` | PASS | 6 | 6 |
| 12 | `origins/P4_BUILD_RELEASE_HOST_RESULT.zip` | PASS | 6 | 6 |
| 13 | `origins/R11_ORIGINAL_PROPOSAL.zip` | PASS | 8 | 0 |
| 14 | `origins/U07_NORMATIVE_SCOPE_RESULT.zip` | PASS | 5 | 5 |
| 15 | `sources/Justice_RG310_C1_FULL_P5_Independent_Cross_Stream_Integration_Result_202` | PASS | 7 | 7 |
| 16 | `sources/Justice_RG310_C1_FULL_P6_Fresh_Independent_Architecture_Security_Review_` | PASS | 6 | 6 |

The checks are **integrity of supplied bytes and internally declared files only**, not provenance authentication, human signature, secret safety, external accepted proof, repo protection, effective privileges or Host/CI runtime evidence. No code/command from the attachments was executed. Static Python `zipfile`, CRC, SHA-256, JSON/CSV parses were used only on archive bytes.

## 2. P7 rows & output conservation

- P7 original `04_P7_A_B_FALSIFIER_MATRIX.csv` read: **28**, IDs `FV-01..FV-28`.
- P7 original `05_P7_FAIL_CLOSED_STATE_TABLE.csv` read: **19**, IDs `ST-01..ST-19`.
- P8 output 04 has **47 rows** with all original columns/text/status values retained and separate P8 delta/tier/after-status columns; original row SHA256 over canonical sorted UTF-8 JSON is included for independent comparison. **0 P7 statuses overwritten/closed**.
- P6-N01–N06 and P5-F01–F08 are research observations/proposal findings; none closes **22 original formal Findings**.

## 3. Source identities, observed scope and limits

### Included byte-authenticated *packaged static research* (not original-owner authentication)

- P8 Handoff/Result original strings and nested P7/P6/P5 + 9 P1/P1.1/P1.2/P1.3/U07/P2/P3/P4/R11 research ZIPs with corresponding manifest hash verification.
- Approved normative R/D/P fixed commit: `8a2e4f1536e9cad499ee7e9d996ff163df132fd4`; existing approved v5 obligations remain, not upgraded to R11.
- Evidence fixed commit: `c428041dfb5779b6b6dc8db7bf14928225a00373`; pinned .github workflows and package.json. Source SHA-1 from GitHub file listing: `release.yml=4f984a012f3fa9421a32531a00394f4d654d5284`, `ci.yml=89570689e752937bd2e40f30a14c67e842181ef6`, `codecov.yml=3767d2f3b187623ebedd0cf9f4b93f1fbba236f0`, `semgrep.yml=763eec4ff600d8083a97114c209344bc421422ba`, `snyk.yml=58fae0a04274384530debc9ce0aed66116faa012`, `release-version-guard.yml=4fb66c1b49e022796cd51ff956b7793de8383cfc`, `package.json=8e154e09d0c6253d104b60e72208c5ff2a3478b4`.

### Fresh GitHub first-party **read-only observations** (current response values; not anchored to fixed 2026-10-14 snapshot)

| Exact GET/resource | Factual observation | Strict limit |
|---|---|---|
| `https://api.github.com/repos/yohi/justice/rulesets` | repository-level list returned one rule id **14286365**, name master, branch target, disabled | May not enumerate every alternative external authorization mechanism; cannot prove absence of effective writers |
| `https://api.github.com/repos/yohi/justice/rulesets/14286365` | `enforcement:disabled`, `conditions:ref_name.include=['~DEFAULT_BRANCH']`, deletion and non_fast_forward, `bypass_actors:[]`, `current_user_can_bypass:'never'` | No enforced veto from *this disabled rule*; bypass-actor response may depend on caller and not a global actor census |
| `https://api.github.com/repos/yohi/justice/branches/master` | `protected:false` with observed master commit `0a7fa07e2aad63ebd28b403876773d2f0c831e82` | Branch-specific metadata, not past state/effective credentials |
| `/repos/yohi/justice/branches/master/protection` | 403 `Resource not accessible by integration` | inaccessible; **not** an empty protection record |
| `https://api.github.com/repos/yohi/justice/pulls/325` | draft/open/unmerged, head `5cc14de814db139776436e87e5753110f41d4bc5` | draft evidence is not normative/human signoff |
| `/repos/yohi/justice/pulls/325/reviews` | `[]` in returned PR reviews | no reviews in that endpoint response, not complete audit of all decision stores |
| `/repos/yohi/justice/git/trees/0a7fa07...?...` and `/git/trees/5cc14de...?...` | recursive **404** current-master and **508** PR-head entries, API `truncated:false`; file names/potential owner labels screened, not a read of every file body | these 2 trees only, not full history or branches |
| `https://api.github.com/search/code?q=DS-01+repo:yohi/justice` / `...C1-FULL...` | two repo-indexed code searches returned `total_count:0` | indexed search can miss ref versions; not proof of absence |
| Repo issue search for DS-01/03/04/05/06 | zero matches in requested searches | does not cover all historical repositories, author signatures, chat, email, Drive or archived files |
| `https://api.github.com/repos/yohi/justice/actions/runs` | recent runs include CI, Coverage, Semgrep, Snyk success on PR325 HEAD 2026-10-22; reported total 4392 at query | Run metadata only; no invocation by P8 or proof of acceptance/credentials |
| `https://api.github.com/repos/yohi/justice/releases/403154810` | historical `v4.3.1`, `published_at:2026-10-04T18:38:12Z`, `immutable:false`, asset id610397097 sha256 `87b6aec445317c0f39335fdc34a7de5baef528898c39eaf89c98c7b0199dbf61`, size976180 | metadata for **v4**, not v5 and no readback of actual asset bytes or registry parity |

### Public platform/API documentation (only semantics, not this system's live proofs)

- https://docs.github.com/en/rest/repos/rules : disabled/evaluate excluded from active branch rules; response shape/bypass fields may depend on access.
- https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets/about-rulesets : disabled rules not enforced.
- https://github.com/googleapis/release-please-action : `release_created` conditional output and tag/release behavior.
- https://www.postgresql.org/docs/18/functions-datetime.html : transaction versus sample clock semantics.
- https://www.postgresql.org/docs/18/functions-info.html : past commit timestamp config/retention limits.
- https://www.postgresql.org/docs/18/runtime-config-wal.html : local and standby WAL durability modes; no independent global time or external signer atomic commit.
- https://docs.npmjs.com/cli/using-npm/scripts : prepublishOnly/prepack lifecycle.
- https://docs.npmjs.com/cli/commands/npm-publish/ and https://docs.npmjs.com/cli/commands/npm-pack/ : pack/publish bytes and dry-run semantics.

## 4. Missing evidence, not claimed absent

1. **Historically genuine** dated attributable Owner originals DS01/03/04/05/06 with verified signer/lineage; signed DS02 explicit population/Host custody. Bounded indexed search returned no authentic originals; no comprehensive all-branch/all-source signed search.
2. Effective permissions and branch/tag/ruleset states over time for *all* GitHub actors (App/PAT/admin/manual/deploy key), actual issuer authority and live npm/GitHub Packages policy, provider bypass and write credentials; rule detail permission restriction and protection GET 403.
3. Actual fixed release run tag/release first-write trace, full remote digest bytes registry vs release, external immutable policy, no public write from preview classification; conditional releases not every run.
4. Independently authenticated issuer-effective common order, externally bounded durable commit C, signer authenticated canonical seal/readback/refusal, API failure/partition negative oracles; broker does **not exist** and runtime evidence is **not demanded now**.
5. Durable independently signed high-water ACK(k), key epoch anti-rollback, old leader + reader + publisher physical fence, remote `UNKNOWN` digest/idempotency recovery and Host JS/native actual mapped/use-time witnessed bytes; no Host access or OS custody proof.
6. Historical parent ZIP `735d9f0c...30160` missing. No R11 approved human record; no approved R'/D'/P'. P1.3 previously unread 207 files remain outside P8 bounded body scan, do not claim all P1 reachability closed.

## 5. Immutable task/gate nonregression and research STOP

- `Architecture A=NO_GO_FOR_OBSERVED_SPLIT_DOMAINS`; `B=RESEARCH_ONLY_NOT_SELECTED`, not `GO` or R11 accepted; no universal impossibility claim.
- `R11 UNAPPROVED / R'/D'/P' NOT_ADOPTED`; `Task1 BLOCKED (31/32; Case A + unknown-tool BLOCKED, Case B PROVEN)`; `H0–H3 NOT_PROVEN`; original `22 Findings OPEN`; `NC37 NOT_EXECUTED`; `DS-01..06 FORMAL_PENDING`; `P2–P4 interface/schema STOP`; `Tasks2–14 NOT_AUTHORIZED`. C1-FULL research scope retained, no implicit C2.
- **NO** GitHub write, no workflow run, no runtime/Host/CI/DB/cloud access, no token/secret, no issuer/signing/HSA/Owner signature/formal Gate, no protected external effect, no approved R/D/P edits, no interface/schema freeze. External platform API semantics are static reference, not practical experiment.
- Owner agenda `05_...UNSIGNED` is **NOT A HUMAN DECISION**. Result manifest/zip only prove generated research artifact bytes, not authority. Any future change demands authenticated Owner decision, approved Requirements-first revision and separately explicit execution permission.
