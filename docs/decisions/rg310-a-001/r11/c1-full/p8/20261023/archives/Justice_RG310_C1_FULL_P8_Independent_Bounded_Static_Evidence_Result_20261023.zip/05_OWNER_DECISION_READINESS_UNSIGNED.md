# Justice RG-310-A-001 — P8 Owner decision readiness (UNSIGNED)

**Decision status:** `NEGATIVE_BOUNDED_STATIC_EVIDENCE_ONLY / NOT_READY_FOR_POSITIVE_A_OR_B_GO / OWNER_CHOICES_UNSELECTED`.

## Separated authority axes

1. Approved Justice v5 R/D/P at `8a2e4f1536e9cad499ee7e9d996ff163df132fd4`: fail-closed *acceptance* and independent evidence/approval chain are normative. Missing proof blocks accepted/current projection. V5 does **not** automatically assert retroactive physical suppression of noncooperating, historically distributed offline copies.
2. `U-07`: adding a universal retroactive enforcement quantifier would be an **additional** material requirement, not a proof that approved v5 was interpreted incorrectly. C1-FULL research direction is not C2, but it is also not a signed universal coercion obligation.
3. R11 38×7, INV-A01..A14, issuer-effective revocation and literal ACCEPT+PUBLISH remain **UNAPPROVED**. R'/D'/P' are not adopted or frozen. P8 is candidate research and is **not Justice Phase 8**.
4. **DS-02 population scope** choices and **A/B protocol** choices are orthogonal axes: do not rename DS02-A as architecture A or DS02-B as B.

## Historical decisions DS-01..06

P8 has verified packaged P7/P6/P5 proposals and rechecked bounded GitHub versioned trees and query-indexed results. No attributable, dated, signed authentic human originals for `DS-01, DS-03, DS-04, DS-05, DS-06` were established. `HISTORICAL_OWNER_ORIGINAL_NOT_VERIFIED / FORMAL_PENDING` does not claim universal absence. For DS-02, only C1-FULL **preferred research scope** in unsigned archived discussion is supported, while signed DS-02, exact host population and retroactive mandate are `FORMAL_PENDING`. GitHub PR325 is Draft/Open/Unmerged; no reviews were returned from the read-only PR review API. Neither PR status nor human username in commit metadata substitutes for Owner decision.

## Future DS-02 population alternatives (NOT_SELECTED)

- **DS02-A universal retroactive physical stop** of all historical third-party forks/offline copies: producer-only architecture cannot guarantee this without global external mandatory custody (unproved; offline counterexample remains).
- **DS02-B universal external mandatory enforcement** even over offline legacy population: future research hypothetical and requires independently provable universal deployment/control over existing machines.
- **DS02-C C1-FULL legitimate full lifecycle** across known channels and custodied/cooperating Supported Hosts, with explicit inability to forcibly stop noncooperating old offline machines: research candidate, not an automatic narrowing to C2 and not a decision.
- **DS02-D leave precise population boundary undecided** pending authentic Owner record and actor/policy custody evidence. No alternative selected here.

## Protocol alternatives (NOT_SELECTED)

- **Architecture A:** preserve literal atomic accepted bytes + independent proof + protected publication and strict issuer-effective Rv-S. `NO_GO_FOR_OBSERVED_SPLIT_DOMAINS`, absent proven shared ordering/clock/first-writer non-bypassable authority. This does *not* prove impossibility for all future designs.
- **Architecture B:** private `DB_COMMITTED_UNSEALED`, independent signer seal, separately authorized external effects, remote outcome/readback, trusted high-water and host-use proof. `RESEARCH_ONLY / NOT_R11_COMPLIANT / NOT_ADOPTED`. With strict Rv-S retained, cross-domain issuer ordering still requires proof. Proposed Rv-F requires explicit *human* material R' change and physical all-channel blackout between ISSUE and FENCE.

## Incremental P8 findings affecting a future Owner agenda, not an approval

| ID | New independent primary read-only evidence | Interpretation / pending decision |
|---|---|---|
| P8-E01 | GET `/repos/yohi/justice/rulesets` + detail: repository rule `14286365`, target default branch, `enforcement:disabled`, deletion/non_fast_forward; `bypass_actors:[]` in returned detail | No affirmative effective pre-Git-write veto from this rule. Decide what exact protected first writers require. Alternate credentials remain unknown |
| P8-E02 | GET `/repos/yohi/justice/branches/master`: `protected:false`; branch protection detail GET 403 (integration lacks permission) | No proof of effective branch protection from returned metadata; no universal policy absence assertion |
| P8-E03 | Re-fetched fixed six workflow files, release.yml pinned `c428041d...`, release-please **before** npm safety gate | Need normative protected-vs-uncertified-preview effect class and nonbypassable veto before conditional first tag/release, registry, asset, SARIF, coverage, artifact, PR/status |
| P8-E04 | GitHub REST historical v4.3.1 Release id403154810: `immutable:false`, asset digest and time supplied | REST readback metadata feasible, but no v5 frozen-byte equality, run causality or adopted acceptance witness |
| P8-E05 | Archived PR325 is draft/open, head `5cc14de...`, PR review API returned `[]`; master/PR trees 404/508 untruncated | P7/R11 evidence preserved but no formal Owner signature found in bounded indexed search; unsearched stores remain unknown |
| P8-E06 | PG18 documented `transaction_timestamp`, `clock_timestamp`, local commit timestamp and WAL synchronous modes; GitHub ruleset docs | No independently authenticated **cross-provider durable COMMIT C** or issuer order; future specs need falsifiable bound, not a demand for nonexistent runtime |

## Future human choice requiring independent Requirements-first procedure

Any decision changing scope, protected effect classes, issuer-effective time to fence-effective time, literal atomic R11 accepted semantics to staged accepted semantics, signer/issuer trust boundary, recovery high-water, host use-time custody or forced retroactivity **requires a separately attributable human Owner decision**, approved new R'→independently reviewed D'→P' chain, fresh negative evidence plan and later discrete authorization. P8 cannot provide a human signature. The agenda should specify veto/denial authority per effect and exact R11 38×7 mapping rather than generic assertions about 'atomic' or 'clock'.

### Nonregression / STOP

`R11 UNAPPROVED`; `Task1 BLOCKED (31/32; Case A + unknown-tool BLOCKED, Case B PROVEN)`; `H0–H3 NOT_PROVEN`; `22 Findings OPEN`; `NC37 NOT_EXECUTED`; `DS-01..06 FORMAL_PENDING`; `P2–P4 interface/schema STOP`; `Tasks2–14 NOT_AUTHORIZED`. No HSA, Gate, release, registry, CI/Host or runtime actions permitted. **C1-FULL research retained**; no C2 implicit substitution.
