# Justice RG-310-A-001 — P6 Owner DS-01..DS-06 decision readiness, UNSIGNED

**Status:** `CANDIDATE_DECISION_AGENDA_ONLY / OWNER_NOT_SELECTED / NO_HSA / NOT_AN_EXECUTION_GRANT` (2026-10-23 JST). This is a technical questioning aid; not an Owner Decision Record or an amendment.

## Authority text versus author-proposed questions

| Authority tier | Actually grounded content | NOT implied |
|---|---|---|
| Approved v5 R/D/P @ `8a2e4f1536e9cad499ee7e9d996ff163df132fd4` | Exact human approval lineage; `JUS5-GATE-02` requires fail-closed acceptance; `INV-04/06` missing evidence blocking and no unauthorized lower-level normative expansion | It does not approve R11, A, B, Rv-F, cross-provider atomicity, or universal physical offline prevention |
| Archived R11 original (unapproved) | Hypothetical independent pre-effect grant/monitor, fresh revocation at COMMIT, atomically inseparable authoritative bytes and accepted record, all 38×7 states and INV-A01..A14 | No operational HSA, no documented issuer-t0 global linearization, no currently proven provider deployment |
| Archived U-07 independent adjudication (unsigned) | Universal historical offline premise is conditional addition, not explicitly approved v5 duty; C1-FULL all legitimate producer lifecycle research direction retained; DS-02 FORMAL_PENDING | No approval of DS02-A/B/C/D, no C2 narrowing, no signed human DS-02 original wording |
| P5 Result `06_OWNER_ARCHITECTURE_DECISION_READINESS_UNSIGNED.md` | P5's suggested DS-01..06 questions, A/B candidate state machine and unknowns | **Not earlier human decisions**. DS-01/03/04/05/06 are P5-*proposed agenda slots*, not original Owner decision text |
| P6 (this document) | Independent conditional falsifiers and exact evidence needed | Not Owner/Coordinator or formal Gate authority |

## Decision slots — questions only, no default

| Slot | Material question & proposed alternatives (UNSELECTED) | Minimum disconfirming evidence/negative control | State |
|---|---|---|---|
| DS-01 — authority/TCB custody (P5-proposed) | Single truly authoritative byte+root serializer **versus** DB-only coordinator with detached independent seal; who owns keys, GitHub and OS/admin root, CI, native child, Host? | Credential/principal inventory; direct-path, inherited FD, GitHub alternate token/API and old-primary bypass; physical reader/writer fences | `NOT_SELECTED / NOT_READY` |
| DS-02 — formal C1-FULL scope (U-07 derived pending agenda) | **DS02-A** literal arbitrary historical offline universal coercion; **DS02-B** mandatory external platform/third-party roots; **DS02-C** full legitimate prospective producer lifecycle + cooperating/custodied Supported Host with explicit historic-out-of-bound disclosure; **DS02-D** pause pending independent roots | Evidence for all legitimate producer controlled CI/Git/package/Host effects and actual principals; source text of human decision absent. No owner selection; C is **not** automatic C2 | `FORMAL_PENDING / NOT_SELECTED` |
| DS-03 — revoke and time (P5-proposed) | Rv-S strict issuer-effective-at-issuance (requires common ordering) **versus** Rv-F pending+blackout→physically fenced-effective (materially different). Define trusted expiry check instant: durable DB COMMIT / external seal / remote effect / Host t_use | `t0 ISSUE < t1 COMMIT < t2 IMPORT`; `C=[9,11]`, expires 10; old writer succeeds pending fence; unknown/overlap ⇒ STOP | `NOT_SELECTED / NOT_READY` |
| DS-04 — accepted state and external visibility (P5-proposed) | One atomic authoritative byte+record+scope contract with provably shared custody **versus** new `DB_COMMITTED_UNSEALED→EXTERNALLY_SEALED_VISIBLE→per-effect admitted remote effects` states; exactly which externally visible effects belong to original atomic unit? | Detached signer refuse/pre-sign/ACK loss; Git release succeeded but registry failed; reader leaked before seal; no remote exactly-once inference | `NOT_SELECTED / NOT_READY` |
| DS-05 — bytes/release/Host (P5-proposed) | Which immutable source+lock+toolchain+JS/native+canonical tarball+registry asset+actual loaded JS/native+origin closure is mandatory; what is preview vs certified? | release-please before gate; two independent npm pack actions; registry replacement/cache; direct source import, native image swap, H0–H3 | `NOT_SELECTED / NOT_READY` |
| DS-06 — independent proof/recovery (P5-proposed) | ACK high-water external truth, signer independence and key epochs, backup restore monotonicity, old-primary physical fencing, remote UNKNOWN policy, terminal no-effect evidence | ACK(42)→restore(41)→CURRENT(41); old primary still holds creds; signer refuses after DB commit; public tag orphan | `NOT_SELECTED / NOT_READY` |

## Exact material candidate normative deltas in mandatory order (not a change request)

### Requirements R' — candidate only

| Candidate | Add/modify in future human-adopted Requirements | Why required |
|---|---|---|
| R'-01 SCOPE | Finite set/predicate of every protected effect, producer-controlled actual principal and Supported Host; public preview/certified namespace distinction; DS02 conditional historical scope declaration | Otherwise absolute monitor coverage is not a falsifiable property |
| R'-02 REVOKE | Revocation `issuer t0` versus authorized receipt/linearized fence effective event; blackout and stale writer/reader requirements; fresh check per protected effect | Original R11's `fresh_at(commit)` does not settle issuer-time globally |
| R'-03 CLOCK | Precisely define durable COMMIT interval `[C_lower,C_upper]`, before/at deadline inclusivity and uncertainty STOP, independent trusted time source and issuer ordering | SQL preflight `now()` is not durable event evidence |
| R'-04 STATES | Choose literal single authoritative byte+proof acceptance or explicitly new two threshold DB candidate/seal with externally admitted remote effects and separate visible/current/unknown states | B is incompatible if falsely renamed old `OP_COMMIT_ACCEPTED` |
| R'-05 REMOTE | No blind retry/exactly-once without endpoint proof; remote effect partial/success/unknown, readback, orphan quarantine/incident, irreversible publication truth | DB rollback cannot undo public Git/registry publication |
| R'-06 RECOVERY | Independent signer/keys + high-water ACK, gap-free accepted/aborted terminal history, recovery interval, old-primary credential/network/reader fencing | Hash-chain alone is actor reconstructable |
| R'-07 BYTES | Exact frozen artifact producer and source/native/JS dependency closure → same registered/release artifact → installed *actual loaded* JS+native `t_use`; H0–H3 proof distinct | No transitive trust from Git SHA or `.node` existence |
| R'-08 GATE | Separate canonical Task1 `R`, compiled `P` and later product/production `I`, actual runtime race A07, persistence sanitation A10/A12, and 38×7 + INV-A01..A14 without waiver | No B1/DB signature substitutes Case A or unknown-tool Task1 evidence |

### Design D' — after R' approval and independent review only

Name actual TCB and mandatory mediation for every writer/read; platform effect-specific credentials; immutable builder with no publish capabilities; one frozen artifact and independently attested readback; exact DB/signer/issuer/clock/quorum/old-primary/state machines and trust roots, read-only/unknown/incident behavior; explicit safe recovery and finite impossible-to-accept counterexamples. Do not freeze draft P2/P3/P4 interface while any upstream obligation is unresolved.

### Plan P' — after approved D' and independent review only

Trace each requirement to independently testable pre-effect rejection/oracle and negative cases in GitHub/registry/OS/native/FD/old primary/issuer-time/actual Host, but mark all execution as requiring **separate future human HSA, Gate and bounded authorization**. Never turn research suggestions into live steps; no CI, DB, host or cloud test is authorized now. Keep a separate Task1 A1 canonical evidence route.

## Decision-readiness result

`READY_TO_PRESENT_EXPLICIT_CHOICE_PREMISES` but `NOT_READY_TO_ACCEPT_A_OR_B`, `NOT_READY_TO_UNFREEZE_INTERFACES` and `NOT_READY_FOR_IMPLEMENTATION_OR_TEST`. A remains NO_GO on **current split-domain assumptions**, not a universal impossibility. B is only a candidate conditional state-machine, with unresolved signer failure liveness, irreversibility and physical bypass. The next authorized action, if any, is limited to non-executing independent source/provenance and human-scope clarification. No DS has been signed, no historical Owner wording is inferred from P5's new labels.
