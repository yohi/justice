# Justice RG-310-A-001 — P6 Limitations, checksums, nonregression and STOP

**2026-10-23 JST · READ-ONLY STATIC · NO OWNER APPROVAL / NO HSA / NO GATE / NO SIGNATURE**

## 1. Input bytes, measured independently

P6 submitted ZIP 746,586 bytes; computed SHA-256 `f4b9767f60af3e5a8d2c697fbc53eaa597e636dff9e868c03b24fb97f4b37dd4` **MATCH externally provided expectation**; ZIP CRC PASS. Outer SHA256SUMS 5/5, MANIFEST 5/5. P5 Result original 70,545 bytes SHA `18db3dbe6ff187539ce9941cafd03806f7dfaa4732d077d70c61d4de7b6eb738`, P5 Handoff original 669,363 bytes SHA `b7f7fd3b06164740d80c8dcf6b2731b8b2ab1b788c8b8a62e758f56f7c5c91df`, both CRC PASS. Complete hierarchy:

| ZIP | Byte length | SHA-256 | CRC | SHA256SUMS | MANIFEST |
|---|---:|---|---|---:|---:|
| Justice_RG310_C1_FULL_P6_Fresh_Independent_Architecture_Review_Handoff_20261022(2).zip | 746586 | f4b9767f60af3e5a8d2c697fbc53eaa597e636dff9e868c03b24fb97f4b37dd4 | PASS | 5/5 | 5/5 |
| Justice_RG310_C1_FULL_P5_Independent_Cross_Stream_Integration_Result_20261022.zip | 70545 | 18db3dbe6ff187539ce9941cafd03806f7dfaa4732d077d70c61d4de7b6eb738 | PASS | 7/7 | 7/7 |
| Justice_RG310_C1_FULL_P5_Cross_Stream_Independent_Integration_Handoff_20261022.zip | 669363 | b7f7fd3b06164740d80c8dcf6b2731b8b2ab1b788c8b8a62e758f56f7c5c91df | PASS | 13/13 | 13/13 |
| P1_SOURCE_EFFECT_RESULT.zip | 225649 | 2407afbe5deedb42f86e1b65ec9be0aeb02b28e13192253d34e77df02142df7e | PASS | 20/20 | 20/20 |
| P1_1_SOURCE_CLOSURE_RESULT.zip | 39047 | 6a1b5915a3d2e6e90f9287b9d8f116e04aa36d54adef365eed4816bbb3003613 | PASS | 6/6 | 6/6 |
| P1_2_TRACKED_TREE_RESULT.zip | 69454 | d7125e2f60b93d2b9bc3a35dd857c3875962fdb44ceedf1bb230716eb7a07fbf | PASS | 10/10 | 10/10 |
| P1_3_SEMANTIC_SOURCE_RESULT.zip | 58687 | a17c108d917bbc7312e2abb0d09f83fa53e004927be6d07eecfc1af5cf71c1a0 | PASS | 6/6 | 6/6 |
| U07_NORMATIVE_SCOPE_RESULT.zip | 25546 | d4394e0b2d5da3eac4485785f65a83c55e8573bd73a0739f109b8ff54884c439 | PASS | 5/5 | SCHEMA_ADAPT_OR_ABSENT |
| P2_ACTOR_EFFECT_REFERENCE_MONITOR_RESULT.zip | 39174 | f64def3bf0118d04acde37ff6cc6b770f23939dda95fc63f438a8c955a9bc887 | PASS | 6/6 | SCHEMA_ADAPT_OR_ABSENT |
| P3_COMMIT_REVOCATION_ATTESTATION_RESULT.zip | 35871 | a1da8844767dfa75179f727b88fd28b5056f1ec4a187a1ce5039b3eecfafa089 | PASS | 6/6 | 6/6 |
| P4_BUILD_RELEASE_HOST_RESULT.zip | 40079 | f603d448860f8233457fd0a164dd1b23c9a9d09af1bdd90cc97e3d0938e7d85d | PASS | 6/6 | 6/6 |
| R11_ORIGINAL_PROPOSAL.zip | 127433 | 1df24d4250132a3df1bc2c4d39b53baebbe1b1d8ad8060862c0531743601d185 | PASS | 8/8 | SCHEMA_ADAPT_OR_ABSENT |

In the above automatically captured hierarchy, the generic parser's `SCHEMA_ADAPT_OR_ABSENT` is resolved by exact schema-aware checks below. Specifically, U-07 and P2 use `files[].name/bytes`, P4 uses `files[].path/size`; these are **all PASS**, not missing/broken. R11 original ZIP has SHA256SUMS 8/8 but **no MANIFEST**.

- `P1_1_SOURCE_CLOSURE_RESULT`: 6/6 source-MANIFEST records byte/hash/size verified.
- `P1_2_TRACKED_TREE_RESULT`: 10/10 source-MANIFEST records byte/hash/size verified.
- `P1_3_SEMANTIC_SOURCE_RESULT`: 6/6 source-MANIFEST records byte/hash/size verified.
- `P1_SOURCE_EFFECT_RESULT`: 20/20 source-MANIFEST records byte/hash/size verified.
- `P2_ACTOR_EFFECT_REFERENCE_MONITOR_RESULT`: 6/6 source-MANIFEST records byte/hash/size verified.
- `P3_COMMIT_REVOCATION_ATTESTATION_RESULT`: 6/6 source-MANIFEST records byte/hash/size verified.
- `P4_BUILD_RELEASE_HOST_RESULT`: 6/6 source-MANIFEST records byte/hash/size verified.
- `U07_NORMATIVE_SCOPE_RESULT`: 5/5 source-MANIFEST records byte/hash/size verified.

Other nested SHA256SUMS plus P5/P6 top sums verified by direct ZIP byte hashing (see counts). The historical earlier parent ZIP `735d9f0ce2b97d2b1543fb6a7a5d9a839b2ada30cb5a41e732f1115725d30160` **NOT_ATTACHED / NOT_VERIFIED**, even though later original ZIPs mention this SHA. A checksum proves submitted bytes match a separately supplied digest, not their human authorship, independent source-of-truth rights, normative correctness, or signer authenticity.

## 2. Fixed pins, independent GET-only scope

- Task1 Evidence HEAD: `c428041dfb5779b6b6dc8db7bf14928225a00373` (no change).
- Approved Requirements/Design/Plan HEAD: `8a2e4f1536e9cad499ee7e9d996ff163df132fd4` (no change).
- Fixed tracked tree: `2c1e8bd2f57cdc4eb47cf6a07b5934704c1b18f4`; historical P1.2 inventory 431 entries / 386 blobs / 45 trees (count inherited from original source report, not independently re-enumerated via live Git tree here).
- P5 Handoff exact 9 source originals and P5 Result 7 outputs remain byte-identical to their enclosed/claimed checksums; no embedded programs executed.
- GET-only GitHub `fetch_file` source path/ref and blob identities independently rechecked for release workflow, CI workflow, release guard, native JS provider and node filesystem/runtime status. Requirements `JUS5-GATE-02` and Design `INV-04/INV-06` exact approved HEAD fetched as read-only source excerpts. Approved Plan source blob SHA is inherited from U-07/P4 original report, not independently refetched during P6.
- R11 original 38×7 `266/266` cell equality against P5 overlay checked by original lines 315–352; this does not prove 14 invariant behaviors. 174 typed graph and 251 typed register row counts independently recomputed. 32 P5 traces remain paper only.

## 3. Epistemic/structural gaps (not passed)

- No real issuer event order/physical fencing, signed ledger/trusted independent clock/actual durable COMMIT instant, external independent signer availability/refusal/ACK/backup, DB atomic visibility or provider-wide atomic remote publication measured.
- No effective GitHub App/PAT/deploy key/admin/ruleset bypass rights, third-party Codecov/Sonar/SARIF/registry/runner capability or actual remote effect occurrence verified. Source-permitted actions are **not** observed writes.
- No actual `npm publish` tarball, immutable registry readback, Release asset digest, exact installed JS/native, trusted Host *actual loaded bytes at t_use*, external Host origin H0–H3 or A07 runtime race/sanitation A10/A12 demonstrated.
- Original P1.3 reports 207 of 341 tracked blob bodies not read in that static investigation; the P1 source/effect legitimate actor population is incomplete. P6 did not re-census missing bodies or all provider configurations. `p4_id` sentinel and placeholder SHA values must be interpreted as documentation metadata only, not proven integrity edges.
- DS-01/03/04/05/06 are agenda names generated by P5, not signed historical Owner decisions. DS-02 formal scope alternatives in U-07 original are likewise UNSIGNED choices; do not promote them into approved human records. `U-07` universal offline path is a **conditional additional quantifier** rather than approved v5 duty. No automatic C1-FULL→C2 scope reduction.
- External human authority, GitHub permissions, live actor TCB, old-primary fence, registry capabilities, signer/clock, supported host population and complete original historical parent remain unresolved. Thus A/B feasibility remains conditional and no actual runtime proof is supplied.

## 4. Mandatory unmodified status ledger

| Subject | P6 state (not changed) |
|---|---|
| Approved v5 R/D/P | **UNCHANGED** @ `8a2e4f15…` |
| R11 architecture | **UNAPPROVED**, original 38×7 plus INV-A01..A14 preserved |
| Task1 canonical evidence | **31/32 PROVEN**, Case A **BLOCKED**, Case B **PROVEN**, unknown-tool **BLOCKED** |
| H0–H3 true ingress/Host origin | **NOT_PROVEN** |
| Original findings | **22/22 OPEN**, P5/P6 notes do not close/reclassify |
| Original NC-01..37 | **37/37 NOT_EXECUTED** |
| P2/P3/P4 interface | **INTERFACE_FREEZE_STOP**, no schema freeze or implementation authority |
| DS-02 | **FORMAL_PENDING**; DS-01/03/04/05/06 **NOT_SELECTED** |
| B0/B1/B2/DEP/PREP/RA/ACTIVATE/HOST | **NOT_AUTHORIZED** for task execution under this review |
| Tasks 2..14 | **NOT_AUTHORIZED** |
| Formal Gate / human adoption / HSA / publish | **NONE; STOP** |

## 5. Work allowed/performed and work strictly not performed

Performed: local offline ZIP/header/decompressed member SHA-256, CRC and schema-aware manifest comparison; static CSV/Markdown comparison and exact GitHub read-only file retrieval at pinned commits; independent creation of this review package from safe local output code. **Not** performed: any code/script from input ZIP, CI/OS/DB/cloud/Host tests, source mutation, GitHub write, commit/push, tag/release/publish, secrets, signing, HSA or formal Gate. Result ZIP SHA is a transport integrity hash, never human authorization. This package cannot unfreeze, grant or adopt Architecture A/B. Future research permitted by this report is documentary only and still subject to human/owner process when outside supplied evidence.
