# C1-FULL P1.1 — Publish / Actual Use Trust Boundaries (UNSIGNED)

**Investigation mode:** fresh independent static source/CI/host investigator, 2026-10-22 JST. **Verdict: `NOT_EXHAUSTIVE / INTERFACE_FREEZE_STOP`.** Accepted C1-FULL is *directional preference*, formal DS-02 `PENDING`. No source/PR/CI/DB/cloud/host/OS operation or execution was performed. GitHub connector `fetch_file(ref=exact HEAD)` used for source reading only.

## 1. Precisely bounded source facts and evidence classes

Fixed Justice **c428041dfb5779b6b6dc8db7bf14928225a00373**; approved normative R/D/P **8a2e4f1536e9cad499ee7e9d996ff163df132fd4** (not superseded); R11 proposal *UNAPPROVED*. P1's existing 74 (`CE-01..28`, `N-01..46`) are preserved in `02`; **N-47..N-54** are appended as distinct, partially overlapping subpaths. P1 original classification remains 64 source / 7 proposal / 3 not verified **as imported P1 labels**, not newly certified system-wide evidence. Current-turn checks specifically reread release, CI, package, OpenCode adapter/tool, CLI, JS/native files and additional utility sources; 28 imported P1 source anchors had their blob SHA independently matched through fixed-ref connector re-fetch (some re-fetches were line-windowed). GitHub `fetch_commit` returned commit metadata, but **not the Git tree object/list**; `fetch_file` rejects directory paths. No recursively enumerated complete tree, no Git tree SHA, no absence proof for other workflow files, scripts, symlinks or submodules. `01` is an honest bounded source-inventory/coverage ledger, **not** a closed repository census.

`PINNED_SOURCE` means the repository *source line and blob* were retrieved; it does **not** mean that an Actions job ran, the package was published, native was loaded, source was deployed, or a particular deny actually occurred. All effective GitHub permissions, actual issuer tokens, branches/tags, organization controls, build runner, registry, host, FD and network effects remain `NOT_VERIFIED`.

## 2. GitHub Actions publication graph and concrete source anchors

```text
push(master) ---> .github/workflows/release.yml (blob 4f984a012f3fa9421a32531a00394f4d654d5284)
                | permissions: contents/pull-requests/packages write (lines 3-11; DECLARED ONLY)
                | release-please-action@45996ed... (lines 13-19)
                | if release_created: checkout(ref=release.outputs.tag_name) (lines 21-24)
                | setup-node registry npm.pkg.github.com + setup-bun + bun frozen lock + Rust
                | build:native:review-artifact -> dist/native/index.linux-x64-gnu.node
                | bun run build -> tsc; bundled dist/opencode-plugin.js; chmod doctor-cli
                | upload-artifact dist/ (GitHub artifact service)
                | npm pack --dry-run --json --ignore-scripts (checks .node *listed*, NOT full digest)
                | npm publish --ignore-scripts / NODE_AUTH_TOKEN=secrets.GITHUB_TOKEN
                | separate npm pack -> gh release upload tag packageFile / GITHUB_TOKEN
                v
          Published registry package bytes / distinct GitHub release asset
                v
       package extract or other acquisition / OpenCode cache / arbitrary consumer
                v
      dist/opencode-plugin.js OR /core /runtime OR bin justice OR source import
                v
             JS / optional native .node / host children / FS & stdout
```

The actual configured `GITHUB_TOKEN` scope, org rules, allowed actors, release creation, tag immutability and external GitHub API writers were **not** inspected or inferred as controlled. A source workflow token's declared write scope does **not** prove an issued principal, repository branch protection, or absence of administrative bypass. Source-specific concrete branch: `release.yml:21-24` checks out a **tag** from the release-please output. That tag's commit is not independently bound to a B2 accepted seq/digest, and it need not be the fixed evidence HEAD. The Actions runtime may download dependencies and native toolchain outside the fixed Justice source bytes.

`release.yml:54-73` differentiates (1) dry-run pack listing a native file, (2) `npm publish --ignore-scripts`, and (3) a later **separate** `npm pack` with upload to a GitHub release. They are three operations, not one sealed artifact identity. There is no recorded proof of same emitted package content, package hash, registry stored bytes, release upload digest or host-loaded dependency closure; verifying file presence does not prove byte correspondence. `--ignore-scripts` on publish also means invoking a regular `prepublishOnly` chain cannot be presumed: `package.json:42-53` defines one, but the workflow explicitly disables lifecycle scripts for publishing.

`ci.yml` (blob `89570689e752937bd2e40f30a14c67e842181ef6:3-40`) exposes push/master and pull_request/master triggers, `actions/checkout`, `oven-sh/setup-bun@v2` (symbolic non-commit ref), a global `opencode-ai@1.18.29` install, Rust/native build/test, JS/lint/dist/integration test commands and artifact upload. This does not establish PR actions are harmless, actual dependency bytes pinned, CI permission defaults, secret exposure or uploaded-artifact custody. No other workflows have been ruled out.

**Falsifiers to request later (not execute here):** a tree SHA and complete workflow dispatch table; actual tag commit vs authorized accepted source; a cryptographic digest for built dist, native ELF, registry package and release tarball; authenticated protected publisher principal and pre-effect deny; GitHub API actor inventory (including admins/apps/other workflows); negative test where different tag/build/native/tarball bits are refused. Artifacts must cover both independent pack sites.

## 3. Package exports and runtime reachability: SOURCE is not actual use

`package.json` blob `8e154e09d0c6253d104b60e72208c5ff2a3478b4:12-41` exposes `.`, `./opencode` (dist/opencode-plugin.js), `./core` (dist/index.js), `./runtime` (dist/runtime/node-file-system.js), `bin.justice` (dist/runtime/doctor-cli.js). README blob `a75a01099e176fd37dd07e0c0958739f5ba0def9:72-165` describes package registry installation, source build, direct import from opencode config. `src/index.ts:1-125` includes a broad API barrel with `JusticePlugin`, filesystem, PlanBridge etc., not a single private Gateway-only interface. The source dependency graph is **not complete**, and actual dist outputs, package extraction, resolution, loader URLs/cache and dynamic imports were **not captured**.

`src/runtime/linux-review-artifact-provider.ts:68-106,190-202` (blob `27b3a430c9015bbaf65ac3ec00e80c23121794c4`) only conditionally loads `.node` via `createRequire(import.meta.url)` and a URL relative to JS runtime location. If platform/arch/glibc/probe/root-open fails, it returns undefined. `native/review-artifact-linux/src/lib.rs` (blob `0ac586948240ebee2360ef2a063048563a8d6426`) has descriptor-relative syscall operations, including openat2/renameat2 for **that operation's** review-artifact path. This does not constrain generic Node FS, GitHub publish, inherited host descriptors, arbitrary child processes, or third-party copied packages. No native ELF hash, dynamic linker closure, inode binding, syscall observation or successful host probe was obtained.

**TOCTOU:** source commit checked vs tag resolution; lockfile name vs registry fetched bytes; emitted dist vs independent pack; package metadata vs actual extracted bytes; addon `.node` path existence vs require; config read vs plugin loaded; module cache vs hot reload; artifact EAF preflight vs `t_use`. An EAF fingerprint becomes an actual-use attestation only with a trusted, nonbypassable verification at the relevant effect or loader and a denial on mismatch, both **NOT_VERIFIED** here.

## 4. OpenCode entrypoints: defined tools != exposed tools

`src/runtime/justice-tools.ts:20-96` (blob `f0ac0943c6c156672891e6625f600071c6ae0606`) defines `defineJusticeStatusTool` and `defineJusticeGateTool`, with status projection cache write in the former; they are **definitions**. `src/runtime/opencode-adapter.ts:182-190` (blob `42a2209500ade4b1cff0798f5378ff3a8cd11da0`) `getTools()` returns only `justice_review`, which `src/opencode-plugin.ts:61` exposes as its tool map. Therefore `justice_status` and `justice_gate` are **not registered through this current plugin return value**, not an assertion that no third-party host or other version ever registers them. `src/runtime/opencode-adapter.ts:645-710` returns `PROCEED` for `justice_*`, no-op/uninitialized cases and catch errors, so this hook is not evidenced as a fail-closed, universal C1 pre-effect reference monitor. Source finding only; no exploit was run.

`src/runtime/command-registration.ts:13-49` (new N-47, blob `648f0d81966c6b2a10637f7ef17d89d204fc9866`) registers `justice-start` and `justice-implement` into OpenCode `config.command`, with prior user-defined names preserved. README `242-255` explicitly states `.opencode/commands/*.md` may be loaded by the host outside that config hook (N-48). Consequently command resolution/collision is a separate host producer/consumer trust edge; actual precedence and loader byte identity are **NOT_VERIFIED**.

`src/runtime/doctor-cli.ts` (blob `09a3b7c452dda108a6040f53db47ae30b0d8e1cf`) is an independent exported bin. `109-158` uses `Bun.spawn` with caller cwd and env and pipes; `164-205` executes `opencode --version` then `opencode debug config` (provided the first reports exactly expected version); `207-222` implements `justice status`, reading plan/telemetry via NodeFileSystem; `497-539` selects status or doctor, dynamically `import(entryFile)`, and writes stdout. `doctor` is **not passive inspection in its actual runtime semantics**. Future investigation must resolve the OpenCode executable, inherited capabilities and env, importer-resolved modules, children/grandchildren, debugger config loaders and stdout/stderr destinations. No call/run occurred here.

## 5. Additional filesystem / notification paths and why they matter

| New row | Fixed source anchor | Separate terminal effect / TOCTOU issue | Existing overlap |
|---|---|---|---|
| N-49 | `src/core/wisdom-persistence.ts:50-56` | `save` directly writes Wisdom JSON, not necessarily the locked atomic path | CE-11, N-41/42 |
| N-50 | `src/core/wisdom-persistence.ts:130-163` | `saveAtomic` comments explicitly identify unlocked load→merge→write; temp rename and cleanup side effects | CE-11, N-42, N-49 |
| N-51 | `src/runtime/opencode-notifier.ts:19-43` | host logger callback and fail-open on errors; notification is not durable approved effect evidence | N-19/20 |
| N-52 | `src/runtime/debug.ts:6-26` | DEBUG environment may enable `console.warn` to host stderr/log sink | N-19/21 |
| N-53 | `src/runtime/doctor-cli.ts:207-222;497-511` | distinct CLI `justice status`, filesystem reads and stdout; **not** `justice_status` plugin tool | CE-10/N-31/32 |
| N-54 | `src/runtime/doctor-cli.ts:109-205` | concrete host child-execution command arguments and inherited env | N-31..33 |

`src/core/wisdom-archive.ts` and `src/hooks/plan-bridge.ts` were freshly fetched as additional source anchors but their full dependency/effect subgraphs are **not** enumerated. Similar caveat applies to `src/core/atomic-persistence.ts`, Node FS, observation JSONL, cache and gate-loader paths retained verbatim from P1. Local tmp/rename durability is not a PostgreSQL accepted transaction or an independently signed ACK.

## 6. Counterexample: already distributed third-party package vs private Gateway

Assume a legitimate package `T0` was published and downloaded earlier by third party `C_ext`, which already owns the package bits and its host runtime/credentials/FS. At time `t1`, producer deploys private Gateway `G` with PostgreSQL accepted-state atomicity. At `t2`, `C_ext` loads its **local copy** of `T0` directly (`import`/`require`/CLI) without contacting producer or `G`; the actor can also fork or remove the optional plugin code. Producer DB accepts/rejects no operation at `t2`, and nothing prevents that local process from using its own permitted capabilities. Hence **universal retroactive mandatory gateway use does not follow** from producer-side DB atomicity or signing. An independent nonbypassable distribution/use boundary for the *particular protected effect* would be required; third-party environments without it are outside unilateral publisher control. This is a structural counterexample to any strict C1-FULL wording that demands that guarantee, not proof that no valuable producer-side fenced C1 proposal can be designed.

**Forbidden shortcut:** silently replacing C1-FULL with C2-LIMITED or excluding external consumers. **Permitted next step:** unsigned Owner question clarifying exactly which effects/actors can be protected and whether strict public-consumer language must be amended. All DS-01..06 remain `PENDING` and the original reference monitor, time/revocation/ack strict constraints remain in force until independent review/Owner choice.

## 7. Logical/independent proof boundaries

- **GitHub-side source and declared workflow** are not equivalent to effective repository token settings, actual build provenance or release publication.
- **Accepted source digest** is not equivalent to JS/native/tarball digest; and these are not equivalent to host-loaded bytes at `t_use`.
- **Internal PostgreSQL COMMIT** is not equivalent to remote GitHub/NPM effect or durable signer+ACK event. Expiry at preflight is not durable-commit expiry; authority-order revoke does not establish independently recorded issuer-issued revoke timestamp.
- **Host logger, CLI, shell, network, native openat2/renameat2 and inherited FD** have distinct principals and effect domains. Cannot claim all have a single monitor from the JS hook.
- **Negative test cases are NOT_EXECUTED.** No isolated host, CI, DB, cloud or OS E2E was conducted.
- **OmO 091728d... / Senpi d56e6a...** are external sources named by the historical plan; pinned source and genuine H0/G1/G2/Case A runtime origin are **NOT_VERIFIED** by P1.1. Unknown tooling remains BLOCKED.

**P1.1 conclusion:** Known direct effects and additional source subpaths are falsifiable research inputs. A complete pinned repository tree was not available; real third-party consumers and actual effect evidence are not enumerable from it. `NOT_EXHAUSTIVE / INTERFACE_FREEZE_STOP` continues. P2/P3/P4 may use these **only as conditional inputs**, not frozen interfaces or authorizations.
