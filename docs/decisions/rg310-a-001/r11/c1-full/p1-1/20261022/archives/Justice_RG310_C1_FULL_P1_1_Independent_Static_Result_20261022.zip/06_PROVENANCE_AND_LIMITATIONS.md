# P1.1 Provenance and Limitations — independent byte check / source-only

Date: 2026-10-22 JST. Measured current uploaded path: `/mnt/data/Justice_RG310_C1_FULL_P1_1_Independent_Source_Closure_Handoff_20261022(1).zip`. All checks performed using locally-authored standard-library Python file/ZIP/hash parsing. Supplied scripts/commands were **not executed**. No hosted repository, runtime, machine/OS, CI, DB, cloud, installed module, secret, or native program was invoked. GitHub access was limited to read-only connector fetches at fixed commit.

## Nested archive integrity results

| Input | Independent expected SHA-256 | Measured SHA-256 | CRC | SHA256SUMS | MANIFEST | Verdict |
|---|---|---|---|---|---|---|
| Current outer handoff ZIP | `e19dd9645a1d82b43dcda903397e5b1b6c0d853ca3c045bb7a7e7b6ec598647a` (from user's message, separate from file) | `e19dd9645a1d82b43dcda903397e5b1b6c0d853ca3c045bb7a7e7b6ec598647a` | PASS / 6 entries | PASS / 4 entries | PASS / 4 entries | **MATCH** |
| Inside current ZIP: P1 original ZIP | `2407afbe5deedb42f86e1b65ec9be0aeb02b28e13192253d34e77df02142df7e` (read-first and outer manifest, not independent historic provenance) | `2407afbe5deedb42f86e1b65ec9be0aeb02b28e13192253d34e77df02142df7e` | PASS / 22 entries | PASS / 20 entries | PASS / 20 entries | **MATCH TO DECLARED HASH** |
| Parent historic handoff | `735d9f0ce2b97d2b1543fb6a7a5d9a839b2ada30cb5a41e732f1115725d30160` | **NOT_AVAILABLE** | N/A | N/A | N/A | **NOT_VERIFIED** |

The current sender-provided outer expected value was independent of uploaded file; comparing it validates byte equality to that stated expected value, **not authorship or cryptographic signature**. The nested P1 reference digest is in uploaded handoff text/manifest; this gives package internal consistency, not an independently authenticated ancestry proof. Historical parent's original bytes were not attached and were not invented/reconstructed. P1 original `07_ARCHIVE_INPUT_VERIFICATION.json` describes previous R1/R11 nested ZIP verification and mentions that original R11 lacked a MANIFEST; **those original nested ZIP archives themselves are not embedded here**. Their prior SHA/CRC results are **IMPORTED REPORT CLAIMS / NOT INDEPENDENTLY REVERIFIED IN P1.1**. P1.1's nested P1 result contains reference *extracted files* rather than the originals.

## Independent source observations

- Exact Justice fixed Evidence HEAD: `c428041dfb5779b6b6dc8db7bf14928225a00373`. `fetch_commit` returns that commit SHA, source metadata and changed-file list; **it does not return the root tree object or recursive tree enumeration**.
- Pinned source `fetch_file` returned file contents/blob Git SHA at this exact ref for `.github/workflows/ci.yml`, `.github/workflows/release.yml`, `package.json`, `README.md`, `src/opencode-plugin.ts`, `src/runtime/opencode-adapter.ts`, `src/runtime/justice-tools.ts`, `src/runtime/doctor-cli.ts`, `src/runtime/linux-review-artifact-provider.ts`, `native/review-artifact-linux/src/lib.rs`, `src/index.ts`, `src/core/justice-plugin.ts`, `src/core/wisdom-persistence.ts` and added source files, alongside configs. Selected paths were fetched in full; some were fetched only in line windows for detailed substantiation. `01` records source identities and exact SHA for 28/28 prior anchor paths plus 5 newly identified paths; full file coverage beyond these was not proven.
- GitHub `fetch_file` on empty repository path, `src` directory and `.github/workflows` directory returned **directory-not-file errors**. Connector does not expose a recursive `get_tree` operation in current installed tool catalog. Web GitHub tree/API fetch failed; local sandbox has no network DNS access. No git checkout, archive download, Actions run, shell script from evidence, or live-host activity was substituted.
- `01` includes **28 freshly SHA-matched prior P1 anchors**, **5 additional source file anchors** and **17 explicit tree/external gaps**. It is **not** a complete Git tree. The 28/28 fresh SHA matches do not change that. Exact Git tree SHA, paths outside these anchors, Git links, symlinks, submodules and full module imports/exports are NOT_VERIFIED. No claim of having counted every repository file.
- P1 source baseline 74 rows and their first 18 columns were preserved *byte-for-value* by parser and output as first columns of the reconciled CSV. All 74 IDs kept in order, including statuses; new N-47..N-54 are additive, not proof the census is exhaustive. 22 OPEN Findings and 37 NOT_EXECUTED NC are preserved in the signed-off-free ledger in `05`; original detailed CSVs remain in verified input P1 archive.
- Real runtime state and external refs (Senpi `d56e6a260d9468418a39bc9120945cf98e06b840`; OmO `091728d274f20d62504b0b5e1edbc3970671dd8b`) were not fetched, installed, instrumented or executed. Host provenance, module loader, dynamic import execution, native ELF/FD and package t_use are NOT_VERIFIED.

## Evidence and negative proof boundaries

| Category | Result | Prohibited inference |
|---|---|---|
| Source lines at pinned commit | `VERIFIED_SOURCE` on explicitly re-fetched files | No claim of job/run/effect/digest enforcement |
| All Git objects at commit | `NOT_VERIFIED` | No claim no other workflows/scripts/consumers |
| Published registry and release tarballs | `NOT_VERIFIED` | No claim source==build==native==tarball==host bits |
| GitHub token/effective repo config/admin writes | `NOT_VERIFIED` | No claim YAML permissions exhaust powers |
| OmO/Senpi host origin H0/G1/G2 | `NOT_VERIFIED` | No promotion of Case A or unknown-tool |
| Strict C1-FULL all third-party consumers | `STRUCTURAL_CONFLICT (unconditional private-gateway interpretation)` | No silent reduction to C2 |
| PostgreSQL internal accept / issued-at revoke / external signed ACK | `NOT_VERIFIED` | No claim distributed transaction atomicity |
| P2/P3/P4 candidate IF | `NOT_FROZEN` | No implementation or formal Owner decision |

**Final provenance verdict:** Current outer and inner provided archive integrity PASS. Full Git tree closure, historical parent authenticity, actual runtime and third-party effect completeness NOT_VERIFIED. `NOT_EXHAUSTIVE / INTERFACE_FREEZE_STOP`. R11 UNAPPROVED, Task1 BLOCKED, B0/HOST NO RUN, Tasks2–14 NOT_AUTHORIZED.
