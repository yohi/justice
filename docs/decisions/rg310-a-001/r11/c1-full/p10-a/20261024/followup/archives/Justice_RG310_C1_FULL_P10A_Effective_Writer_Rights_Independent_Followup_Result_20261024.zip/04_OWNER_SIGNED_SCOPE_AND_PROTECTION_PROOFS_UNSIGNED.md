# Owner-signed scope & provider proof requests — unsigned, unapproved template

**NOT AN OWNER RECORD. NOT A SIGNATURE. NOT AN AUTHORIZATION.** This document is an independent investigator's **request**, no personal/secret token values, no privileged token identifiers, no new policy selection, no deployment permission. Blank slots are **intentionally unfilled**. The public PR #325 archive `3acee3f5edf00c373f0cf6bca8750c7682382bf1` explicitly contains `P10A_INDEPENDENT_RESULT_INTAKE.md` and `P10A_NEXT_EVIDENCE_REQUIREMENTS_UNSIGNED.md`, both **UNSIGNED**. The direct inspected directories/limited code-search returned no authenticated signed canonical scope; that is **NOT_VERIFIED**, not a global claim of nonexistence.

## O-01 Owner canonical original — request only

Request the independently verifiable **Owner-signed canonical protected-effect scope original**, not an AI-filled list. It must bind exact project/repo/package/Host populations, coverage of production release, pre-release, preview PR/checks, tag/branch, Release, asset, GitHub Packages version/delete/restore, Actions artifacts, Codecov/Sonar/SARIF, external integrations, and actual supported Host use, with explicit inclusion/exclusion, effect first-write boundaries, exception authority, effective date/expiry, digest and signature-verification chain. Supply DS-01..06 historical signed originals (if existent) or explicitly mark `MISSING / NOT_VERIFIED`; do not infer authority from research files.

Unsigned unfilled record template:

```text
DOCUMENT_CLASS: OWNER_CANONICAL_SCOPE_REQUEST_ONLY
owner_signed_original_uri: [NOT_PROVIDED]
verifiable_signature_or_authority_attestation: [NOT_PROVIDED]
original_sha256: [NOT_PROVIDED]
protected_resources_and_effects: [NOT_SELECTED]
preview_vs_certified_release_classification: [NOT_SELECTED]
C1_FULL_Host_population_and_offline_obligation: [NOT_SELECTED]
DS_01_TO_06_AUTHORITY: FORMAL_PENDING
validity_interval_and_revision_rules: [NOT_PROVIDED]
independent_custodian_verification: [NOT_PERFORMED]
```

## O-02 Branch/tag policy and bypass – provider GET evidence needed

Request a **privileged read-only** time-stamped provider export, with actor's observation role, of repo **all paginated rulesets** (branch, tag, push, repository; parent semantics if applicable), exact ref-name conditions, active/evaluate/disabled states, bypass/exempt user/App/role/deploy-key categories, branch classic protection, tag rules, PR review/check enforcement, release immutability policies, and confirmation of what grant allows a direct mutation for each endpoint. Distinguish provider 403, connector 400, indexed search empty and provider 404. Recheck with an independently authorized observer; **no changes**.

## O-03 GitHub principals and alternate ingress – non-secret aggregate

Request Owner-/provider-confirmed **counted classes and effective permissions** for repository owner/collaborators, Apps/installations, classic PAT classes, fine-grained PAT where applicable to GitHub APIs, SSH deploy keys and `allow write` flags, bots, manual/emergency maintainers, GitHub App delegation and alternate git/ref/Release/asset endpoints. Do not include token material, real PAT strings, private keys, secret contents, or unnecessary individual identity details. Report unknown and missing readers explicitly; a public contributor list is not a complete authenticated writer census.

## O-04 Actions and external producer rights – effective-run snapshots

Request `GITHUB_TOKEN` **effective job-level** permissions at execution time, workflow/repository defaults, fork-run restrictions, environment gate configurations, reusable workflow caller/callee inheritance, workflow dispatch/re-run actor controls, release-please token delegation, uploader privileges, and external Codecov/SonarCloud/Semgrep/Snyk/third-party CI publisher grants. Provide sanitized provider snapshots and bound run IDs/times, not tokens. Six pinned workflow YAMLs prove possible paths, not effective runtime grants.

## O-05 GitHub Packages `@yohi/justice` – package-specific owner proof

Request timestamped package object existence/visibility, package-owner `admin/write/read` role **categories**, repo access inheritance vs granular override, `Manage Actions access` connected repos and exact permission, classic PAT `write:packages` and `delete:packages` viable actor categories, `GITHUB_TOKEN` write/admin/delete/restore scope and subject, package versions / delete / restore / alternate manual publish endpoint scope, and readback/protection at the package's actual registry. GitHub Packages, **not npmjs.com**; do not transfer trusted-publisher policy. Package REST GET was connector-side 400, not 404. No publish/delete test.

## O-06 GitHub Release/ref/asset first-effect prohibition

Request non-secret effective **prewrite** denial and immutable-release setting at relevant **future** release creation, scope of protected tag refs, full direct REST/GraphQL and web-interface actors, asset add/replace/delete semantics, and Release state transition invariants. Provide an authenticated provider audit for exact actions and time. Historical v4.3.1 `immutable:false`, published Oct 4 with distinct asset uploaded 20 seconds later, is not v5 evidence. The Release-please step precedes pack verification, so any pack-only veto is causally insufficient.

## O-07 Old-primary write fencing / independent issuer

Request Owner-custodied **non-secret** audit of retired Primary/App/PAT/runner credential classes and provider-ACK revocation effective times, any outstanding pre-issued scoped grants, old writer re-election/backup restore possibility, issuer `ISSUE` versus fence-effective ordering and blackout, replay/duplicate output policy and independent fencing observer. Physical old-principal prevention must cover all requested remote effects, not only DB state or signer epoch. No credential revocation, issuance, refresh, login, permission change or test authorized here. P10-C separate.

## Response checklist (not consent)

| Req | Provider-origin signed/privileged proof acquired? | This investigation |
|---|---|---|
| O-01 | NO | **NOT_VERIFIED**; searched bounded PR head tree / public index, unsigned archive only |
| O-02 | PARTIAL | Branch `protected:false`; disabled rule; tag-filter visible empty; classic protection 403 |
| O-03 | NO | Collaborators, keys, installation GETs rejected connector-side 400 |
| O-04 | PARTIAL_SOURCE_ONLY | Workflow YAMLs and job metadata; token/environment/reusable settings not enumerated |
| O-05 | NO | Package ACL/list read blocked connector-side 400 |
| O-06 | PARTIAL_HISTORIC_ONLY | Source order, old v4 Release and asset; no v5 prior-write denial |
| O-07 | NO | No independent physical fence/revocation evidence |

All blanks remain unsigned. No Owner decision, Gate approval, new grant, adoption, implementation, release, CI/Host run, PR merge or schema freeze has been performed.
