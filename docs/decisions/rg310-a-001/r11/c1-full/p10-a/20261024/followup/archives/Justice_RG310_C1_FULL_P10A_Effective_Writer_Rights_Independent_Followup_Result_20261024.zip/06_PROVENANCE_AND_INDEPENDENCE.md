# Justice RG-310-A-001 — Independent read-only provenance, integrity and stop record

**Date** 2026-10-24 JST; acquisition 07:59–08:03 UTC, using connected GitHub `fetch` GET-only resources where allowed. Investigator distinct from source artifact author, prior reviewer, Owner and formal Gate by role: no signature, no approval, no write execution. This record provides **independent acquisition/method**, not an independently attested custodial identity or proof of collaborator/access rights. No remote request other than GET; no source-embedded scripts executed. Original ZIPs treated as static untrusted data.

## 1. Byte-level integrity tested independently

| Layer | Independent result |
|---|---|
| Outside supplied Handoff | `bf9464a9e55d20ecc73b1f6eb5e35b11dea12a54e01bf9ac86b07de20b4e4881`, **MATCH separately stated expectation**; **51,354 bytes**; ZIP CRC **6/6 PASS**; SHA256SUMS **4/4**; MANIFEST **4/4** |
| `00_READ_FIRST.md` / `01_WORK_CONTRACT.md` | Both read in full; SHA manifest and SHA256SUMS independently verified; no execution |
| P10-A original result | `41d83cf7b8223a47721191372922e76d50e6c374b3804713de26f3863e6870ee`, **24,004 bytes**; CRC **11/11**, SHA256SUMS **9/9**, MANIFEST **9/9** (uses **`name`**, not `path`) |
| P9 original result | `f0efb114aaf04a3ced9da45a6b40ca698b2fe6e275afbed61e46a198e02073b0`, **24,044 bytes**; CRC **8/8**, SHA256SUMS **6/6**, MANIFEST **6/6** |
| Historical unreproduced originals | P9 input handoff `512887fb…`, P6 sibling supplement `55c8756…`, ancestor `735d9f0ce2b97d2b1543fb6a7a5d9a839b2ada30cb5a41e732f1115725d30160`: **NOT_VERIFIED**, not supplied recursively |
| P10-A original *input* Handoff `ad45d3c1dce465c8a303cdf72f156f452cbc6465a8c4b9a40731a8962b59508e` | Original P10-A input Handoff **not attached to this follow-up**; P10-A report's historical claim, not independently rehashed here |

These results establish byte-level reproducibility of the supplied outer and the **two nested result ZIPs only**. They do not establish source author's authority, version 5 Gate or protection behavior. New result archive contents are independently checksummed in `SHA256SUMS`/`MANIFEST.json` with self-exclusion; outer result ZIP SHA is reported separately.

## 2. Source, provider and role strata

- **Fixed Task1 evidence HEAD** `c428041dfb5779b6b6dc8db7bf14928225a00373` (source code only); **approved v5 R/D/P** `8a2e4f1536e9cad499ee7e9d996ff163df132fd4` (normative baseline not amended). Fixed `release.yml` git blob `4f984a012f3fa9421a32531a00394f4d654d5284` retained from originals; its plaintext was freshly fetched, SHA256 `ac3542c27f1c63b5bac4025a3b233650447337390b1db5651e62d1657ae00337`. Source SHA captures also present for all other five YAMLs in acquisition log.
- **Current `master` observation** `0a7fa07e2aad63ebd28b403876773d2f0c831e82`; this differs from the fixed Task1 evidence and archive PR #325 head. Do not splice source/config epochs.
- **PR #325** read fresh: `draft:true`, `state:open`, `merged:false`, head `3acee3f5edf00c373f0cf6bca8750c7682382bf1`. At that PR head, P10-A original intake and next evidence document are explicitly **UNSIGNED**, not an authenticated Owner-signed scope. Master contents API on that optional `docs/decisions/...` path returned provider 404; the same subtree was observed on the PR head. Hence **404 is branch/ref/scope-specific**, not global absence.
- **Current visible GET rules** repo master `protected:false`, ruleset #14286365 disabled on default branch, bypass_actors [] for that disabled ruleset; page2 empty. Tag-filtered rulesets page1/2 empty in this view, not a provider-wide no-tag-protection proof. Exact branch protection GET **provider 403**. App/collaborator/deploy key/workflow permissions/packages REST paths **connector 400** allowlist restriction; these cannot be used as negative existence evidence.
- **Provider-visible historical effects** Actions `justice-dist` ID `12478096629` on run `39898374188` created `2026-10-23T04:09:40Z` digest `sha256:855feb61b8052c49d3a74e940a3017efaf91815964ad04859c6a1769a1baa38b`; `coverage-report` ID `12477667915` run `39898374191` created `2026-10-23T04:05:41Z` digest `sha256:ad2aead50be03bfa725d7e1d6bee278455150fa5e75cd730c251cf3025933f44`. External Codecov/SonarCloud and GitHub SARIF **job steps** successful; no independent remote acceptance object read for these providers.
- **Historical v4 Release** v4.3.1 ID403154810 published `2026-10-04T18:38:12Z`, `immutable:false`; asset ID610397097 created `18:38:32Z`, digest `sha256:87b6aec445317c0f39335fdc34a7de5baef528898c39eaf89c98c7b0199dbf61`. These historical object facts cannot become a v5 acceptance or direct-delete denial proof.

## 3. Acquisition hygiene and interpretive limits

All new successful response hashes in `01_EVIDENCE_ACQUISITION_AND_API_SCOPE_LOG.csv` are SHA-256 of the **exact UTF-8 connector `result.content`**, computed using an independent in-tool SHA-256 implementation and checked against the `abc` standard vector. They are **not** cryptographic hashes of HTTP wire bytes, transport headers or independently signed provider responses. For errors no response body was obtained or hashed. Eight later directory/archival reads lack exact payload hash and are explicitly marked `GET_SUCCESS_NOT_HASHED`; T1 and T7 timestamps are not asserted to exact subsecond bounds. T2–T5 acquisition batches use explicit start/end windows. No false hash or invented observation time is silently filled.

The original 24 P10-A log rows have been preserved **as untrusted earlier reported observations** in the CSV; new follow-up reads have distinct `FU-` IDs. The original 32 actor/effect records are preserved in `02_...csv` with conservative outcome columns. The 16 `CE-` negative oracles, eight P10-A independent findings, and P9 22 documentary writer candidates are preserved in `05_...csv`. P9 candidates are **not P9 formal Gate findings**; the original 22 Justice findings remain OPEN, separately.

A search of public, currently indexed code for a few precise strings returned zero results; this is **not** proof of no unsigned/signed scope in other branches, unindexed files, private custodial systems, or Owner originals. No P10-A-Finding or O-01..07 has been upgraded to global all-path effective rights closure. No observer accessible in this investigation was independently proven privileged to read all Apps, PAT rights, emergency writers, tag protection, GitHub Packages ACL and old-primary physical fences.

## 4. P9/P10-A baseline preservation

- Prior **P9**: `NEGATIVE_BOUNDED_CONTRACT_ASSESSMENT / NO_POSITIVE_A_OR_B_GO`; 22 P9 writer path candidates not proven distinct real writers; P6A/B and other historical reviewed hypotheses not elevated.
- **P10-A F01..08**: eight independent research findings unchanged. `F01` specifically **DISPROVES** late pack checker as prior barrier for earlier potentially protected release-please PR/tag/Release writes; it does not demonstrate unauthorized remote mutation or absence of a different provider veto. F02–F08 retain bounded observation, blocked and non-proof statuses.
- 24 evidence log observations, 32 inventory candidate rows, 16 **not executed** counterexamples held without code execution, dynamic probes or positive gate closure.
- `COMPLETE_MEDIATION_NOT_PROVEN`, `ALL_EFFECTIVE_WRITERS_CENSUS_NOT_PROVEN`, `REMOTE_PRIOR_DENIAL_NOT_PROVEN`, `OLD_PRIMARY_FENCING_NOT_PROVEN`, `H0..H3_NOT_PROVEN`.

## 5. Mandatory authority, formal Gate and implementation STOP

**Architecture A:** `NO_GO_FOR_OBSERVED_SPLIT_DOMAINS` (does not prove universal infeasibility). **B:** `NOT_SELECTED` (paper research only); **C1-FULL** remains the requested research direction, not a signed effect denominator or retroactive all-host constraint. **R11:** `UNAPPROVED`; **R′/D′/P′:** `NOT_ADOPTED`; **DS-01..06:** `FORMAL_PENDING`. **Task1:** `BLOCKED`, prior `31/32 PROVEN` (Case A BLOCKED, Case B PROVEN, unknown-tool BLOCKED); previous **22 original findings OPEN**, `NC37 NOT_EXECUTED`; `H0–H3 NOT_PROVEN`; **Tasks2–14 NOT_AUTHORIZED**; **P2/P3/P4 INTERFACE_FREEZE_STOP**. No Owner decision or formal acceptance.

**No actions executed:** no write method; no PR merges, GitHub/package/policy/secret changes, token retrieval, Actions dispatch/Host/DB/cloud tests, package publish, ref/tag/Release effect, package pull that might leak credentials, schema freeze or live policy probe.
