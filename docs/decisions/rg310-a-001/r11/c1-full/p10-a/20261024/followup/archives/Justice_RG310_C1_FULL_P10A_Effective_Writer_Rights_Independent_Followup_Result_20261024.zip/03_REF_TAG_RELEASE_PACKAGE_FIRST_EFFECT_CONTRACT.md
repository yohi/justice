# Justice RG-310-A-001 — First-effect authority contract (research-only / unsigned)

**As observed:** 2026-10-24 08:00–08:03 UTC; fixed source commit `c428041dfb5779b6b6dc8db7bf14928225a00373`, not master HEAD `0a7fa07e2aad63ebd28b403876773d2f0c831e82`.  
**Status:** `NO_POSITIVE_A_OR_B_GO / COMPLETE_MEDIATION_NOT_PROVEN`. This is a falsifiable paper contract, **not** approved R′, schema freeze, implementation specification, Owner authorization or live policy change.

## 1. Observation, authority and proof are separate layers

`source_workflow_declares_write` is not `token_received_effective_grant`, and neither is `provider_prewrite_denial_all_alternates`. A GET snapshot is not a continuously enforced condition. Valid closure for each first remote write would require an authenticated Owner-selected *protected effect* and time interval, all independent first-write ingress endpoints, the complete effective writer/credential population, active rules matching the exact resource, the full bypass and exception set, a non-bypassable provider-side refusal occurring **before** the write under unapproved conditions, and an independently observed causal trace. No such conjunction is established here.

The Owner-signed protected-effect population is missing. PR/preview/CI/check/status, security coverage, package publication, public release and supported Host use may be materially different protection classes. **Do not silently collapse these into an invented complete denominator or silently exclude any.** Owner's C1-FULL direction is a requested research scope, not signed DS-02 or a universal offline-host mandate.

## 2. Fixed source ordering, with direct first effects separated

At fixed `.github/workflows/release.yml` (Git blob `4f984a012f3fa9421a32531a00394f4d654d5284`, re-fetched plaintext SHA-256 `ac3542c27f1c63b5bac4025a3b233650447337390b1db5651e62d1657ae00337`): push to `master` triggers a workflow **declaring** `contents:write`, `pull-requests:write` and `packages:write`; step 1 invokes `googleapis/release-please-action` (`@45996ed...`), followed on `release_created` by checkout, native build/check, build artifact, `npm pack --dry-run` verification, `npm publish --ignore-scripts` to GitHub Packages with `NODE_AUTH_TOKEN` referencing `secrets.GITHUB_TOKEN`, and finally `gh release upload` with `GITHUB_TOKEN` reference. No credentials were read. Release-please's potential PR/tag/Release effects **precede** any later pack/check gate.

**Counterexample CE-01, narrow and decisive:** A later successful or failing `npm pack --dry-run`, downstream job, or post-publish packaging check cannot be the universal causally prior veto of *earlier* release-please PR/tag/Release changes, **if those earlier effects are protected**. That claimed gate placement is `DISPROVEN`. An unobserved independent provider control may still prevent writes. No actual unauthorized tag, Release, PR, package or asset mutation was demonstrated.

| Candidate protected first effect (Owner classification pending) | Potential writer / ingress, not authenticated as exclusive | Required **before** effect | Observed bounded fact / persistent blocker |
|---|---|---|---|
| Release PR create/update | release-please or direct App/PAT/human -> PR API | effective actor-specific PR permission + trusted prewrite grant/provider denial | workflow order verified; collaborator/App/PAT census blocked; signed scope absent |
| `refs/tags/v*` create, force-update, delete | release-please, git push, REST/GraphQL, deploy key, old bot | active matching tag rule/protection; effective rights and all bypass classes; denial before ref update | 21 visible historical tag refs; tag-ruleset filtered page1/2 empty in observer view; NOT universal no-rule evidence |
| GitHub Release create/publish/edit/delete | release-please, human, App/PAT, other CI | Release API's exact operations controlled before effect; immutable policy time validity where applicable | historical v4.3.1 `immutable:false` (ID403154810), not current/v5 gate |
| GitHub Release asset upload/update/delete | `gh release upload`, direct REST/GraphQL/API clients | separate API endpoint's prior refusal, actor/asset policy, readback | historical v4.3.1 asset 610397097 separately created 20s after release publication; no v5 prior denial |
| GitHub Packages `@yohi/justice` version publish / delete / restore | workflow npm, classic PAT package owner/manual, permitted other repo actions | independent package ACL; linked repo inheritance check; per-package effective write/admin/delete, token and rights census | fixed `package.json` registry `https://npm.pkg.github.com`; package GET denied by connector allowlist; rights unknown |
| CI/release `justice-dist` & coverage artifact | Actions runner artifact-upload service | Owner first decides whether protected; run-scoped admission before upload; cancellation/re-run authority | `justice-dist` 12478096629 and `coverage-report` 12477667915 provider-visible in 2026-10-23 CI runs; not release acceptance evidence |
| SARIF Code Scanning upload | Semgrep/Snyk jobs, security-events writer, other uploader | GitHub Code Scanning effective uploader scopes plus trusted prior denial | action step success observed, not remote SARIF object proof |
| Codecov/Sonar/check status | external scanner token/App/CI/status REST writers | per-provider uploader/PR-status permissions, cryptographic principal and causal policy | step success only; external service provider objects/settings not independently acquired |
| supported Host actual loaded JS and native `.node` | trusted/unmanaged Host loader/retained offline copies | signed scope + actual at-use mapped bytes/origin and physical custody | P10-D H0–H3 `NOT_PROVEN`; package, artifact and path hashes insufficient |
| retired Primary / cached independent token | old admin/App/PAT/runner/signature grant candidate | issuer revocation and effective provider-side fencing, durable epoch/blackout, no replay/re-election | no old-principal census or issuer-to-provider fence evidence; P10-C pending |

`FW-05` local pack is not a remote first effect. `FW-20..22` are policy/run metadata, not writers. `FW-19` is conditional on authenticated Host population. X01–X10 are possible *not observed* alternative channels, and **32 candidates do not equal 32 proven effective writers**.

## 3. Ruleset / branch / tag policy evidence and negative inference guards

- `GET /repos/yohi/justice/branches/master`: `protected:false` at the recheck; this only describes that API field. The fixed source commit and current master must not be conflated.
- `GET /repos/yohi/justice/rulesets?includes_parents=true&per_page=100&page=1` shows one branch ruleset `14286365`; `page=2` empty. Its `enforcement:disabled`, ref `~DEFAULT_BRANCH`, deletion/non-fast-forward, empty visible `bypass_actors` and `current_user_can_bypass:never` **cannot be an operative veto while disabled**. The empty bypass list pertains to this specific *disabled* ruleset, not every admin/App/token/package effect.
- A GET with `targets=tag` returned `[]` on pages 1/2; not all security restrictions, branch classic protections, tag policies, undisclosed rules or end-user effective rights are globally ruled out by this limited authenticated view.
- `GET .../branches/master/protection` returned **provider 403 Resource not accessible by integration**. `GET .../rules/branches/master`, `GET .../actions/permissions`, package and installed-App/keys/collaborator enumeration returned **connector-side 400 disallowed GET family**. These are non-equivalent failure types and never positive absence evidence.
- Personal owner type `User` is observed; do not invent organization inheritance. Conversely do not infer that admin-manual, emergency, external integration or individual package access classes are absent.
- No all-path `allowlist` or complete bypass matrix exists in the acquired read scope. No operational attempts may be used to determine it here.

## 4. GitHub Packages is NOT npmjs.com trusted publishing

Pinned `@yohi/justice` targets `npm.pkg.github.com`; GitHub Docs says the npm registry has granular package permissions, classic-PAT publishing and in-workflow `GITHUB_TOKEN` channels. Packages can inherit linked repository access or be configured independently; Actions' admin package capabilities are separately relevant. **No inference from npmjs.com trusted-publisher, OIDC, token-disable or dist-tag policy may close GitHub Packages rights.** Generic public documentation describes possible authority categories, not `@yohi/justice` effective ACL or actual issued tokens.

Public docs (research-only):
- https://docs.github.com/en/packages/working-with-a-github-packages-registry/working-with-the-npm-registry
- https://docs.github.com/en/packages/learn-github-packages/about-permissions-for-github-packages
- https://docs.github.com/en/packages/learn-github-packages/configuring-a-packages-access-control-and-visibility
- https://docs.github.com/en/code-security/how-tos/secure-your-supply-chain/establish-provenance-and-integrity/prevent-release-changes

## 5. Explicit failure/STOP oracle

`ALLOW_FIRST_EFFECT` is **not established** when **any** of: scope unowned, credential/actor omitted, policy inaccessible/disabled/mismatched, bypass census incomplete, old writer fencing unknown, durable issuer ordering unknown, service-specific denial untested, retrospective-only check, Host mapped bytes unverified, or provider-object result ambiguous. The epistemic output is `NOT_PROVEN/BLOCKED`, not a claim that the live provider denied an attempted write. `DISPROVEN` applies *only* to proposed **later pack/check as prior gate for earlier release-please writes**.

No `A GO`, `B GO`, R11 adoption, schema/interface freeze, merge, release or Task authorization is implied. Architecture A is `NO_GO_FOR_OBSERVED_SPLIT_DOMAINS` (not universal logical impossibility); B `NOT_SELECTED`; R11 `UNAPPROVED`; DS01–06 `FORMAL_PENDING`; Task1 `BLOCKED`; Tasks2–14 `NOT_AUTHORIZED`.
