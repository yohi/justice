# Candidate P10-A — Independent read-only result package

Created from directly verified outer handoff ZIP (SHA-256 `ad45d3c1dce465c8a303cdf72f156f452cbc6465a8c4b9a40731a8962b59508e`), without executing input programs or making service mutations.

Files:

- `00_INTEGRITY_VERIFICATION.json`: outer and nested integrity facts.
- `01_P10A_INDEPENDENT_INVESTIGATION_REPORT.md`: finding / bounded verdict.
- `02_TIMESTAMPED_EVIDENCE_ACQUISITION_LOG.csv`: 24 independently acquired records with read-view / timestamps / provider refs and limits.
- `03_ACTOR_EFFECT_CREDENTIAL_INVENTORY.csv`: **32** candidacies (=22 P9 + 10 hypothetical) explicitly distinguish writer vs local vs metadata.
- `04_PER_EFFECT_COMPLETE_MEDIATION_MATRIX.csv`: 32 unclosed mediation cells.
- `05_BOUNDED_COUNTEREXAMPLE_ASSESSMENT.csv`: 16 negative oracles, explicitly no write probes.
- `06_OWNER_NON_SECRET_EVIDENCE_REQUESTS.md`: non-secret evidence requests.
- `07_SEPARATELY_AUTHORIZED_DYNAMIC_TEST_CANDIDATES.md`: unexecuted experimental proposals.
- `MANIFEST.json`, `SHA256SUMS`: generated package integrity (excludes own checksums).

Verdict: `P10A_BOUNDED_READ_ONLY_NEGATIVE_OR_UNRESOLVED / COMPLETE_MEDIATION_NOT_PROVEN / NO_POSITIVE_A_OR_B_GO`.
