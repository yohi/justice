# Separately authorized dynamic validation candidates — NOT EXECUTED / NOT AUTHORIZED

These are **design candidates** and are forbidden under the current P10-A read-only contract. Approval must be separately authenticated by Owner and independently risk assessed; use disposable/isolated repositories, domains, package namespaces, and credentials that cannot affect production.

| ID | Intended future falsification | Safe isolation prerequisite | Current status |
|---|---|---|---|
| D-01 | Direct tag/Release/asset mutation with deliberately unauthorized synthetic App/PAT | Throwaway repo and trusted denial instrumentation | NOT_AUTHORIZED |
| D-02 | First GitHub release-please tag/PR creation vs downstream verifier ordering | Throwaway Actions repo/workflow and tracing; no production token | NOT_AUTHORIZED |
| D-03 | Token/manual/Actions registry publisher parallel channel | Temporary private test package with documented package permissions | NOT_AUTHORIZED |
| D-04 | Revoke old primary and test physical provider-side fencing | Dedicated isolated principal and revoked disposable credential | NOT_AUTHORIZED |
| D-05 | Abort/timeout with partial GitHub Release and package publication | Synthetic mock provider first, actual test providers only separately approved | NOT_AUTHORIZED |
| D-06 | Code scanning/SARIF/coverage first-effect admission | Disposable PR and third-party sandbox | NOT_AUTHORIZED |
| D-07 | Release asset replacement and dist-tag change on separate API ingress | Test release/package with unimportant versions | NOT_AUTHORIZED |
| D-08 | Host loaded JS/native actual bytes vs package/archive digests | P10-D isolated Host safety contract | NOT_AUTHORIZED |

None of these experiments was run in this investigation. No derived runtime result should be implied.
