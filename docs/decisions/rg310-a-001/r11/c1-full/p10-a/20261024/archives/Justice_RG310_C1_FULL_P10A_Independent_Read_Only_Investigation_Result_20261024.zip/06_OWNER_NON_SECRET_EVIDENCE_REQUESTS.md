# Remaining read-only evidence requests (non-secret; Owner may provide signed originals)

| Request | What (sanitized read-only) | Closure requirement | Otherwise |
|---|---|---|---|
| O-01 | Authenticated signed original specifying exactly which protected effects are in-scope (certified release vs preview/PR/CI, host use, external reports) and DS-01..06 originals | Denominator definition | `NOT_PROVEN`, no scope selection by investigator |
| O-02 | Exact-time repository owner and repository/branch/tag ruleset listings; all pages/ETags and bypass actor **summary**, observer's read permissions; classic protection | Effective policy closure | `BLOCKED/NOT_VERIFIED` |
| O-03 | GitHub collaborator role classes, Apps installation granted permission classes, active write deploy keys, classic/fine-grained PAT *capability aggregates only*; no raw token IDs/values required | Principal and credential census | No total actor closure |
| O-04 | Actions default workflow tokens and escalation rules, `permissions` effective run contexts, protected environments, external CI integrations, reusable workflow delegation, workflow_dispatch status | Delegation closure | Inherited privileges unknown |
| O-05 | GitHub Packages npm `@yohi/justice` immutable package identity, package-level collaborators/Actions access, publish/delete/distribution-tag rights, evidence whether PAT/manual alternate publish is allowed | Registry distinct provider veto | No registry mediation proof |
| O-06 | GitHub release creation/edit/delete and asset replace/delete protection; immutable release policy in force for *target v5*; tag policy for `refs/tags/v*` | GitHub release/asset ingress veto | Historical mutable v4.3.1 remains metadata |
| O-07 | Old-primary and emergency actor capability revocation audit, provider-side physical disable time, non-secret issuer-to-principal mapping and source snapshots | Old writer closure | Stale writer remains hypothetical/unruled-out |
| O-08 | Pre-approved *isolated test plan only*, if needed after read-only exhaustion | Future denial-before-first-write runtime proof | Remain NOT_PROVEN; no execution here |

**Never submit raw secrets, tokens, keys, credentials, unredacted environment dumps, or live authentication cookies.** Keep authorized principal mappings in Owner-controlled custody. Redact before exporting any material; preserve original signed provenance under Owner controls. No request here is a permission to mutate or test a live system.
