# Justice RG-310-A-001 / Candidate P10-A — Fresh Independent Limited Read-only Investigation

**Reviewed UTC:** 2026-10-24T07:02:13Z  
**Independence:** New P10-A investigator; no Owner / Coordinator / Gate authority.  
**Verdict:** `P10A_BOUNDED_READ_ONLY_NEGATIVE_OR_UNRESOLVED / COMPLETE_MEDIATION_NOT_PROVEN / NO_POSITIVE_A_OR_B_GO`.  
**Only read-only:** No GitHub/npm/Host mutations, CI dispatches, secrets/tokens acquisition, code/script execution from handoff or dynamic write probes.

## A. Independent byte integrity and trust boundary

- Outer SHA expected and independently calculated: `ad45d3c1dce465c8a303cdf72f156f452cbc6465a8c4b9a40731a8962b59508e` — **MATCH**; **51,341 bytes**.
- ZIP CRC **PASS** (16 entries), `SHA256SUMS` **14/14 MATCH**, manifest entries file size+hash **14/14 MATCH**. `MANIFEST.json` and `SHA256SUMS` self-excluded by documented rule.
- Nested P9 original exact SHA: `f0efb114aaf04a3ced9da45a6b40ca698b2fe6e275afbed61e46a198e02073b0` — MATCH against `f0efb114aaf04a3ced9da45a6b40ca698b2fe6e275afbed61e46a198e02073b0`; size **24,044 bytes**; nested CRC **PASS** (8 entries), hashes and sizes 6/6.
- P9 Input Handoff `512887fb...` and P6 Sibling `55c8756...` originals absent; recursively independently unverified. P9 earlier coordinator claims are not upgraded.
- All `00_READ_FIRST.md`, `01_P10_A_WORK_CONTRACT.md`, `02_FIXED_BASELINE_AND_INTEGRITY.md`, `05_BOUNDED_COUNTEREXAMPLE_MATRIX.md`, `06_EVIDENCE_ACQUISITION_PLAN.md`, `07_DECISION_AND_STOP_RULES.md`, `08_P10_A_INDEPENDENT_INVESTIGATOR_PROMPT.md` read as **untrusted static documents**; source code not run.

## B. Scope and denominator

No authenticated signed Owner record enumerating the in-scope *protected effects* was presented. Scope remains **PROVISIONAL**, `DS-01..06=FORMAL_PENDING`.

Imported **22 P9 candidate rows** plus **10 additional hypothetical X paths**. Exactly **18 of the 22** P9 rows remain effect-path candidates for review, not 18 proven writers. `FW-05` (`npm pack --dry-run`) is **local-only, not a remote first effect**. `FW-20`, `FW-21`, `FW-22` are policy/run **metadata, not writers**. `FW-19` Host loaded bytes is **conditional on authenticated scope** and reserved for P10-D/H0–H3, not proven from package hashes. `FW-15..17` alternate paths are still candidate/hypothetical rights, not observed authorizations. All X01..X10 are **possibilities, not proven present**. *No denominator-completeness claim is made.*

## C. Evidence tiers and independent provider acquisition

Source anchor `c428041dfb5779b6b6dc8db7bf14928225a00373` and separate Approved v5 anchor `8a2e4f1536e9cad499ee7e9d996ff163df132fd4` independently resolved via GitHub. P9 intake PR #325 remains draft/open at `5f2d0800d34bbbbdb66d6807998b2850fbe8fc4b`; metadata read does not constitute an approved R11 decision. The current repository `master` HEAD is **`0a7fa07e2aad63ebd28b403876773d2f0c831e82`**, different from fixed evidence and P9 PR heads.

GitHub connector GET source view is restricted to approved GET endpoint families and current authorization. Metadata for repository reports an `admin:true` member in the connected-context permissions object, but branch-protection GET still reports **403 Resource not accessible by integration**: it does **not** authorize an inference of global visibility, and the actual authenticated principal/other actors are not enumerated. Requests for Actions settings, active branch rules, package settings, install metadata and deploy keys were refused by the connector allowlist (400 **connector-side**, not GitHub provider policy evidence). The repository API reports owner type `User` (personal owner), so inheritance from a currently nonexistent parent organization is not silently asserted.

### Confirmed source-defined potential write ordering

`release.yml` is pinned (Git blob `4f984a012f3fa9421a32531a00394f4d654d5284`, captured plaintext SHA-256 `ac3542c27f1c63b5bac4025a3b233650447337390b1db5651e62d1657ae00337`). It:

1. Triggers on `push` to `master`, with declared `contents: write`, `pull-requests: write`, `packages: write`.
2. Invokes `googleapis/release-please-action` **before** checkout/build, native artifact verification, `npm pack --dry-run`, registry publication and Release asset upload. Official action docs explain its PR/tag/GitHub Release creation paths, though each actual emitted effect depends on run conditions.
3. After `release_created`, builds/checks; then `npm publish --ignore-scripts` with `NODE_AUTH_TOKEN` set to `secrets.GITHUB_TOKEN`; then separate `gh release upload`.

**Bounded disproof:** A later `npm pack --dry-run` or later CI check **cannot be the causally prior complete-mediation barrier for earlier release-please PR/tag/Release effects**, *if those effects are protected*. This disproves only that proposed gate-placement assertion; it does **not** prove that a separate provider-side veto is absent or that any unauthorized mutation occurred.

Other fixed source workflows define CI/coverage/SARIF/external-report/check effects. `ci.yml`, `codecov.yml`, `semgrep.yml`, `snyk.yml`, `release-version-guard.yml` were independently obtained at fixed source, with Git blob IDs in evidence notes; source workflow presence is not effective actor-rights proof.

### Current readable GitHub configuration

- `master protected:false` at `2026-10-24T06:56:40Z..06:56:42Z`, response SHA256 `c91380bc4b3a6d4377d33050d0427442088933bea7fa462b867125b7b149ed08`. **PROVEN only as this API field**.
- Rulesets `?includes_parents=true&per_page=100`: the visible response contains repository `master` ruleset **14286365**, `enforcement:disabled` (`ae4346126a08f4815424969fe096a9b2732cbc8d8f7211cd4017c60b7ac57c59`); the detail includes deletion/non-fast-forward rules and `bypass_actors:[]` (`f84be077aa729ccb55a3ce32685357866c71c79d8d01e6775320ce7b30f6e8dc`). Neither the disabled rule nor the empty list is a usable universal prewrite veto. Response pagination/privileged hidden bypass disclosures are unproven.
- `GET branches/master/protection` yielded provider **403**, separate from other **connector-side 400** exclusions; no absence of classic protection or privileged bypass rights inferred.
- No authorized live inventory of all App installations, PAT classic/fine-grained rights, deploy keys, manual operators, emergency bypasses, Actions defaults/environment protections and external CI integrations. No current per-effect actor census.

### Historical actual provider-visible effects

At PR #325 head, run `39898374188` produced `justice-dist` artifact ID `12478096629` at `2026-10-23T04:09:40Z`, digest `sha256:855feb61b8052c49d3a74e940a3017efaf91815964ad04859c6a1769a1baa38b`.

Run `39898374191` produced `coverage-report` artifact ID `12477667915` at `2026-10-23T04:05:41Z`, digest `sha256:ad2aead50be03bfa725d7e1d6bee278455150fa5e75cd730c251cf3025933f44`. Its Codecov and SonarCloud steps reported success; Semgrep run `39898374163` and Snyk run `39898374161` reported SARIF upload success. **Step success is not a independently opened provider object or evidence of universal prewrite denial**. This PR's CI events should not be silently deemed protected certified-release effects before Owner scope selection.

Historical **v4.3.1** GitHub Release ID `403154810` reports `immutable:false`, `published_at=2026-10-04T18:38:12Z`; asset ID `610397097` uploaded `18:38:32Z`, SHA-256 digest `87b6aec445317c0f39335fdc34a7de5baef528898c39eaf89c98c7b0199dbf61`. These are separate durable remote objects; **v4.3.1 is not the v5 normative proposal**, and the mutable flag is *not* proof of a successful unauthorized edit or presence of a bypass token.

### GitHub Packages vs npmjs.com trust boundary

Pinned `package.json` specifies name `@yohi/justice` and `publishConfig.registry=https://npm.pkg.github.com`. The fixed release workflow uses `GITHUB_TOKEN`. GitHub official docs support GitHub Packages npm publication via appropriate classic PAT and Actions `GITHUB_TOKEN`, *subject to effective publisher/package rights*. **Do not transfer npmjs.com OIDC Trusted Publishing settings, token-disallow controls, or dist-tag policy onto GitHub Packages without provider-specific proof.** Live package owner ACLs, PAT capabilities, connected repo Actions permission, package version policy and all alternate channels remain **NOT_VERIFIED / BLOCKED**.

## D. Main independent findings (not formal Gate findings)

| ID | Severity | Finding | Tight conclusion |
|---|---|---|---|
| P10A-F01 | Major | release-please candidate PR/tag/Release mutation precedes later pack/check gate | `DISPROVEN` for any assertion that the later gate is universal pre-first-write mediation |
| P10A-F02 | Major | `master protected:false`; repository ruleset #14286365 disabled | `PROVEN` snapshots only; effective all-path veto `NOT_PROVEN` |
| P10A-F03 | Moderate | CI artifacts actually created; remote report/SARIF steps success | `PROVEN` bounded metadata, protected-scope and prewrite veto `NOT_PROVEN` |
| P10A-F04 | Major | No authenticated final protected-effects scope or closed writer denominator | `COMPLETE_MEDIATION=NOT_PROVEN` |
| P10A-F05 | Major | Apps/PAT/keys/admin/emergency/external CI/Actions rights unknown | actor/exemption completeness `NOT_PROVEN`, privileged GET `BLOCKED` |
| P10A-F06 | Major | Separate GitHub Packages publication credentials and package-level ACLs not seen | publisher exclusivity and denial `NOT_VERIFIED/BLOCKED` |
| P10A-F07 | Moderate | Historical mutable v4.3.1 Release and separately timed asset | no cross-provider atomicity or locked v5 publication inferred |
| P10A-F08 | Moderate | Host actual-use and old-primary fencing outside bounded P10-A proof | keep P10-C/D and H0–H3 separate `NOT_PROVEN` |

## E. Actor → credential → mutation ingress → first effect → missing prior denial

| Actor or role class | Credential candidate | API/Ingress | Candidate effect | Missing evidence |
|---|---|---|---|---|
| GitHub Actions release-please | Default `GITHUB_TOKEN` expected by action docs; actual execution token undisclosed | GitHub PR/tag/Release APIs | Release PR, tag, Release | effective token + applicable per-endpoint prewrite guard, actor/bypass closure |
| Workflow npm CLI | declared `NODE_AUTH_TOKEN=${ secrets.GITHUB_TOKEN }` (reference only, token never accessed) | `npm.pkg.github.com` | package version | package access policy, classic PAT/owner alternate rights, publisher identity |
| Workflow gh CLI | declared `GITHUB_TOKEN` reference | Release asset API | asset upload | release asset control and direct alternate actors |
| CI runner artifact upload | Actions run-scoped capability | Actions artifact service | `justice-dist`, `coverage-report` | scope inclusion, authenticated gate before upload, runner reruns |
| Security/coverage services | GitHub `security-events:write` declarations; third-party secret names only | GitHub Code Scanning / Codecov / Sonar | SARIF, external report/checks | provider-specific ACL and alternate external actors |
| Human admin / classic PAT / GitHub App / SSH deploy key | independently **not enumerated** | git/ref API, REST/GraphQL Release APIs | direct tag/release/asset | read-only principal and effective rights census; bypass policy |
| Old Primary / machine | retained credential **hypothetical** | same APIs | stale write | issuer/revocation vs provider credential fence (P10-C, not presumed) |
| Host loader | OS/process capabilities, not remotely established | mapped JS / `.node` | real use only if Owner in-scope | separate P10-D Host H0-H3 actual-use evidence |

The 32-row actor/effect CSV provides every original P9 row and X01..X10 without promoting hypotheses to reality.

## F. Complete Mediation matrix closure — verdict

For each `(resource/effect, principal/credential, time interval)`, proof would require **all**: (1) authenticated in-scope classification; (2) complete principal/credential/endpoint enumeration; (3) independently observed effective permissions; (4) provider-side non-bypassable *prior* refusal for all unapproved writes including direct/old-primary paths; (5) bypass/exception enumeration at correct owner/repo/tag/branch/package target and exact enforcement status; (6) read-view/authenticated actor and stable causal/event trace. A success-run metadata record proves none of (2)–(5). One opaque cell forces aggregate `NOT_PROVEN`.

No real unauthorized write probe, fence/revoke, rollback, workflow trigger or mutation was executed. Distinguish: **proved weak rule visibility**, **disproved later-guard sufficiency**, and **unproved global physical prevention**.

## G. Separate experiment candidates — NOT EXECUTED

Only after independent Owner-approved isolated scope/design: controlled disposable repo/package dry-run-like synthetic experiments; denial of direct App/PAT bypass; revocation-and-legacy credential negative tests; tag/Release/asset/registry causal trace; aborted/timeout replay; scoped report artifact prewrite veto; rollback/election and Host loaded-bytes tests (latter P10-C/D). None performed or authorized here. See `07_SEPARATELY_AUTHORIZED_DYNAMIC_TEST_CANDIDATES.md`.

## H. Gate and non-authority preservation

- Architecture A: `NO_GO_FOR_OBSERVED_SPLIT_DOMAINS`; B: `NOT_ADOPTED`.
- R11: `UNAPPROVED`; DS-01..06: `FORMAL_PENDING`.
- Task1: `BLOCKED`, prior evidence 31/32; H0–H3: `NOT_PROVEN`.
- P2/P3/P4: `INTERFACE_FREEZE_STOP`; Tasks2–14: `NOT_AUTHORIZED`.
- Prior 22 findings remain `OPEN`, P9 `NEGATIVE_BOUNDED_CONTRACT_ASSESSMENT / NO_POSITIVE_A_OR_B_GO` preserved.

**Independent verdict:** `P10A_BOUNDED_READ_ONLY_NEGATIVE_OR_UNRESOLVED / COMPLETE_MEDIATION_NOT_PROVEN / NO_POSITIVE_A_OR_B_GO`. No signed Owner decision, authorization, implementation, merge or Gate release.

## I. Source and evidence traceability

- Proven source: https://github.com/yohi/justice/blob/c428041dfb5779b6b6dc8db7bf14928225a00373/.github/workflows/release.yml ; https://github.com/yohi/justice/blob/c428041dfb5779b6b6dc8db7bf14928225a00373/package.json
- Visible policy: https://api.github.com/repos/yohi/justice/branches/master ; https://api.github.com/repos/yohi/justice/rulesets/14286365
- Run evidence: https://github.com/yohi/justice/actions/runs/39898374188 ; https://github.com/yohi/justice/actions/runs/39898374191 ; https://github.com/yohi/justice/actions/runs/39898374163 ; https://github.com/yohi/justice/actions/runs/39898374161
- Historical Release https://github.com/yohi/justice/releases/tag/v4.3.1 ; P9 intake https://github.com/yohi/justice/pull/325
- Official references: https://docs.github.com/en/rest/repos/rules ; https://docs.github.com/en/packages/working-with-a-github-packages-registry/working-with-the-npm-registry ; https://docs.npmjs.com/trusted-publishers/ ; https://github.com/googleapis/release-please-action ; https://docs.github.com/en/code-security/how-tos/secure-your-supply-chain/establish-provenance-and-integrity/prevent-release-changes

### Capture quality limitations

Eight key provider GET bodies have individually time-bounded acquisition windows and independently computed SHA-256 over the exact returned **connector text**. Connector errors have exact start/end UTC. Remaining metadata sources were read earlier in this session without independent exact time-bounded raw-text SHA collection; those rows explicitly say `NOT_CAPTURED`, preserve provider IDs/digests, and **must not be promoted to stronger evidence based on assumed capture quality**. No evidence proves connector identity allows full policy or secret list disclosure. No current GitHub Packages metadata acquired.
