# Complete R10→R11 Proposal ZIP Tree Difference

- Old proposal ZIP SHA256: `66ac9ebab5400460b28d28180e212969aa09a9a8d643662b80c51bb48701d309`; new proposal ZIP SHA256: `1df24d4250132a3df1bc2c4d39b53baebbe1b1d8ad8060862c0531743601d185`.
- Unified patch contains **all filenames**, including README, SHA256SUMS, additions, deletes and content-identical renames. Generated with Git from two extracted source trees using `git diff --cached --find-renames --binary --full-index HEAD`; no remote repository changed.
- Machine-readable `INVENTORY.json` records every old and new source ZIP entry (including manifest), each SHA256 and exact-byte historical rename edges. It is a **complete package change set**, not an equivalence of generated runtime or source code.
- Patch SHA256: `0b35283050c6082c4eed425efc9521d17ced722330e2cc868148635a3a4a9d8f`. To reproduce, unpack R10 ZIP into an empty Git repo, initial-commit that tree; replace with R11 ZIP contents, `git add -A`, run the diff command above. Review the `rename from`/`rename to` headers for immutable historical files.
- New/old ZIPs are provided in R11 independent handoff as canonical inputs. Patch and inventory are static analysis outputs; not a Gate or authority.
