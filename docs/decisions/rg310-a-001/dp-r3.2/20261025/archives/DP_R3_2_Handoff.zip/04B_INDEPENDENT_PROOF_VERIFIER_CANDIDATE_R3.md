# DP-R3 — Independent canonical proof verifier / authenticated receipt contract (CANDIDATE ONLY)

**Status:** `AUTHOR_R3_LIMITED_CORRECTION / IS_NORMATIVE=false / FROZEN=false / ADOPTED=false / NOT_EXECUTED`. This supersedes only the *candidate* DP-R2 document `04B...R2.md` for documentary review; keep R2 original byte-for-byte. No verifier, trusted key or provider veto currently exists as a demonstrated implementation. Never treat a JSON Schema parse, string `PROVEN`, a claimant-provided receipt, or a forged-looking signature as an external validation.

## 1. Two trust-separated messages

`04A` describes an **untrusted claim envelope**, optionally carrying a receipt blob. `04A.$defs.canonical_verification_receipt` describes the *shape* of an independent verifier's signed output; its appearance in a claim does not authenticate it. A separate authorized and externally trust-anchored verifier must emit or independently retrieve that exact output; claimant cannot choose approved verifier profile, signer key, replay database or provider trust anchor. Verification is the future service's output, not a second claimant-supplied `independent_verifier_status=PROVEN` field.

The signed receipt is: `{receipt_protocol_version, source, canonicalization, signed_subject, signed_subject_sha256, verifier_signature_algorithm, verifier_signature_or_attestation, receipt_id}`. `signed_subject` is the *sole signed assertion payload*, with all listed required fields in `04A.$defs.verified_subject`. Canonicalize the subject with the **proposed** RFC 8785/JCS I-JSON UTF-8 rules (reject non-I-JSON, duplicate keys, noncanonical integer encoding, unsupported algorithm, undefined normalization or extension fields), compute SHA-256 over the exact canonical bytes, and verify the configured detached signature/provider attestation with a domain-separated context and the externally provisioned trust anchor. A text digest printed by claimant is never a fresh computation. Profile/algorithm selection remains Owner-pending.

Required *authenticated signed subject* fields:

- `verifier_id`, `verifier_trust_anchor_id`, `verifier_key_id`, `verifier_key_epoch`, `verifier_profile_id`, `verifier_profile_sha256`, `verifier_signing_domain`, `verification_checked_at_epoch` and `evidence_profile_status=EXTERNALLY_APPROVED_CURRENT` — validate provider-issued profile identity, validity, key rotation/revocation and signing purpose independently; any string value alone is NOT proof.
- `predicate_id`, `predicate_result` (`PROVEN`/`DENIED`), `proof_source_issuer_id`, `proof_source_key_epoch`, `raw_witness_sha256`, `raw_witness_encoding`, `raw_witness_media_type` — independently retrieve exact raw witness bytes from the authenticated source and hash them; metadata-only readback never proves byte equality.
- `verified_request_id`, `verified_attempt_binding`, `request_attempt_binding_sha256`, `verified_effect_id`, `verified_resource_id`, `verified_principal_id`, `verified_provider_policy_id`, `verified_provider_policy_epoch`, `verified_artifact_chain_id`, `verified_root_sha256`, `verified_challenge_nonce`, `nonce_replay_namespace`, `verified_interface`, `verified_issuer_epoch`, `verified_db_term`, `verified_db_sequence`, `verified_issuer_checkpoint_id` — compare field-by-field with the canonical request, Owner-signed policy and external provider first-ingress evidence, not only same root/nonce. `request_attempt_binding_sha256` is the hash of separately provided canonical, authenticated request-to-attempt mapping bytes; recompute and validate every selector. Reject two physical attempts sharing a purported unique mapping or one physical attempt mapped to two requests.
- `verified_observation_interval` (`lower`, `upper`, `time_domain_id`, `witness_id`, `calibration_status`, `causal_order_status`), and `denial_before_effect_proof` discriminated kind — independently verify bounded common causal domain and ordering. `lower<=upper` alone is insufficient, as is a same-looking time-domain string.

## 2. Attempt identity: distinguish request from physical mutation

The outer `request_id` is a correlation identifier, **not** the physical mutation attempt. Only `EXTERNAL_FIRST_EFFECT_ATTEMPT` (has `immutable_attempt_id`, `provider_id`, mutation kind and `resource_id`) may bind a remote-provider FIRST write/denial; verify issuer-authenticated mapping request↔attempt and exact witness/event IDs, then verify no mapping replays. `NO_EXTERNAL_FIRST_EFFECT_ATTEMPT` has `request_id`, `predicate_instance_id`, and enumerated `no_external_attempt_reason` **without any invented attempt ID**. Valid candidates include issuer-state check, authorization-only, DB durability, private signer seal, recovery-local check or Host use observation. A `REMOTE.readback` may reference a pre-existing physical attempt, but a local metadata-only readback is not automatically a new first-effect attempt. Classify it according to the actual original attempted write; if the origin is missing, `UNKNOWN`.

For no-external-attempt predicate `predicate_result=DENIED` is not a provider **before-first-effect refusal**; output `UNKNOWN/NOT_PROVEN` for the physical-effect question. A policy's internal unauthorized result does not establish a provider-origin denial.

## 3. Provider-denial special case

`predicate_result=DENIED` requires external attempt binding and `denial_before_effect_proof.mode=PROVIDER_FIRST_EFFECT_DENIAL`. Signed subject **must** carry exact `provider_origin_denial_witness_sha256`, `denial_event_id`, `denied_attempt_id`, `denied_provider_policy_id`, `denied_policy_epoch`, `denied_resource_id`, `denied_principal_id`, `denied_effect_id`, `denial_causally_before_first_mutation`, and scoped negative readback digest. The independently obtained raw provider denial witness and negative-effect readback bytes must hash to those claimed hashes. Verify actual provider mutation admission point, policy enforcement epoch, causal BEFORE relation, and complete competing writer population separately. A claimed `denial_causally_before_first_mutation=true` flag is only data until authenticated causal ordering is verified. `DENIED` for one attempt does not prove non-bypassable closure across all alternative writers, apps, PATs or administrator exceptions.

No physical prior provider denial proof may be silently replaced by a late `npm pack --dry-run`, a GitHub tag ruleset protecting Release Assets/Packages, or an unproven token/ACL bound to a root/attempt. Where selected strict assurance has no native non-bypassable provider enforcement or demonstrably exclusive credential custody: `UNENFORCEABLE_AS_PROPOSED / NO_CURRENT`.

## 4. Future finite validation algorithm, not executed

1. **CHECK_PROFILE:** load externally authenticated and current Owner-adopted R'/D'/P' and immutable verifier profile (currently NONE); check principal trust and authorized predicate domain. No authenticated current profile ⇒ `UNKNOWN/NOT_PROVEN`.
2. **CHECK_ENVELOPE:** structurally parse `04A` and reject unknown/double JSON keys and noncanonical I-JSON; this is syntax only and cannot confer proof.
3. **CHECK_ORIGINAL_BYTES:** independently retrieve canonical authenticated raw witness and request↔attempt binding (where relevant), and hash *actual bytes*, not claimant text. Raw bodies unavailable ⇒ `UNKNOWN`.
4. **CHECK_RECEIPT_SIGNATURE:** canonicalize exactly `signed_subject`; recompute digest; independently validate signature/attestation with whitelisted algorithm, trust anchor/key ID/epoch, purpose, profile digest and revocation. Receipt issuer may not be requester. Attestation absent/unverifiable ⇒ `UNKNOWN`.
5. **CHECK_EXACT_BINDING:** require semantic equality of signed subject to request ID, exact immutable physical attempt OR typed no-attempt instance, provider mutation/resource/principal/effect, artifact chain/root, issuer checkpoint/DB term/sequence, policy epoch, nonce namespace and key epochs. IDs with no authenticated chain of custody cannot be joined even when strings match.
6. **CHECK_REPLAY_AND_CAUSAL:** verify nonce and immutable attempt uniqueness in authenticated replay ledger and exact trusted time-domain calibration and interval bound; fail on overlap/incomparable clocks/revoke uncertainty. JSON Schema cannot check comparative bounds nor authenticate clock.
7. **CHECK_PREDICATE:** rederive the exact interface-specific predicate from independently authenticated source bytes. For `DENIED`, require provider-origin prior admission refusal, complete per-attempt witness and negative readback. For `PROVEN`, require actual positive interface proof; not mere signer/client ACK, metadata equality or a string status.
8. **EMIT_FINITE_RESULT:** only after 1–7 may future independent verifier return a signed receipt for **one precise predicate**; cannot unilaterally certify `CURRENT` or Complete Mediation. On `IN_DOUBT`/`CONFLICT`/`UNSUPPORTED` or missing source bytes, return `UNKNOWN/NOT_PROVEN/NO_CURRENT`; no blind retry or silent downgrade.

## 5. Explicit nonpromotable counterexamples — paper only

| ID | Untrusted inputs | Required negative disposition |
| --- | --- | --- |
| R3-NEG-01 | Claimed `PROVEN`, valid JSON Schema, but copied or self-signed verification receipt | `UNKNOWN/NOT_PROVEN`, no certified CURRENT |
| R3-NEG-02 | Signed receipt for attempt A attached to request B (same root and nonce) | `CONFLICT/NOT_PROVEN`, reject cross-attempt join |
| R3-NEG-03 | Correct policy/effect but signed witness digest ≠ independently fetched bytes | `CONFLICT/NOT_PROVEN`, no proof promotion |
| R3-NEG-04 | Provider `DENIED` response for tag mutation reused for Release Asset upload | `UNKNOWN/NOT_PROVEN`; effect/resource mismatch |
| R3-NEG-05 | Signed output has `NO_EXTERNAL_FIRST_EFFECT_ATTEMPT` yet asserts provider prior-denial | `UNSUPPORTED/NOT_PROVEN`; wrong predicate type |
| R3-NEG-06 | Key epoch revoked or profile not approved; receipt cryptographically plausible | `UNKNOWN/NOT_PROVEN` (invalid trust) |
| R3-NEG-07 | Local timestamp lower/upper valid but incompatible signer/provider domains | `UNKNOWN/NOT_PROVEN` (causal ambiguity) |
| R3-NEG-08 | Prior-denial event true for one attempt, another App/PAT can still publish | No Complete Mediation; no `CERTIFIED_CURRENT` |

All rows are synthetic text cases; **no test was executed** and no new source/provider/Host observations were made.

## 6. Scope/authority distinctions

`JUS5-GATE-02` / `INV-04` approved v5 fail-closed acceptance remains mandatory. Interface `04`, `04A`, this `04B` and proposed `04C` are R3 **author candidates only**: no positive claims about crypto, status or provider/Host enforcement. Original 22 Finding OPEN, NC37 NOT_EXECUTED, Task1 31/32 BLOCKED, H0–H3 NOT_PROVEN, R11 UNAPPROVED, Owner DS-01..06 and O-01..07 UNSELECTED, R'/D'/P' NOT_ADOPTED, P2–P4 interface freeze STOP, Tasks2–14 NOT_AUTHORIZED.
