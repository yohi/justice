# Justice RG-310-A-001 — DP-R3限定是正（著者案）

審査日：2026-10-25 JST。DP-R2独立再レビュー：12指摘中YES 11／PARTIAL 1／NO 0。**DP-R3は残存FND-DPR0-004の文書是正のみ**を目的とする。

- `04/04A`: 証拠を主張するレスポンスと、独立した検証主体が発行・署名する正規検証receiptを分離。生の証拠バイトSHA-256、requestとimmutable attemptの真正な対応、対象リソース・effect・principal・policyとepoch、artifact chain/root、nonce、時刻の因果関係を一つの署名対象へ収録。
- `04B_R3`: 正規化、外部信頼anchor、鍵epoch・失効、署名・原バイト・nonce・replay照合、provider-originでのfirst-effectより前の拒否を、型付き検証アルゴリズムの**案**として記述。JSON Schemaの構造検証のみで`PROVEN`にしない。
- `04C`: cross-attempt流用、証拠ハッシュ不一致、対象API違いなど8件の未実行反例。外部First-Effectが存在しない検査は明示的なno-attempt variantとし、架空のattempt IDを要求しない。
- 11件の過去の独立YESは文書品質評価として保持。R3独立再レビューは未実施。

**絶対境界:** 既承認v5 fail-closed acceptance維持、R11未承認、R'/D'/P'未採択、DS-01..06／O-01..07未決、Task1 BLOCKED 31/32、22 Finding OPEN、NC37 NOT_EXECUTED、H0-H3 NOT_PROVEN、P2-P4 STOP、Tasks2-14 NOT_AUTHORIZED。実装・試験・GitHub書込・Host/provider実験・Owner署名は行っていない。
