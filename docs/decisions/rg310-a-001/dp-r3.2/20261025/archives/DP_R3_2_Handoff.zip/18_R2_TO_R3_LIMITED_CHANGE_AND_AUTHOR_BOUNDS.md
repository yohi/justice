# DP-R2 → DP-R3 bounded author change — FND-DPR0-004 only

**2026-10-25 JST. AUTHOR DRAFT / UNSIGNED / DOCUMENTS ONLY.**

R2 independent review source SHA-256: `ea7a1564e4d6a99e5339572b2c836def52545753aee02781b8e8937770bd9e8d`. R2 original handoff SHA-256: `f726aac4501b3ec7070e07ef810a2669ec0752f41093700afaae37c93afbafd0`. R2 independent verdict: `REVISION_REQUIRED`, YES 11 / PARTIAL 1 / NO 0. One remaining document gap: external verifier receipt does not bind raw proof/attempt/witness/object/policy and issuer in one typed signed canonical subject.

## Scope of author-only correction

- `04`: add explicitly authenticated receipt predicate requirements and request-vs-immutable-attempt/no-attempt distinction for all eight candidate interfaces.
- `04A`: add structurally typed signed-subject and canonical-verification-receipt candidate definitions, required for PROVEN and provider DENIED, including raw_witness_sha256, request_attempt_binding_sha256, authenticated predicate/effect/principal/resource/policy+epoch/root/challenge, independent signer profile and concrete provider prior-first-effect denial witness. Shape is not proof.
- `04B...R3`: external-profile trust roots, cryptographic/domain validation, request/attempt/source-bytes equality, signer epoch/nonce, replay, time/causal checks; explicit no-external-attempt variant. Preserve unchanged R2 version for audit.
- `04C`: eight *unexecuted* synthetic negative cases including cross-attempt reuse, witness byte-hash mismatch, wrong effect and provider bypass.
- `01/02`: tie candidate verifier output to WP06b full proof closure; correct R1 stale current-status narrative and explain author R3 status.
- `00/08/09/13_R3/16_R3`: point reviewer to changed exact bytes, limits and non-regression.

### Does not do

No provider capability observation, real verifier execution, package/release write, GitHub change, test execution, trusted key enrollment, Owner adoption, formal Gate, Task2–14, DS/O selection, R'/D'/P' freeze or approved v5 rewrite. The previous eleven R2 YES are inherited **document-level** independent verdicts, not new R3 reviewer judgments. They remain subject to non-regression check.
