# DP-R3.1 限定文書是正サマリー（著者評価のみ）

独立DP-R3評価：`REVISION_REQUIRED / YES 11件 / PARTIAL 1件 / NO 0件`。残るFND-DPR0-004の6論点（4件＋編集・receiptメタデータ）を文書として修正しました。**独立再レビュー未実施、DOCUMENT_READINESS_PASS未取得**。

- **版数：** 04/04Aを`CANDIDATE_DP_R3_1`に統一。R2/R3からの無断変換禁止。
- **時刻精度：** RFC8785/JCS署名対象のUnixナノ秒は正規10進**文字列**、int64境界と上下限比較は独立検証条件。IEEE754整数変換禁止。
- **no-attempt：** 正式な物理attemptの代わりに、出所認証済みのno-attempt predicate-instance **そのもの**のバイトとSHAを検証。架空のattempt IDを発行しない。
- **policy：** 署名subjectの`verified_policy_binding`をProvider policy、内部署名policy、範囲特定済み不適用へ分岐。外部拒否はProvider policyと物理attemptの両方が必須。
- **receipt結合：** 署名済みID／アルゴリズム／正規化profileを外側receiptと独立信頼rootに対応付け、不正差替え・再利用を拒否。
- **非回帰：** 既存11 YES、27効果、8 interface、16 WP＋WP06a/b、34紙上fixture、22 Finding/NC37、13のOwner判断（未選択）、R11/Task1/Host/Providerの全STOPを維持。

ZIPとR3 independent reviewは原本バイト保存。新規10件04Dは未実行紙上反例であり、試験合格とは扱いません。設計と実装計画以外の許可・実行はありません。
