# Justice RG-310-A-001 — DP-R2 限定是正（著者案／未審査）

独立R1レビュー：`REVISION_REQUIRED`。元の12件は **YES 9、PARTIAL 3、NO 0**。対象はFND-DPR0-003（Provider別First-Effect強制）、004（8インターフェイスの証拠検証）、007（T07/T34の紙上fixture）。その他9件の文書上YESを運用PROVENへ昇格していません。

- **003:** E01～E15を個別のMutation API、実在が確認できる認可プリミティブ候補、外部からの確認条件、代替Writer、未提供／実効未確認時の`UNENFORCEABLE_AS_PROPOSED`へ分解。branch/tag rulesetでRelease、Asset、PR、GitHub Packagesが必ず止まるという誤りは明示的に排除しました。候補ポリシー・token ACLが署名済みattempt/rootへ結合する保証は未証明。
- **004:** `04`と`04A`を整合させ、`04B`で真の独立検証条件を規定。PROVEN文字列、署名らしいテキスト、DENIED理由だけでは`PROVEN`になりません。時刻区間の大小、共通causal domain、provider拒否の先行性はJSON Schemaでは検証できず、実証データのない状態は`UNKNOWN/NO_CURRENT`。
- **007:** T07=コミット区間1.0～2.0秒／期限1.5秒の重複、T34=現在鍵epoch8／復元seal鍵epoch7／seal seq40対紙上high-water42を別々の入力に。34 fixture全件に静的ケース別の期待反証項目と外部証拠欠落の扱いを記載。全件 **SPEC_ONLY_NOT_EXECUTED**。

**著者側判定:** `AUTHOR_DRAFT_COMPLETE_FOR_REVIEW / FRESH_INDEPENDENT_RE_REVIEW_REQUIRED`。正式な設計・実装計画完成判定、Owner選択、R'採択、実装許可ではありません。今回もコード・Provider・GitHub・CI・DB・Hostの更新や試験実行は行いません。R11 UNAPPROVED、Task1 BLOCKED、P2～P4 STOP、Tasks2～14 NOT_AUTHORIZED。
