# DP-R3.1 → DP-R3.2 limited author correction and bounds

**Author-only disposition:** `PROPOSED_CORRECTION / FRESH_INDEPENDENT_RE_REVIEW_REQUIRED`. Not independent YES, formal Gate, or executed test.

| Independent item | Review evidence | R3.2 bounded document correction | Claimed author state |
| --- | --- | --- | --- |
| FND-DPR31-NEW-001 | R3.1 review §3 identifies unsafe signed epochs/sequences; separate static author census finds 11 signed and 8 outer/legacy `type:integer, minimum:0` and confirms JCS/IEEE754 2^53 ambiguity | All 19 changed in-place as canonical ASCII unsigned base10 JSON **strings** with exact arbitrary-precision parse and before-JCS raw-token rejection; signed subject/source/outer binding in `04`, `04A`, `04B_R3_2`; 12 unexecuted negative-paper oracles in `04E` | `AUTHOR_CORRECTED_NOT_INDEPENDENTLY_REVIEWED` |
| FND-DPR0-004 inherited | R3.1 R3 subissues A–D + editorial/receipt metadata were independently rated YES, but new signed-number gap keeps overall PARTIAL | New `CANDIDATE_DP_R3_2` version and exact receipt refs; old canonical ns/no-attempt/provider policy branches preserved, new unsigned epoch/sequence values made lossless | `AUTHOR_CORRECTED_NOT_INDEPENDENTLY_REVIEWED` |
| FND-DPR0-001..003,005..012 | R3.1 independent 11 historical YES | No edits to 05, 06, 07, 10, 11, 12, 15 or 15A core evidence/plan rows; only 01/02 explanatory addenda. Recheck nonregression independently. | `HISTORICAL_DOCUMENT_ONLY_YES` |

**Representation contract:** `^(0|[1-9][0-9]*)$`, 1..128 ASCII characters, JSON string only (including outer claimant and legacy untrusted receipt fields), reject raw number, overlength, whitespace, exponent, prefix/sign/leading zeros. Exact source-authenticated comparison is a future verifier obligation. `"9007199254740992" != "9007199254740993"`; both unquoted forms invalid for these fields. No tests/signatures were run, no trusted clock/provider first-effect enforcement asserted.

**Original document boundaries:** approved v5 acceptance remains mandatory. R11 UNAPPROVED; R'/D'/P' NOT_ADOPTED; 13 DS/O unsigned; original 22 OPEN and NC37 NOT_EXECUTED; Task1 BLOCKED historical 31/32; H0-H3 NOT_PROVEN; P2-P4 INTERFACE_FREEZE_STOP; Tasks2-14 NOT_AUTHORIZED. DP-R3.2 does not select Architecture B or grant any work.
