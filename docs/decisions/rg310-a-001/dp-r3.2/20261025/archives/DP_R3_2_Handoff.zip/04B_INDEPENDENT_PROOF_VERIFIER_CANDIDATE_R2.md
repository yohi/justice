# DP-R2 / Candidate independent proof verifier contract — DOCUMENT ONLY

This is a non-normative finite specification. **Neither schema validation, a PROVEN string, a plausible signature, nor a DENIED reason code is sufficient to certify a predicate.** Verification is not performed here. A JSON Schema cannot prove signatures, authenticate provider membership, compare lower <= upper across fields or prove causal ordering. Such semantic checks are explicitly separate from structural validation.

## Verification state machine

1. Parse the envelope using `04A` as *shape* validation only. Invalid syntax => `NOT_PROVEN`. A syntactically valid `PROVEN` label is an untrusted claim until 2–8 complete. Unknown issuer, replay, absent trust root, mismatched object, ambiguous time domain or provider rights => `UNKNOWN/NOT_PROVEN`, no `CURRENT`.
2. Resolve `interface` to an **independently provisioned and Owner-approved** verifier profile: allowed proof issuer(s), provider tenant/project/repo/package, trust-anchor identity, key rotation/revocation epoch, signature/attestation algorithm, allowed object types, accepted canonical encoding, time-domain evidence and proof freshness. Profile availability, authorization, and rotation are NOT_PROVEN; no trust root is selected now.
3. Canonically bind `request_id`, nonreplayable `challenge_nonce`, `artifact_chain_id`, `root_sha256`, exact `effect_id`, `actor_id`, issuer checkpoint, DB term/seq and policy epoch to signed/provider-attested proof bytes and `verified_evidence`. If any comparison fails, do not promote. A self-declared receipt does not authenticate its own verifier ID or signature.
4. Validate signature/provider attestation against that *external* trusted key and authenticated provider provenance. Validate key ID/epoch not revoked in relevant interval, replay nonce uniqueness, request/attempt ID uniqueness and that all scope/resource selectors match the policy. Receipt digest SHA-256 must be calculated from the actual externally supplied canonical proof bytes, not copied from claimant input.
5. Verify interval lower/upper are integer time values with `lower <= upper`, same authenticated `time_domain_id`, `calibration_status=TRUSTED_COMMON_DOMAIN_VERIFIED`, valid causal witness and bounded uncertainty. Clocks from incompatible domains, uncalibrated UTC/SQL `now()`, or overlapping interval decision boundaries => `UNKNOWN`, never a proof of commit freshness or denial-before-effect. No synthetic `TRUSTED` fixture establishes runtime time credibility.
6. `PROVEN`: after 1–5, independently verify the operation-specific predicate (issuer revoke ordering; durable COMMIT witness; readback of identical physical bytes; grant at first effect; signed seal; high-water/fencing; Host actual *used* bytes) from source appropriate to its issuer. Return an **independently generated** verified receipt scoped to one predicate only. It is not `Accepted/CURRENT` without entire selected dependency closure.
7. `DENIED`: require provider-origin `denial_source`, signed/authenticated `before_effect_witness` with provider policy ID/epoch, exact API mutation kind/object id, actual principal and immutable attempt, denial event and attested causal BEFORE-first-write relation; check provider-side negative-effect readback scoped to that attempt/resource; require independent verification receipt. One refusal is NOT a census of all writers. Late rejection after a first external write does not qualify.
8. `UNKNOWN`: require reason+scope; `IN_DOUBT`: immutable attempt, possible first effect, verified no blind retry; `CONFLICT`: exact expected vs observed remote OID; `UNSUPPORTED`: unavailable capability+required assurance. All of these block selected strict remote first effect and certified CURRENT. No lower-assurance substitution without explicit Owner/R'/D'/P' adoption.

## Interface-specific proof sources (all unresolved)

| Interface | External attestor/trust root candidate | Independent negative oracle |
|---|---|---|
| ISSUER.revoke_issue/query_fence | issuer append-only receipt plus independently observed causal checkpoint | signer-only revoke or late imported revoke is not proof of issuer-effective strict fence |
| AUTH.authorize_commit | human-signed exact R/D/P identity + independent time/fence binding | an authorization label without provenance and exact approved chain is NOT_PROVEN |
| DB.commit_durable_receipt | independently attested durable commit/sequence/byte root witness | transaction start time or client ACK alone is not proof of durable COMMIT instant |
| SIGNER.readback_and_seal | independent signer verifying persistent DB root after COMMIT, monotonic signer epoch | seal made while DB aborts, stale key, or ACK loss gives UNKNOWN/CONFLICT |
| EFFECT_GRANT.authorize_once | provider-enforced first-ingress policy/veto plus total writer census | locally issued grant cannot prevent direct App/PAT/API mutation |
| REMOTE.readback | provider-origin remote exact object-version bytes/OID and independent hash | metadata digest or HTTP 200 alone cannot establish byte equality |
| ACK.high_water/RECOVERY.fence | independent durable high-water and former-primary/provider identity fence | restored primary with stale valid writers => BLOCK |
| HOST.attest_actual_use | trusted OS/loader/remote attester isolated from untrusted JS/native package | path-based module load or inspected on-disk filename != used mapped bytes |

**Author-only static checklist, not executed:** 8 interface names preserved; all six result types; DENIED requires before-effect attestation; PROVEN requires independent verifier receipt; schema cannot claim verifier operation; no runtime or provider credential was touched.
