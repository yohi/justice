# DP-R1 — Material normative branches and owner decisions (UNSIGNED)

**This is NOT an adopted R'/D'/P' or Owner decision.** Existing approved v5 remains controlling; exact v5 human authorization and fail-closed acceptance duties are non-waivable by draft scope policy.

- **DS-01 / O-02..06:** select effective trust root and provider first-effect physically deniable set per actual resource ID, policy epoch, App/PAT/admin principals and bypass modes. O-01 completeness and owner-signature currently `NONE`. No supported first-write GO.
- **DS-02 / O-01:** formally decide C1-FULL legitimate producer/consumer/effect universe, per-effect assurance, explicit exclusions and epoch. Offline historic noncooperative third-party copies cannot be falsely represented as physically fenced; retain fail-closed Justice acceptance for unproven inputs.
- **DS-03:** explicitly choose `RV_COMMIT_FRESHNESS`, `RV_STRICT_ISSUE`, or a **materially new proposed** `RV_FENCE_BLACKOUT` (requires reviewed R'). A source-level impossibility for observed split domains does not prove the whole approved v5 impossible.
- **DS-04:** choose private DB committed candidate + independent readback/seal + remote effect isolation as proposed, or document alternate and independently falsify. A new two-stage B-C1 contract is not R11 literal one-operation distributed `ACCEPT+PUBLISH`.
- **DS-05:** select supported Host trust roots and concrete JS/native actual-use verification. Existing H0–H3 have not passed.
- **DS-06 / O-07:** select independent high-water, former-primary effective fence, stale key/token denial, and remote unknown/reconciliation policies; a DB epoch cannot replace a physical boundary.

**Explicitly pending:** all thirteen DS/O decisions in 03 remain `selected_option=NONE`; proposed `04A` schema is not frozen; every provider first-effect has effective-rights and enforcement `NOT_ESTABLISHED`; no implementation branch or CI change authorized.
