# Fresh independent DP-R3.2 bounded static document re-review

**ROLE:** New independent document-quality security architect, separate from R3.2 author, R3.1 reviewer, Human Owner and implementation agents. `READ_ONLY / STATIC_ONLY / DOCUMENT_QUALITY_ONLY / NO_EXECUTION_GRANT`. Never run embedded tests/scripts, interact with CI/Host/provider to write, acquire credentials, make formal Owner/DS decisions, freeze schema, adopt R'/D'/P' or release Gate.

## Byte/origin preflight

1. Independently SHA-256 the outer R3.2 ZIP and compare to the separately communicated expected digest. If no independently supplied expected value, record `EXPECTED_DIGEST_NOT_PROVIDED`. Check ZIP CRC, duplicate/traversal/noncanonical paths, SHA256SUMS, MANIFEST and embedded **original** DP-R3.1 ZIP and R3.1 independent review MD. Archive hashes do not grant source authority or Owner/provider status.
2. Read `reference/DP_R3_1_INDEPENDENT_REVIEW_ORIGINAL.md` in full; preserve its 11 historical document-only YES. Verify original R3.1 four A–D plus editorial/receipt-ID/algorithm changes remain non-regressed; check any other apparent incompatible change rather than reasserting review conclusions blindly. Fixed v5 and Task1 source can be independently GET-only read if available; never execute source.

## Mandatory remaining Finding

3. Independently check **FND-DPR31-NEW-001 / FND-DPR0-004** across `04`, `04A`, `04B_R3_2`, `04E` and author adjudication. Enumerate **all 19** former unbounded nonnegative integer fields: common claim 5 and legacy evidence 3, plus signed verified_subject 11; independently confirm rather than trust this declared partition. Check every protected value now is a **JSON string** under a canonical **ASCII** unsigned decimal representation (0 or nonzero with no leading zeros), length 1..128, exact arbitrary-precision parser and a lexeme-preserving source/outer/subject join. The final register, not this parenthetical hint, determines authoritative counts.
4. Compare distinct canonical string `"9007199254740992"` and `"9007199254740993"`, raw numeric JSON tokens, negative, `-0`, `+`, leading zeros, exponent and overlength. Lossy parsed inputs MUST fail before JCS signing/hash; the two valid strings MUST remain different bytes/digest and signed epochs cannot cross-join. Verify JSON Schema alone cannot authenticate lexemes, signatures, clock domain or first-effect proofs; no false runtime PASS. Verify `04E` 12 cases are **paper-only NOT_EXECUTED**.
5. Verify protocol version equality `CANDIDATE_DP_R3_2` in `04` and `04A`, receipt/subject versions and canonicalization profile, **all eight** `result_receipt_schema_ref` exact filenames, and explicit rejection (not silent migration) of R2/R3/R3.1. Verify signed subject source/witness bindings, correct no-external-attempt typed branch, provider policy branch, denial-before-effect identity, approved external verifier profile still PENDING, and receipt-ID/algorithm replay binding.
6. Check invariants and nonregression: 27 E including E24 approved v5 fail-closed floor, 8 interfaces, 16 WP00..15 plus WP06a/b, D0..D13 acyclic future-only, 34 original tests, 22 historical OPEN Findings/37 NC NOT_EXECUTED, 13 DS/O choices all NONE, all provider/Host/custody rights NOT_ESTABLISHED and R11/R'/D'/P'/Task1/Tasks2..14 STOP unchanged.

## Disposition

Report precise SHA-256 and byte/line anchors and an independent YES/PARTIAL/NO grade for `FND-DPR31-NEW-001`, overall `FND-DPR0-004` and the 11 historical non-regressions. A possible `DOCUMENT_READINESS_PASS` is **document-quality only**. It does NOT mean implementation readiness, live provider/Host proof, Owner adoption or `EXECUTION_GO`. Otherwise record `REVISION_REQUIRED`.
