# DP-R1 → DP-R2 limited change record and author bounds

Source R1 SHA-256: `cbaed1bc219e986f5046ad9d14fde7441af6c2ff223323942aa51a8d6cf64a12`; R1 re-review SHA-256: `af463225280bf49265511b5e4912af2f075e6e9666b2038503bf70ab4fad7c16`.

| File | R2 change | Original status |
|---|---|---|
| 01, 02 | Append limited signed/unsigned distinction, provider-stop, verifier, paper-trace design/plan addenda | Candidate R1 text otherwise retained |
| 04, 04A | Semantic/schema field alignment; non-frozen eight interfaces and six result types | Does not authenticate signatures or issue real proof |
| 04B | New external semantic verifier specification | PROVEN never follows merely from JSON parsing |
| 06, 15 | T07/T34 finite synthetic time/key/seq witness tuples | No trial/execution |
| 10...R2 | E01..E15 provider-specific conditional API/permission mechanism, unsupported STOP | E01..E15 physical veto still NOT_ESTABLISHED |
| 13...R2 | Track nine R1 YES and three R2 author-corrected proposals separately | Independent DP-R2 NOT_REVIEWED |
| 15A | 34 case-specific static audit; external proof per case NOT_OBSERVED | Not test execution |
| Other R1 registries | Unchanged byte content, with R1 names preserved | No status promotion |

User authorization permits **design and implementation-plan documentation only**. No R'/D'/P' adoption, O-01 signed effect scope, DS-02 selection, schema freeze, runtime proof or Task2-14 grant. Original A/B and U-07 distinctions maintained. Baseline v5 JUS5-GATE-02 and INV-04 never depend on pending Owner effect selection.
