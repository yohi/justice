# Justice RG-310-A-001 — DP-R3.1 fresh independent limited static document-quality re-review

**Review date:** 2026-10-25 JST  
**Authority:** READ_ONLY / STATIC_ONLY / DOCUMENT_QUALITY_ONLY / NO_EXECUTION_GRANT  
**Disposition:** **REVISION_REQUIRED** — historical R3 11 YES retained without new regression; **FND-DPR0-004 remains PARTIAL**, with the original R3 A–D and editorial/receipt-metadata defects addressed in the R3.1 candidate, but **one new blocking signed-integer/JCS precision defect** identified. **DOCUMENT_READINESS_PASS NOT_GRANTED**. This is an independent analysis of provided static material, not a signed human/Owner/provider assertion or proof of deployed controls.

## 1. Independent byte receipt and limitations

| Check | Result |
|---|---|
| Outer handoff ZIP | `Justice_RG310_C1_FULL_DP_R3_1_Limited_Independent_Static_Review_Handoff_20261025(1).zip` |
| Outer size | **639,608 bytes** |
| Independently calculated outer SHA-256 | `ffe69da3ad14ca926ad19197a0d3e6368d7a34275a702c142c5c6501c899ef6b` |
| Independently supplied expected outer digest | **EXPECTED_DIGEST_NOT_PROVIDED**. No external-match claim. The manifest is inside the same untrusted archive. |
| ZIP CRC / paths | **40/40 PASS**; duplicate filenames 0; absolute, parent traversal, noncanonical/backslash paths 0 |
| Outer SHA256SUMS / MANIFEST.json | **38/38** actual bytes, hashes and sizes match both lists; no missing or extra listed payloads |
| Embedded original DP-R3 ZIP | `reference/DP_R3_HANDOFF_ORIGINAL.zip`: **483,637 bytes**; SHA-256 `874ea913cb7ca8cc291a044fade13b4b3c04740664e30dc18ba7e3fb2627abe1`; inner ZIP CRC **35/35**, duplicate/unsafe paths 0; SHA256SUMS and manifest **33/33** match |
| Embedded original DP-R3 independent review | `reference/DP_R3_INDEPENDENT_REVIEW_ORIGINAL.md`: **16,199 bytes**; SHA-256 `87dff1284c992ed875408fe791b02adf9a1a4ffc72a1315c329ab60a6f0c95a4`. Read in full (92 lines). The R3 review states **REVISION_REQUIRED, 11 YES / 1 PARTIAL / 0 NO** and FND-DPR0-004 PARTIAL. |
| Earlier originals nested within R3 | DP-R2 ZIP SHA-256 `f726aac4501b3ec7070e07ef810a2669ec0752f41093700afaae37c93afbafd0` / CRC **29/29**; R2 review SHA-256 `ea7a1564e4d6a99e5339572b2c836def52545753aee02781b8e8937770bd9e8d`; both match their R3 embedded manifest. |
| R3→R3.1 reproducible change record | **Seven** changed substantive same-name files (`00`,`01`,`02`,`04`,`04A`,`08`,`09`); both integrity lists regenerated. `22_R3_TO_R3_1_TEXT_DIFF.patch` reproduces `difflib.unified_diff` of those seven files exactly (**61,654 bytes**). Other original shared substantive files are byte-identical; newly added R3.1 verifier, paper oracles, adjudication and provenance reference files are identifiable. |

These checks establish consistent receipt of the supplied bytes, **not** external original provenance, reviewer signature, authorized signer identity, Owner decision or provider authority. The independently pinned expected outer digest was not given separately. Nested historical claims are evidence *inside an archive*, not present runtime attestations.

Structural-only parsing found the `04` interface contract JSON and `04A` schema JSON to be valid JSON without duplicate keys. The `04A` schema itself passes JSON Schema Draft 2020-12 meta-schema checking. No embedded fixtures, scripts, source application, model, Host, CI, signature verifier or provider operation was executed. Meta-schema correctness establishes only schema syntax.

### Independently read fixed approved source blobs (GET-only)

`yohi/justice` approved v5 Requirements Git blob `d335c34b747cafd6ac3b2e81d710fdcc61fb777e` **lines 222–233**: `JUS5-GATE-02` explicitly makes acceptance fail closed, blocking Authorized / Accepted / Verified / Complete on missing proof. Approved v5 Design Git blob `64acdf177d2fd207861eb477af7c8a265eed71e8` **lines 152–163**: `INV-04` confirms fail-closed acceptance. Task1 `release.yml` Git blob `4f984a012f3fa9421a32531a00394f4d654d5284` **lines 17, 59–70** exposes independent release-please / npm publish / pack / release-upload commands; a read of workflow source is not proof of physical provider mediation. Pinned approved commit asserted by packet: `8a2e4f1536e9cad499ee7e9d996ff163df132fd4`; Task1 HEAD asserted: `c428041dfb5779b6b6dc8db7bf14928225a00373`. This review fetched exact blobs by SHA, not a new holistic source-tree or current effective-permissions census.

## 2. Targeted re-review — FND-DPR0-004

| R3 issue | Independent R3.1 document-only assessment | Evidence anchors |
|---|---|---|
| **A. Version mismatch** | **YES (targeted correction)**. `04.common_envelope_proposal.protocol_version` and `04A.properties.protocol_version.const` are `CANDIDATE_DP_R3_1`; explicit no implicit R2/R3 envelope conversion, with versioned receipt and signed-subject shape. | `04_EIGHT_INTERFACE_CONTRACTS_CANDIDATE.json:9,28–31`; `04A_TYPED_ENVELOPE_CANDIDATE_SCHEMA.json:38–40,944–946,1790–1792`; `04B_INDEPENDENT_PROOF_VERIFIER_CANDIDATE_R3_1.md:5–9` |
| **B. Signed Unix nanosecond precision** | **YES for ns fields, but not for other integrity-sensitive numeric fields; see NEW-001**. Outer and signed lower/upper are JSON strings matching `^(0|-?[1-9][0-9]*)$`, maxLength 20; independent exact int64 parse, bounds, causal-domain proof and `lower <= upper` explicitly required. No acceptance of `-0`, plus sign, leading zeros, exponent, numeric token, negative/positive int64 overflow or inverted interval under the *specified future semantic verifier*. Schema alone cannot check overflow or ordering. | `04:20–31`; `04A:92–114,1120–1147`; `04B_R3_1:11–15`; `04D:3–5` |
| **C. Attempt vs no-attempt digest ambiguity** | **YES (targeted correction)**. Disjoint `verified_attempt_binding.oneOf` and `verified_binding_source.oneOf`; exact `additionalProperties=false` canonical source document keys and two distinct signed source purposes; external source-authenticated actual `immutable_attempt_id` versus no-attempt source-authenticated `predicate_instance_id` without fake physical ID. Signed common digest SHA-256(JCS UTF-8 canonical binding document) and source-authentication witness, exact cross-join as mandatory *future* independent semantic checks. | `04A:1008–1090,1296–1532,1694–1774`; `04B_R3_1:17–25`; `04D:6,9` |
| **D. Scoped policy** | **YES (targeted correction)**. `verified_policy_binding.oneOf` has provider, internal-signed and scoped typed nonapplicability. External attempt or `DENIED` requires `PROVIDER_FIRST_EFFECT_POLICY`; no-attempt only internal or typed absent; source/epoch/identity joins and attestation remain semantic obligations. Typed absence never satisfies a provider pre-write veto. | `04A:1534–1648,1650–1774`; `04B_R3_1:27–31`; `04D:7–8` |
| **Editorial reference and punctuation** | **YES**. All eight `interfaces[*].result_receipt_schema_ref` entries have exact current schema filename and `04B_INDEPENDENT_PROOF_VERIFIER_CANDIDATE_R3_1.md`; each points to existing payloads and the `#/$defs/canonical_verification_receipt` schema pointer. `semantic_verifier_contract_id` similarly exact. DENIED semantic gate punctuation corrected. | `04:99,167,236,305,374,442,510,581,601–612,646–649` |
| **Receipt ID / algorithm / canonicalization substitution** | **YES as document contract, not deployed security**. `signed_receipt_id`, `signed_algorithm_id`, `signed_canonicalization_profile` are mandatory in the signed subject; outer `receipt_id`, `verifier_signature_algorithm`, `canonicalization` explicitly compared to each other and an **externally pinned, Owner-approved (currently NONE)** profile. Repeated IDs and cross-request replay rejected by the future verifier. `signed_subject_sha256` is over signed-subject JCS bytes; signature uses separate pending domain separator. | `04A:937–941,1636–1648,1777–1824`; `04B_R3_1:33–41`; `04D:10–11` |

**Mandatory distinction:** This static review checked the **completeness and internal consistency of the proposed semantic verifier obligations**, not acceptance/rejection of actual signed events by a running verifier. The candidate did not provide a real verifier, adopted trust root, signed live witness or test outcomes.

## 3. New document defect — FND-DPR31-NEW-001 (Moderate, blocking)

**Unbounded JSON numbers remain inside the JCS-signed verification subject for trust-critical epochs and sequence values.** Although DP-R3.1 correctly converts signed *nanosecond timestamps* to lossless decimal strings, the same signed `verified_subject` still permits nonnegative JSON `integer` values with **no upper bound** for:

- `verifier_key_epoch`: `04A:959–961`
- `proof_source_key_epoch`: `04A:988–990`
- `denied_policy_epoch`: `04A:1210–1212`
- `verified_issuer_epoch`: `04A:1268–1270`
- `verified_db_term`: `04A:1272–1274`
- `verified_db_sequence`: `04A:1276–1278`
- `verification_checked_at_epoch`: `04A:1284–1286`
- `verified_binding_source.source_authority_key_epoch`, both branches: `04A:1393–1395,1517–1519`
- `verified_policy_binding.verified_provider_policy_epoch`: `04A:1557–1559`
- `verified_policy_binding.internal_policy_epoch`: `04A:1585–1587`

The outer claim also has unbounded corresponding integer fields `issuer_epoch`, `db_term`, `db_sequence`, `policy_epoch` (`04A:68–90`). These are not as directly security-critical as the signed values, but the future verifier must compare them losslessly against source-witness epochs.

**Why this is material:** RFC 8785 JCS operates on I-JSON-compatible numeric values and serializes numbers using ECMAScript / IEEE-754 double precision. For example the two different integer tokens **9007199254740992** and **9007199254740993** may collapse into the same number after a binary64 JSON parse; the latter is not a losslessly representable IEEE-754 integer. `04B_R3_1:13–14` specifically prohibits lossy processing for **nanoseconds** but `04B_R3_1:35–41` does not define a comparable guard for other sensitive signed integers. Both integer tokens meet the written `type: integer; minimum: 0` form if interpreted by a lossless JSON parser, and neither schema nor the verifier contract requires a lexical non-lossy reject-before-JCS step for them. This leaves the document-level exactness of signed key/policy/issuer/DB epoch joins underspecified. It is a **possible future parser/profile ambiguity**, not a claim that runtime forgery is currently possible; no verifier exists.

**Bounded correction:** In `04A` and `04B_R3_1`, either (a) encode all such security-significant, potentially unbounded epochs and sequence numbers as canonical unsigned decimal JSON strings with exact arbitrary-precision checking, or (b) formally constrain them to safe nonnegative integers **0..9007199254740991** and mandate independent rejection of lossily parsed, unrepresentable or noncanonical *raw* numeric tokens **before** JCS processing. Specify exact source/subject/outer joins using the same representation, and add a paper-only regression oracle distinguishing `9007199254740992` from `9007199254740993`. Do not report the new oracle as executed.

**Source for numeric caveat:** RFC 8785 §§3.1 and 3.2.2.3, Appendix D: <https://www.rfc-editor.org/rfc/rfc8785.html>.

**Impact on R3 partial disposition:** Targeted R3 sub-defects A–D and both clarity items are addressed as documentary proposals; **FND-DPR0-004 = PARTIAL** overall because a newly uncovered canonical-signed integer identity gap still affects this same verification contract. New issue tracked separately as FND-DPR31-NEW-001. The preceding R3 reviewer’s eleven **YES** remain historical document-only verdicts, with no independent regression found in their scope; this does not purport to reauthorize underlying gates.

## 4. Bounded non-regression and historical stops

| Item | Independent static observation | Precise source |
|---|---|---|
| Eight interfaces | 8/8 unchanged IDs: ISSUER; AUTH; DB; SIGNER; EFFECT_GRANT; REMOTE; ACK/RECOVERY; HOST. All `is_normative=false`, `frozen=false`, `proof_issuer_verified=false`. | `04.interfaces[0..7]` (JSON lines 34–584); `04A.properties.interface` lines 26–36 |
| 27 lifecycle effects / E24 floor | 27/27 `UNSIGNED_PROPOSAL_NOT_SELECTED` and coverage open. E24 is `JUS5-GATE-02_INV-04_MANDATORY` and `APPROVED_V5_FAIL_CLOSED_MANDATORY` (CSV row **25**, header row 1). Source requirement/design blobs independently read, as above. | `05_PROPOSED_EFFECT_COVERAGE_MATRIX.csv` **CSV lines 2–28, E24 line 25**; `02` lines 151–155 |
| Future DAG | D0→D13 forward only; D8 after D7; separate D9 test, D11 Host/provider boundary and D13 human deploy grants. No cycle found in the stated D0–D13 sequence. This is a paper plan only. | `02:20–44,143–164` |
| WP count and private/certified split | 16 base `DP-WP-00..15` plus `DP-WP-06a/06b` = 18 distinct rows; all `NOT_AUTHORIZED_NOT_EXECUTED`; `WP06a` private states cannot independently certify `CURRENT`, `WP06b` requires full proof closure. | `11_WP_IMPLEMENTATION_CONTRACTS_R1.csv` rows 2–19; `02:145–155` |
| Paper fixtures and old oracles | `06` T01–T34 34/34 `NOT_EXECUTED_DESIGN_ONLY`; `15` has 34 `cases`; `15A` 34 audited rows; R3 `04C` 8/8 `SPEC_ONLY_NOT_EXECUTED`; R3.1 `04D` 10/10 `SPEC_ONLY_NOT_EXECUTED` (CSV lines 2–11). **Zero operational PASS.** | Files `06`, `15`, `15A`, `04C`, `04D` |
| Original findings / negative counterexamples | P5 inherited register has exactly 22 `INHERITED_ORIGINAL/FINDING/OPEN` and 37 `INHERITED_ORIGINAL/COUNTEREXAMPLE/NOT_EXECUTED`, 59 distinct original IDs individually present in `07` traceability. The whole P5 CSV has 251 rows inclusive of additional research and P5 paper traces (not falsely 59 total). | `reference_P5_INHERITED_22_37_REGISTER.csv` / `07_REQUIREMENT_FINDING_TRACEABILITY.csv` |
| Owner and normative options | 13/13 `selected_option=NONE`: DS-01..06 and O-01..07. No signed adopted choices in archive. | `03_OWNER_AND_NORMATIVE_DECISIONS_UNSIGNED.csv` lines 2–14 |
| R11/Task1/Host/provider STOP | R11 `UNAPPROVED`; R′/D′/P′ `NOT_ADOPTED`; Task1 historical 31/32 with Case A BLOCKED; H0–H3 NOT_PROVEN; NC37 NOT_EXECUTED; 22 Findings OPEN; provider effective-rights/first-write control/Host actual-use NOT_ESTABLISHED; P2–P4 `INTERFACE_FREEZE_STOP`; Tasks2–14 `NOT_AUTHORIZED`. Historical parent data and live status were **not newly tested**. | `00_READ_FIRST.md`, `02:13–18,139–164`, `04B_R3_1:45`, `09:29–42,64–69` |

## 5. Final bounded disposition

**REVISION_REQUIRED / DOCUMENT_QUALITY_ONLY / FND-DPR0-004 PARTIAL / FND-DPR31-NEW-001 OPEN / NO_EXECUTION_GO.**

A follow-on R3.2 limited author correction should address **only the remaining signed numeric identity problem**, provide exact R3.1→R3.2 byte diff, manifest and paper negative oracle, then obtain another fresh independent static document-quality re-review. No new source implementation, fixture/provider execution or formal Owner approval is implied.

A future `DOCUMENT_READINESS_PASS` (if independently earned) means *design and implementation-plan completeness alone*: it does **not** adopt R′/D′/P′, authenticate a trust root, close provider/Host evidence, freeze interfaces, authorize Tasks2–14, run tests, or grant production deployment. None of those grants are issued in this report.
