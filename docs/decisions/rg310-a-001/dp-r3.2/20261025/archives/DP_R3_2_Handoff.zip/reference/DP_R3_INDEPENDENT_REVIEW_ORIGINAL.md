# Justice RG-310-A-001 — DP-R3 fresh limited static document re-review

**Review date:** 2026-10-25 JST  
**Scope:** READ_ONLY / STATIC_ONLY / DOCUMENT_QUALITY_ONLY / NO_EXECUTION_GRANT  
**Disposition:** **REVISION_REQUIRED** — documentary **11 YES / 1 PARTIAL / 0 NO**. `FND-DPR0-004` remains `PARTIAL`. `DOCUMENT_READINESS_PASS` is **not** awarded. No implementation, provider, Host, CI, Owner authority or Gate was exercised or conferred.

This report is an independent-from-claims *fresh analysis pass* on the supplied static bytes, not evidence of independent human or institutional reviewer identity, provider provenance, signatures or live controls. Embedded scripts, fixtures and tests were never run; local read-only byte inspection and record counting were performed.

## 1. Byte receipt and source baseline

- Received ZIP `Justice_RG310_C1_FULL_DP_R3_Limited_Design_Plan_Independent_Review_Handoff_20261025(1).zip`: **483,637 bytes**, independently calculated SHA-256 `874ea913cb7ca8cc291a044fade13b4b3c04740664e30dc18ba7e3fb2627abe1`.
- Independently communicated expected **R3** digest: **`EXPECTED_DIGEST_NOT_PROVIDED`**. The manifest or README is not an independent checksum channel and neither a checksum nor an archive signature is Owner/provider authentication.
- ZIP CRC **35/35**; duplicate names **0**; absolute/`..`/noncanonical/traversal paths **0**.
- `SHA256SUMS` **33/33** and `MANIFEST.json` **33/33** matched the exact contained byte sizes/hashes.
- `reference/DP_R2_HANDOFF_ORIGINAL.zip`: **348,098 bytes**, SHA-256 `f726aac4501b3ec7070e07ef810a2669ec0752f41093700afaae37c93afbafd0`, nested CRC **29/29**, byte-identical to the separately uploaded earlier DP-R2 ZIP in the available working session.
- `reference/DP_R2_INDEPENDENT_REVIEW_ORIGINAL.md`: **28,549 bytes**, SHA-256 `ea7a1564e4d6a99e5339572b2c836def52545753aee02781b8e8937770bd9e8d`, byte-identical to separately available original review. It states at **lines 7–9 and 38–53**: R2 `REVISION_REQUIRED`, **11 YES, 1 PARTIAL, 0 NO**, only FND-DPR0-004 PARTIAL. Its explicit R2 source and proof limitations were read and retained, not adopted as runtime proof.
- R3 embeds byte-identical R2 `03`, `05`, `06`, `07`, `10_R2`, `11_R1`, `12_R1`, `15` and 15A candidate baselines; R3 `04`, `04A`, `01`, `02` contain amendments, and `04B_R3`/`04C` are new. R2 `04B_R2` was retained unchanged. Comparisons are content comparisons, not endorsements.
- Fixed `yohi/justice` GitHub source blobs were fetched **GET-only** at approved HEAD `8a2e4f1536e9cad499ee7e9d996ff163df132fd4`: requirements `d335c34b747cafd6ac3b2e81d710fdcc61fb777e`, design `64acdf177d2fd207861eb477af7c8a265eed71e8`, plan `10dfba4c199feff19ee387b244daf6c0fd30d5e3`. Task1 evidence branch HEAD `c428041dfb5779b6b6dc8db7bf14928225a00373` `.github/workflows/release.yml` blob `4f984a012f3fa9421a32531a00394f4d654d5284`. These match the previous fixed-source identifiers without executing source or asserting current runtime controls.

## 2. Mandatory single Finding — FND-DPR0-004: PARTIAL

**R3 material improvements:**

1. `04_EIGHT_INTERFACE_CONTRACTS_CANDIDATE.json` `common_envelope_proposal.verification_receipt_requirement` and `.attempt_identity_policy` (lines **26–27**) distinguish untrusted claimant status, client correlation ID, physical immutable attempt and typed no-attempt predicate. Every `interfaces[0..7]` now has `result_receipt_schema_ref`, `verified_attempt_join_kind`, and `candidate_verifier_must_check` (lines **95–97, 163–165, 232–234, 301–303, 370–372, 438–440, 506–508, 577–579**). The eight identities are issuer, authorization, durable DB receipt, signer, effect grant, remote readback, recovery, Host use. The interface-specific provider status remains `proof_issuer_verified=false`.
2. `04A_TYPED_ENVELOPE_CANDIDATE_SCHEMA.json` `$defs.verified_subject.required` (**lines 892–935**) explicitly contains external verifier/key/profile/signing-domain identities, proof source/epoch, actual raw witness digest, request and attempt/no-attempt variant, authenticated mapping digest, effect/resource/principal/policy+epoch, chain/root, nonce namespace, trusted interval/causal status, denial witness, DB/issuer sequence, and current verification profile. `$defs.verified_subject.properties.verified_attempt_binding.oneOf` (**997–1075**) separates physical EXTERNAL_FIRST_EFFECT_ATTEMPT from NO_EXTERNAL_FIRST_EFFECT_ATTEMPT. A provider `DENIED` subject requires EXTERNAL mode and a typed provider first-effect refusal (**1160–1284**, conditional **1285–1345**). `$defs.canonical_verification_receipt` (**1348–1394**) makes `signed_subject` and `signed_subject_sha256` mandatory alongside verifier attestation/signature, algorithm and receipt ID. Root PROVEN and DENIED conditions require the canonical receipt (**381–431**, **810–851**).
3. `04B_INDEPENDENT_PROOF_VERIFIER_CANDIDATE_R3.md` **lines 5–39** specifies independent external trust anchor, externally authorized verifier profile, approved key/algorithm and epoch checks, signed-subject JCS encoding and actual witness byte hash, nonreplayable mapping/nonce, causal intervals and independent provider-origin prior-denial proof. It explicitly disallows self-certified PROVEN and treating a single refusal as Complete Mediation. Failure is UNKNOWN/NOT_PROVEN/NO_CURRENT; no Owner adoption or real verifier is claimed.
4. `04C_CANONICAL_RECEIPT_NEGATIVE_ORACLES_R3.csv` 8 paper-only rows provide static falsification scenarios, no execution.

**Blocking/remaining document defects** (not an allegation of exploitable runtime bypass or actually forged receipt):

- **DP-R3-FND004-A — Incompatible protocol versions:** `04_EIGHT_INTERFACE_CONTRACTS_CANDIDATE.json` `common_envelope_proposal.protocol_version` **line 9** is `CANDIDATE_DP_R3`, whereas `04A_TYPED_ENVELOPE_CANDIDATE_SCHEMA.json` `properties.protocol_version.const` **lines 38–40** remains `CANDIDATE_DP_R2`. A claim conforming to the advertised R3 interface fails the R3 schema's own constant requirement. Unify on one version and explicitly address transition from R2.
- **DP-R3-FND004-B — Canonical signed nanosecond time precision:** `04` `common_envelope_proposal.observation_interval.lower/upper` **lines 20–22** calls for `int64-trusted-unix-ns`; `04A` `verified_subject.properties.verified_observation_interval.lower/upper` **lines 1115–1132** uses unrestricted JSON `integer`; `04B_R3` **line 9** proposes RFC 8785/JCS I-JSON UTF-8 canonical signing. Arbitrary Unix epoch nanoseconds are outside IEEE-754 exact-integer range. RFC 8785 recommends encoding higher-precision integers as strings (RFC 8785 §3.1 / Appendix D). Define an exact canonical signed encoding for ns (e.g. decimal string with format and normalization), or constrain every signed integer to an explicit safe range and transform time units under authenticated semantics. Reject non-exact encodings rather than permitting divergent hashes or ordering.
- **DP-R3-FND004-C — No-attempt binding hash not defined:** `04A.$defs.verified_subject.required` **lines 910–913** always requires `request_attempt_binding_sha256`. `04B_R3` **line 15** defines it as the hash of independently authenticated request-to-attempt *mapping bytes*, but **lines 20–22** expressly prohibit inventing an attempt for a `NO_EXTERNAL_FIRST_EFFECT_ATTEMPT` predicate; **line 34** speaks of mapping bytes only 'where relevant'. Specify the exact separately authenticated no-attempt predicate-instance bytes and their canonical digest in this branch, or use a discriminated per-branch digest field. Never require a fictitious physical attempt ID.
- **DP-R3-FND004-D — Provider-policy fields in no-attempt predicates:** `04A.$defs.verified_subject.required` **lines 913–919** unconditionally mandates `verified_provider_policy_id` and `.verified_provider_policy_epoch` for issuer/DB/sealer/Host-local no-provider first-effect predicates. No typed `NOT_APPLICABLE` policy scope or independent semantics for those fields are specified. Do not invent a provider policy for non-provider predicates; define a distinct internal-policy identity if relevant or a typed scoped absence and corresponding verifier requirements.
- **DP-R3-EDITORIAL — Reference name:** The repeated `04.interfaces[*].result_receipt_schema_ref` strings refer to `04B_DP_R3`, not the exact filename `04B_INDEPENDENT_PROOF_VERIFIER_CANDIDATE_R3.md`. `04.semantic_verifier_contract_id` correctly uses the actual filename. Align these for machine-consumable path precision. The `DENIED.semantic_gate` phrase at `04` line 607 also has a missing punctuation boundary; editorial only.

**Receipt validity limit:** `04B_R3` requires recomputation over the actual signed subject bytes under an independently provisioned verifier profile and external anchor. The `receipt_id`, `source`, `canonicalization`, and `verifier_signature_algorithm` are envelope metadata, not all individually members of `signed_subject`; trust-anchor/profile restrictions must prevent unchecked algorithm or receipt-ID substitution. For replay integrity, define whether `receipt_id` is only an untrusted locator or must be signed/bound to the verified evidence index. This is an additional interface-clarity condition, not evidence that a signature check ran.

**Eight 04C static mental checks — not tests:**

| Oracle | Input | Expected rejection / limitation | Static outcome |
|---|---|---|---|
| R3-NEG-01 | schema-valid/self-issued PROVEN receipt | UNKNOWN/NOT_PROVEN | Design demand present (`04B` 32–38); NOT_EXECUTED |
| R3-NEG-02 | attempt A receipt reused for request B | CONFLICT/NOT_PROVEN | explicit request/attempt uniqueness demanded; NOT_EXECUTED |
| R3-NEG-03 | signed raw digest does not match independently fetched bytes | CONFLICT/NOT_PROVEN | byte-hash recomputation demanded; NOT_EXECUTED |
| R3-NEG-04 | tag denial presented for Release asset | UNKNOWN/NOT_PROVEN | exact effect/resource/policy/attempt join demanded; NOT_EXECUTED |
| R3-NEG-05 | NO_EXTERNAL_ATTEMPT with provider DENIED | UNSUPPORTED/NOT_PROVEN | typed schema denial condition excludes no-attempt; NOT_EXECUTED |
| R3-NEG-06 | revoked verifier epoch or unapproved profile | UNKNOWN/NOT_PROVEN | external trust/profile check demanded; NOT_EXECUTED |
| R3-NEG-07 | incompatible signer/provider clock domains | UNKNOWN/NOT_PROVEN | common calibrated time domain demanded; NOT_EXECUTED |
| R3-NEG-08 | single provider denial while App/PAT bypass remains | no Complete Mediation / no CURRENT | explicit competing-writer closure demanded; NOT_EXECUTED |

The negative oracles show correct *stated denial dispositions*, not the validity of a parser, schema, signature, provider or runtime enforcement. Extra no-attempt/canonicalization defects remain even if the eight authored cases are conceptually sound.

## 3. All twelve Finding verdicts and concrete trace anchors

| Finding | R2 independent | Fresh R3 document verdict | Anchors / rationale |
|---|---|---|---|
| FND-DPR0-001 | YES | **YES** | `02` lines 20–44 D0–D13 acyclic, future-only; no authority granted |
| FND-DPR0-002 | YES | **YES** | `01` 194–198, `02` 149–155, `11` DP-WP-06a/06b private versus certified closure |
| FND-DPR0-003 | YES | **YES** | Byte-identical `10_PROVIDER_FIRST_EFFECT_CONTRACTS_R2.csv` CSV rows 2–16 E01–E15 and 17–20 cross-cutting bypass classes; conditional provider controls, all `NOT_ESTABLISHED` and strict `UNENFORCEABLE_AS_PROPOSED` STOP preserved |
| FND-DPR0-004 | PARTIAL | **PARTIAL** | `04` 9/26–27/95–97/.../642–645; `04A` 39, 381–431, 810–851, 892–1394; `04B_R3` 7–39; `04C` rows 2–9; unresolved DP-R3-FND004-A–D above |
| FND-DPR0-005 | YES | **YES** | `01` 174–193, byte-identical `12` 15 distinct paper causal/recovery rows, DS-03 semantics all unselected |
| FND-DPR0-006 | YES | **YES** | `reference_P5_INHERITED_22_37_REGISTER.csv` 22 `FINDING/OPEN` and 37 `COUNTEREXAMPLE/NOT_EXECUTED`; all 59 distinct IDs retained individually in `07` |
| FND-DPR0-007 | YES | **YES** | byte-identical `06` T01–T34, `15` cases T01–T34 and `15A` 34 audit rows; T07/T34 remain finite negative illustrations, 34/34 NOT_EXECUTED and no NC37 equivalence |
| FND-DPR0-008 | YES | **YES** | `05` CSV rows 2–28 E01–E27; E24 CSV row 25 `JUS5-GATE-02_INV-04_MANDATORY`, E26/E27 historical/direct writes not claimed vetoable |
| FND-DPR0-009 | YES | **YES** | `01` 206–212, `02` 166–168 preserve distinct source/build/registry/tarball/Release/Host bytes and negative readback outcome |
| FND-DPR0-010 | YES | **YES** | `01` 206–210 preserve conditional OS-loader/remote Host attester alternatives; H0–H3 and actual use NOT_PROVEN |
| FND-DPR0-011 | YES | **YES** | `11` 18 entries = WP00–15 (16 base) + WP06a/b; every `NOT_AUTHORIZED_NOT_EXECUTED`, `02` 143–164 keeps gates and dependencies |
| FND-DPR0-012 | YES | **YES** | `00`, `09`, `18` unsigned author draft; `01` 214–216 explicitly labels R1-era pending status historical and gives R2 11/1; `02` 141 and 187–195 explicitly identifies R1-era historical statement and R3 current-author status. No adopted/normative claim |

## 4. Non-regression/authority HOLD

- `03_OWNER_AND_NORMATIVE_DECISIONS_UNSIGNED.csv`: **13/13** `selected_option=NONE` (DS-01..06 + O-01..07). Not Owner signatures.
- `05`: E01..E27 **27/27**, E24 mandatory approved v5 fail-closed `JUS5-GATE-02 / INV-04`; all 27 still unsigned proposals/coverage OPEN, E26/E27 unvetoed historic/direct paths not erased.
- `10_R2`: provider E01..E15 differentiated admission surfaces, conditional prior veto and explicit `UNENFORCEABLE_AS_PROPOSED`; **19/19** `current_evidence_state=NOT_ESTABLISHED`, effective writers `NOT_CENSUSED`, policy/epoch `NOT_OBSERVED`, Owner scope `NONE`.
- `12` 15 unexecuted revocation/recovery traces, three DS-03 forks in `01` 176–184: COMMIT freshness, strict revoke-issuance, fence blackout all UNSELECTED.
- `11` 18/18 future WP entries unexecuted; `02` D0..D13 future dependency order acyclic; D6 does not imply D9, D9 no physical provider/Host grant now, no D12/D13.
- `reference_P5_INHERITED_22_37_REGISTER.csv`: 22 original Finding OPEN, 37 NC37 NOT_EXECUTED; all individually present in `07`, no unearned closure. `06` 34/34 `NOT_EXECUTED_DESIGN_ONLY`, `SPEC_ONLY_NOT_EXECUTED`, `NOT_AN_EXECUTION_OF_NC37`, `15` 34/34 `SPEC_ONLY_NOT_EXECUTED`; `04C` 8/8 `SPEC_ONLY_NOT_EXECUTED`.
- `R11 UNAPPROVED`; Task1 historic **31/32**, Case A BLOCKED, Case B PROVEN, *not reexecuted here*; H0–H3 NOT_PROVEN; provider effective rights, complete alternative writer census, physically prior denial, registry exact bytes, Host loaded JS/native mapped bytes and former-primary fencing NOT_ESTABLISHED. R'/D'/P' NOT_ADOPTED; no interface freeze; formal phase/Gates STOP; Tasks2–14 NOT_AUTHORIZED.

## 5. Disposition, bounded remediation and prohibited inference

**`REVISION_REQUIRED / DOCUMENT_QUALITY_ONLY / 11 YES / 1 PARTIAL / 0 NO / NO_EXECUTION_GO`**.

A **document-only DP-R3.1** can correct `04A.properties.protocol_version.const`, clarify canonical I-JSON safe integer or decimal string encoding for signed ns intervals, define the authenticated branch-specific no-attempt digest/policy absence semantics, and align full verifier reference strings. Keep all 11 prior YES non-regressed; provide a byte diff, checksum manifest and author-only adjudication, then obtain a genuinely fresh bounded document-quality re-review. No requirement here to run scripts/tests or query/modify providers before that re-review.

Even a future `DOCUMENT_READINESS_PASS` would only concern *documentation completeness*, not proof of provider-side veto, signer key custody, actual Host attestation, Owner adoption, R'/D'/P' acceptance, interface freeze or `EXECUTION_GO`. No such authorization has been granted.

## Sources for external reference only

- GitHub approved fixed source (GET-only) `yohi/justice` requirements/design/plan at HEAD `8a2e4f1536e9cad499ee7e9d996ff163df132fd4`; Task1 `release.yml` at `c428041dfb5779b6b6dc8db7bf14928225a00373`.
- RFC 8785, *JSON Canonicalization Scheme (JCS)*, Sections 3.1 and 3.2.2.3 and Appendix D: https://www.rfc-editor.org/rfc/rfc8785.html
