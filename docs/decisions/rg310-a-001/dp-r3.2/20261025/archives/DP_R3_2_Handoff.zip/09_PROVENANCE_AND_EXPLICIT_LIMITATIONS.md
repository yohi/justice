# Provenance, checked inputs and explicit limitations

### User authorization interpretation

On 2026-10-25 the user explicitly approved continuing **only toward completion of design and implementation plan**. This packet records the *scope* of that instruction. It does not represent a formal authenticated Owner signature, G1/G2 authorization or DS-02 selection. No impersonation or synthesized signature appears in this packet.

### Primary pinned GitHub source identities (verified by GET-only read this turn)

| Artifact | Fixed ref | Git blob SHA-1 |
|---|---|---|
| Approved v5 Requirements | `8a2e4f1536e9cad499ee7e9d996ff163df132fd4` | `d335c34b747cafd6ac3b2e81d710fdcc61fb777e` |
| Approved v5 Design | same | `64acdf177d2fd207861eb477af7c8a265eed71e8` |
| Approved v5 Plan | same | `10dfba4c199feff19ee387b244daf6c0fd30d5e3` |
| Task1 release.yml | `c428041dfb5779b6b6dc8db7bf14928225a00373` | `4f984a012f3fa9421a32531a00394f4d654d5284` |

Specific v5 clauses read from fixed Requirements: `JUS5-AUTH-01..09` around line 575–645; `JUS5-GATE-01/02` around line 216–235; Design `INV-03/04/05/06` around lines 122–183. Project metadata and paths are source-derived; contract choices are design proposals.

### Source-file archive digests checked on local files this turn

| Source | SHA-256 |
|---|---|
| Owner O-01..07 preparation ZIP | `e252ea48aa3a7e735757dd2208c2ae1b22e9697d0d9eb436cae1a4349099cf5c` |
| P9 result ZIP | `f0efb114aaf04a3ced9da45a6b40ca698b2fe6e275afbed61e46a198e02073b0` |
| P10-A follow-up result ZIP | `194d601b9565f11a55817aa9897912b81375aea01b061cb412001fbecb8b9b55` |
| U-07 normative independent result ZIP | `d4394e0b2d5da3eac4485785f65a83c55e8573bd73a0739f109b8ff54884c439` |

Prior JUS-R11 original matrix and other historical report packages have separate referenced SHA in the source packages. This packet is **not** claiming it independently reverified all historic parent archives or tested all code paths. Historic parent archive `735d9f0c...30160` remains NOT_VERIFIED.

### Crucial missing evidence / absence of proof

- O-01 signed canonical scope and assurance choices / exact protected effect epoch: NOT_PROVIDED.
- DS-01..06 authenticated formal adoption (historical originals unknown): FORMAL_PENDING.
- O-02..06 complete provider App/PAT/CI/GitHub Packages rights and prior-veto enforcement: NOT_PROVEN. `master protected:false` and ruleset `14286365 disabled` were bounded snapshots; do not infer all rights absent.
- O-07 effective old-primary physical fence / issuer authority: NOT_PROVEN.
- Release publisher exact-byte readback, remote ACK, signer key, durable causal COMMIT timestamp bounds, external visibility: NOT_PROVEN.
- Real Host actual-use JS/native loaded bytes and origin H0..H3: NOT_PROVEN. Unknown-tool and Case A remain BLOCKED.
- Source/effect closure remains incomplete despite prior 431 fixed tracked tree; at P1.3 207 blob bodies were then uninspected, and external effects and future generated/loaded bytes are not covered by tree enumeration.
- 22 original Findings OPEN and NC37 NOT_EXECUTED; 34 new test cases in this packet are all SPEC_ONLY/NOT_EXECUTED. No dynamic, offline or provider test run is claimed.

### Deliverable status

This packet is a complete **draft design + draft implementation plan with review checklists**. Status is `DOCUMENT_READY_FOR_INDEPENDENT_REVIEW`, *not* `NORMATIVE_APPROVED`, `INTERFACE_FROZEN`, `IMPLEMENTATION_READY`, `GATE_PASS`, `HOST_RUN`, `PRODUCTION_CERTIFIED`, or `TASK2_14_AUTHORIZED`.

## R1 independent review provenance and status non-equivalence

The external DP-R0 review (original bytes included as a reference, SHA checked by recipient when received) adjudicated twelve Findings `FND-DPR0-001..012`, six Major, five Moderate, one Minor; verdict `REVISION_REQUIRED`. R1 is **author correction in proposal**, not an independent reviewer acceptance. `13_...csv` records an author claim for each finding; all `fresh_independent_verdict=NOT_REVIEWED`.

`reference_P5_INHERITED_22_37_REGISTER.csv` is an intermediate P5 register. Exactly 22 inherited Finding and NC01..NC37 rows are preserved with proposed (not verified) mappings. Underlying historical original source and runtime proof are not newly supplied/verified. Old source/effect closure beyond 27 candidate categories is not proven. Known provider policy observations and connector 400/403/404 are incomplete and not physical veto certificates.

The common envelope JSON Schema is an **unadopted syntactic candidate** and checks neither provider signatures nor real clock bounds, old-primary fencing, prior-denial authority or remote bytes. No runtime tests, embedded commands or provider APIs are executed during R1 authoring; all test fixtures are proposed-only metadata.


## DP-R2 additional evidence limitations

- R2 is an author-side **documentation** response to a user-provided fresh independent DP-R1 review (result `REVISION_REQUIRED`, 9 YES/3 PARTIAL); the original review is nested in the R2 handoff without fabricating a reviewer-signed attestation.
- Official public provider docs clarify ruleset enforcement, GitHub Packages ACL/token use and Codecov upload-token exceptions, but **do not** independently attest this repository's effective policies, all writer populations, or root/attempt-bound prior refusals. Conditional API controls in R2 must not be read as `PROVEN` physical admission controls.
- Verified source fixed HEADs remain unchanged; all newer R2 interface/schema/fixture attributes are proposed static data. Local author JSON/CSV structural inspections, if done, do not test DB/Host/Provider claims.


## DP-R3 receipt limitation / provenance addendum

Original independent R2 review SHA-256: `ea7a1564e4d6a99e5339572b2c836def52545753aee02781b8e8937770bd9e8d` and original R2 handoff SHA-256 `f726aac4501b3ec7070e07ef810a2669ec0752f41093700afaae37c93afbafd0` are byte-preserved in this new outer ZIP. `04B...R2.md` also remains byte-identical; the R3 successor is not a retrospective change to R2's status. The R3 candidate schema and receipt describe prospective cryptographic and provider proofs only. No signer/provider attested proofs, actual raw response bodies or Owner-signed scopes are present. R3 fresh independent verdict NOT_REVIEWED.

## DP-R3.1 append-only evidence (2026-10-25)

- New candidate R3.1 version and schema/checking text address the independently reported R3 FND004 A–D and editorial. The R3 original and reviewer report are preserved as exact byte originals in this handoff; no external source authority asserted by matching archive checks.
- `04B_INDEPENDENT_PROOF_VERIFIER_CANDIDATE_R3_1.md` supersedes R3 verifier **as author proposal only**; R3/R2 versions remain unselected archival references.
- `04D` consists of new paper-only negative oracles, NOT_EXECUTED. No implementation, verification service, keys, source/prov/Host/CI runtime controls, credentials, or external operations were performed.
- R11=UNAPPROVED; Rprime/Dprime/Pprime=NOT_ADOPTED; DS01-06/O01-07=PENDING; Task1=31/32 BLOCKED; original 22 Findings=OPEN; NC37=NOT_EXECUTED; H0-H3=NOT_PROVEN; P2-P4 INTERFACE_FREEZE_STOP; Tasks2-14 NOT_AUTHORIZED; all 34 tests/10 new oracles NOT_EXECUTED; no implementation/CI/Host/provider/ruleset/credential operations.


## R3.2 author delta / provenance only
The latest independent R3.1 review, 2026-10-25, is embedded as `reference/DP_R3_1_INDEPENDENT_REVIEW_ORIGINAL.md`, never adopted as formal authority. DP-R3.1 original ZIP embedded byte-identically as `reference/DP_R3_1_HANDOFF_ORIGINAL.zip`. The only technical change in this R3.2 candidate is the 19-field nonnegative integer epoch/term/sequence canonical decimal-string representation and corresponding `04`/`04B` version/semantics and `04E` paper oracles; other 11 historical YES preserved as documentary reviews. The current proposal is UNSIGNED / NOT_ADOPTED / NOT_EXECUTED / INTERFACE_FREEZE_STOP. Earlier R3.1 status paragraphs are historical, not present R3.2 independent verdicts.
